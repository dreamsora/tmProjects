<?php
include 'inc.php';

$frmid = intval($_GET['id']);
$action = daddslashes($_GET['action']);

$frmrow = $DB->query("select * from tm_form where frm_id=".$frmid." limit 1")->fetch();
$tablename = $frmrow['frm_frmname'];

 $sql = "select COLUMN_NAME,column_comment,COLUMN_TYPE from INFORMATION_SCHEMA.Columns where table_name='".$tablename."' and table_schema='".$data['db_name']."'";
 $rs = $DB->query($sql);

function getenum($ctype){
    $enum = $ctype;
    $enum = str_replace("'", "", $enum);
    $enum_arr=explode("(",$enum);
    $enum=$enum_arr[1];
    $enum_arr=explode(")",$enum);
    $enum=$enum_arr[0];
    $enum_arr=explode(",",$enum);
    return $enum_arr;
}
?>

<!DOCTYPE html>
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            #table-div input{
                height: 30px;
                margin-top: 10px;
            }
        </style>
    </head>
    <body>
        <?php
        if($action == "submit"){
            $tablename = $_POST['tablename'];
            $rurl = $_POST['rurl'];
            unset($_POST['tablename']);
            unset($_POST['rurl']);
            foreach ($_POST as $k => $value) {
                if(gettype($value) == "array"){
                    $str = "";
                    foreach ($value as $v) {
                        if($str != "") $str.=",";
                        $str .= $v;
                    }
                    $_POST[$k] = $str;
                }
              
            }
            if(insert($tablename, $_POST)){
                     exit('<script>alert("添加成功！");window.location.href="'.$rurl.'";</script>');
            }else{
                     exit('<script>alert("添加失败！");window.history.go(-1);</script>');
            }
        }elseif($action == "put"){
            ?>
                <div style="width: 50%;margin: 0 auto;text-align: center;border:1px solid #000;padding: 20px;" id="table-div">
            <!--构造表单开始-->
            <h1><?=$frmrow['frm_name']?></h1>
            <form action="/other/diy.php?action=submit" method="POST">
                <input type="hidden" name="tablename" value="<?=$tablename?>">
                <input type="hidden" name="rurl" value="<?=get_url()?>">
            <?php
              while ($crow = $rs->fetch()){
                  if($crow['COLUMN_NAME'] == "id") continue;
                //  echo var_dump($crow);
                 // echo '<br>'; echo '<br>'; echo '<br>';
                  $name = $crow['COLUMN_NAME'];//字段名
                  $t = explode("|", $crow['column_comment']);
                  $showname = $t[0];//显示名称
                  $htmltype = $t[1];//HTML标签类型
                  
                  //输出单行文本类型
                  if($htmltype == "text"){
                    echo $showname.':<input type="text" name="'.$name.'" required>  ';
                  }
                  if($htmltype == "textarea"){
                    echo $showname.' :<textarea  name="'.$name.'"  row="5" required></textarea> ';
                  }
                  $i = 0;
                  if($htmltype == "radio"){
                       $enum_arr=getenum($crow['COLUMN_TYPE']);
                       echo $showname.'：';
                       foreach ($enum_arr as $v){
                           if($i==0){$checked= "checked";}else{$checked="";}
                           echo '<input type="radio" name="'.$name.'" '.$checked.' value="'.$v.'">'.$v;
                           $i++;
                       }
                  }
                  if($htmltype == "checkbox"){
                       $enum_arr=getenum($crow['COLUMN_TYPE']);
                       echo $showname.'：';
                       foreach ($enum_arr as $v){
                           echo '<input type="checkbox" name="'.$name.'[]" value="'.$v.'">'.$v;
                       }
                  }
                  if($htmltype == "select"){
                       $enum_arr=getenum($crow['COLUMN_TYPE']);
                       echo $showname.'：';
                       echo '<select name="'.$name.'">';
                       foreach ($enum_arr as $v){
                             if($i==0){$selected= "selected";}else{$selected="";}
                           echo '<option value="'.$v.'"  '.$selected.'>'.$v.'</option>';  $i++;
                       }
                       echo '</select>';
                  }
                  echo '<br>';
                   
                }
          
            ?>
                <input type="submit" value="提交表单" > <input type="reset" value="重置表单">
                
            </form>
             <!--构造表单结束-->
        </div>
                <?php
        }
        
        ?>
        
    </body>
</html>



