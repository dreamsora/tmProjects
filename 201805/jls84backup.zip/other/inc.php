<?php



error_reporting(0);
define('SYSTEM_ROOT', dirname(__FILE__).'/');//当前文件路径
define('ROOT', dirname(SYSTEM_ROOT).'/');//上级根目录
date_default_timezone_set('Asia/Shanghai');
session_start();

//数据库配置文件是否存在
if(!file_exists(ROOT.'tmphp/database.php')){
    //数据库配置文件不存在
    exit("未安装");
}
$loginerr = 1;
$data = require ROOT.'/tmphp/database.php'; //加载数据库配置文件

//数据库是否已配置
if($data['db_name'] == '' || $data['db_user'] == '' || $data['db_host'] == ''){
    exit("请先配置数据库文件");
}
$dsn="mysql:host=".$data['db_host'].";dbname=".$data['db_name'];
try {
    $DB = new PDO($dsn, $data['db_user'], $data['db_pwd']); //初始化一个PDO对象
} catch (PDOException $e) {
    die ("Error!: " . $e->getMessage() . "<br/>");
}
$DB->exec("set names utf8");

//主机协议 https || http
define('SERVER_PORT', isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://');
//当前访问的主机名 www.xxx.com
define('HTTP_HOST', (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : ''));
//程序URL地址 http://www.05.com/     
define('SITE_URL', SERVER_PORT.HTTP_HOST);

include ROOT.'tmphp/function/function.php';

function insert($table,$data){
    global $DB;
    foreach($data as $k => $v){
            $fields[] = $v;
            $keys[] = $k;
    }
    $values = "('".implode("','", $fields)."')";
    $column = "(`".implode("`,`", $keys)."`)";
    $sql = "insert into {$table} {$column} values {$values}";
    //exit($sql);
    $cid = $DB->exec($sql);
    return $cid;
}
?>