<?php

$action = !empty($_GET['action'])?$_GET['action']:null;
?>
<!DOCTYPE html>
<html>
    <head>
        <title>拓谋CMS - 用户工具</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="//cdn.bootcss.com/bootstrap/3.3.4/css/bootstrap.min.css">
      
        <script src="//cdn.bootcss.com/jquery/1.11.2/jquery.min.js"></script>
        <script src="//cdn.bootcss.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
        <style>
        
        </style>
    </head>
    <body>
           <div class="container">
               <div class="row"  style="height: 90px;line-height: 90px;color:black;font-size: 20px;font-weight: bold;padding-top: 50px;">
        <?php
        //友情链接工具
        if($action == "links"){
        ?>
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">友情链接生成工具</h3>
            </div>
            <div class="panel-body center-align">
        
                
                <div class="row center-block" style="margin-bottom: 10px;">
                <div class="col-md-12 col-xs-12 col-sm-12">
                    <div class="col-md-3 col-xs-3 col-sm-3" >
                     <input type="text" class="form-control" name="name_0" id="name_0" placeholder="链接名称">

                     </div>
                        <div class="col-md-3 col-xs-3 col-sm-3" >
                   <input type="text" class="form-control" name="class_0" id="class_0" placeholder="class值">
                     </div>
                      <div class="col-md-3 col-xs-3 col-sm-3" >
                   <input type="text" class="form-control" name="url_0" id="url_0" placeholder="链接地址">
                
                     </div>
                        <div class="col-md-3 col-xs-3 col-sm-3" >
                          <select class="form-control" name="target_0" id="target_0">
                               <option value="_blank">_blank 在新窗口中打开</option>
                               <option value="_self">_self 在当前中打开</option>
                               <option value="_parent">_parent 在父窗口中打开</option>
                               <option value="_top">_top 在整个窗口中打开</option>
                               <option value="framename">framename 在指定的框架中打开被链接文档（链接地址填iframe的name值）</option>
                         </select>
                     </div>
                </div>
             </div>
            
            
                <button  class="form-control btn-success" id="addlink" onclick="addlink()" style="margin-bottom: 10px;">增加一个链接</button>
                <div class="row center-block" style="margin-bottom: 10px;">
                       <div class="col-md-12 col-xs-12 col-sm-12">
                    <div class="col-md-3 col-xs-3 col-sm-3" >
                        <input type="text" class="form-control" name="split" id="split" value="|" placeholder="分割符号">

                     </div>
                        <div class="col-md-3 col-xs-3 col-sm-3" >
                     </div>
                      <div class="col-md-3 col-xs-3 col-sm-3" >
                
                     </div>
                        <div class="col-md-3 col-xs-3 col-sm-3" >
                        
                     </div>
                </div>
                </div>
            <button  class="form-control btn-danger" id="shengcheng" onclick="shengcheng()"  style="margin-bottom: 10px;">生成HTML 展示在下方</button>
                  
            <div class="row center-block" style="margin-bottom: 10px;">
                <div class="col-md-12 col-xs-12 col-sm-12">
                    <textarea class="form-control" rows="7" placeholder="代码展示区" id="code"></textarea>
                    
                </div>
            </div>
                
            </div>
        </div>
<script>
var index = 0;
function addlink(){
    index++;
      var html = '<div class="row center-block"  style="margin-bottom: 10px;"> '
           +  '<div class="col-md-12 col-xs-12 col-sm-12"> '
            +   '  <div class="col-md-3 col-xs-3 col-sm-3" > '
            +  '    <input type="text" class="form-control" name="name_'+index+'" id="name_'+index+'" placeholder="链接名称"> '
            +  '    </div> '
             +   '  <div class="col-md-3 col-xs-3 col-sm-3" > '
          + '     <input type="text" class="form-control" name="url_'+index+'" id="class_'+index+'" placeholder="class值"> '
           +  '     </div> '
      +   '  <div class="col-md-3 col-xs-3 col-sm-3" > '
          + '     <input type="text" class="form-control" name="url_'+index+'" id="url_'+index+'" placeholder="链接地址"> '
           +  '     </div> '
              +   '  <div class="col-md-3 col-xs-3 col-sm-3" > '
              +   '      <select class="form-control" name="target_'+index+'" id="target_'+index+'"> '
                   +    '     <option value="_blank">_blank 在新窗口中打开</option> '
                     +  '     <option value="_self">_self 在当前中打开</option> '
                      +  '    <option value="_parent">_parent 在父窗口中打开</option> '
                       + '    <option value="_top">_top 在整个窗口中打开</option> '
                      + '     <option value="framename">framename 在指定的框架中打开被链接文档（链接地址填iframe的name值）</option> '
                  + '   </select> '
              +  '  </div> '
           +  '</div> '
       + '  </div> '
       +  '  ';
    $("#addlink").before(html);
}
function shengcheng(){
    //alert("1");
    var links = "";
    var split = $("#split").val();
    for(var i = 0;i <= index ;i++){
        var link = ""
        var name = $("#name_"+i).val();
        var url = $("#url_"+i).val();
        var clas = $("#class_"+i).val();
        var target = $("#target_"+i+" option:selected").val();
        if(name == "" || url == "")    continue;
        link = "<a href='"+url+"' target='"+target+"' class='"+clas+"'>"+name+"</a>";
        if(links != "")links = links + split;
        links += link;
    }
    $("#code").val(links);
}
</script>

        <?php
        }else{
            ?>
                
                
<a href="?action=links" class="btn btn-danger"  style="margin-bottom:5px;width: 100%">友情链接生成</a>
                  
<a href="?action=links" class="btn btn-success"  style="margin-bottom: 5px;width: 100%">更多</a>      
                
           <?php
        }
        ?>
        
        </div></div>
        
    </body>
</html>