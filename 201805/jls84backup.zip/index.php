<?php

//调试模式：开发阶段设为开启true，部署阶段设为关闭false。
define('APP_DEBUG', false);

//程序根路径
define('APPLICATION_PATH', dirname(__FILE__).DIRECTORY_SEPARATOR); 


/*
 * 引入核心文件
 */
require APPLICATION_PATH.'tmphp/tmbase.php';