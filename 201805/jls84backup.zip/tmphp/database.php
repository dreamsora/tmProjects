<?php
/*拓谋CMS 数据库配置*/
return array(
	'db_host' => 'bdm260213301.my3w.com', //数据库服务器
	'db_port' => 3306, //数据库端口
	'db_user' => 'bdm260213301', //数据库用户名
	'db_pwd' => 'chendong0000000', //数据库密码
	'db_name' => 'bdm260213301_db' //数据库名
);
?>