<?php




/*
 * 导航标签
 * param $p 参数字符串 
 *       type=1,2,3  num=5 class=active 
 *       type：栏目类型ID num：获取数量 class：选中样式 ctypeid:当前栏目ID
 */
function tag_fornav($p,$html){
 
      $p = preg_replace('/\s+/', ' ', $p);//去除多个空格
      $param = explode(' ', $p);
   
      $type = "";//栏目列表 默认全部
      $num = 5; // 加载的数量
      $class = ""; //选中样式
      $parent="and ( lm_parent is null or lm_parent = 0) ";
      foreach ($param as $k => $v){
           $temparr = explode('=', $v);
           if(empty($temparr[1]))               continue;
           $k = $temparr[0];
           $v = $temparr[1];
          // echo $k."---".;
          //获取栏目
          if($k == "type" && $v != "0" && $v != ""){
              $type = $v;
          }
          //获取数量
          if($k == "num" && $v != "0" && $v !=0 && $v != ""){
              $num = $v;
          }
          //获取选中class
          if($k == "class" && $v != null   && $v != ""){
              $class = $v;
          }
          //获取上级ID
          if($k == "parent" && $v != "" && $v != "null" && $v != null){
              $parent = $v;
          }
          
       
          
      }
 
     $GLOBALS['c'] = $class;
      if($type != "" && $type != "all") $type = 'and lm_id in('.$type.')';
      //exit($parent);
      if($parent != "and ( lm_parent is null or lm_parent = 0) ") $parent =  "and lm_parent in($parent)";
      if($type == "all"){
           $sql = "select lm_id,lm_name,lm_pyname from tm_lanmulist where lm_status = 1 order by lm_sort desc limit ".$num;
      }elseif($type != "" && $type != "all"){
        $sql = "select * from tm_lanmulist where lm_status = 1  ".$type." order by lm_sort desc limit ".$num;
   }else{
           $sql = "select lm_id,lm_name,lm_pyname from tm_lanmulist where lm_status = 1 ".$parent." ".$type." order by lm_sort desc limit ".$num;
      }
      
  /*$sqlall = file_get_contents("1.txt");
    $sqlall = $sqlall."\r\n\r\n".$sql;
    file_put_contents("1.txt",$sqlall);*/
      global $DB;
      $rs = $DB->query($sql);
      $rt = "";
      while ($row = $rs->fetch()){
          $GLOBALS['l'] =$row['lm_pyname'];
          $GLOBALS['lmid'] = $row['lm_id'];
          $GLOBALS['db'] = $DB;
            $li =str_replace('{tm:navlink}',SITE_URL.$row['lm_pyname'], $html);
            $li =str_replace('{tm:navname}',$row['lm_name'], $li);
            $li =str_replace('{tm:ctypeid}',$row['lm_id'], $li);
            $li =str_replace('{tm:nav_lm_images}',SITE_URL."upload/img/".$row['lm_images'], $li);
            $li =str_replace('{tm:nav_lm_desc}',$row['lm_desc'], $li);
            $li =str_replace('{tm:nav_lm_key}',$row['lm_key'], $li);
            $li =str_replace('{tm:nav_lm_text}',$row['lm_text'], $li);

           
            $li=preg_replace_callback('/class="([^\"]*)"/',function($ms){   return "class=\"<?=classactive('".$GLOBALS['l'] ."','".$GLOBALS['c']." ".$ms[1]."')?>\""; },$li ); //当前栏目
            $li=preg_replace_callback('/{tm:nav.son}\s+(.+)\s*{\/tm:nav.son}/',function($ms){
                   //return tag_forlinks($ms[1],$ms[2]);
                   $lmid = $GLOBALS['lmid'];
                   $sonhtml = $ms[1];
                   //$sonhtml = preg_replace('/\s+/', ' ', $sonhtml);//去除多个空格
                   $DB= $GLOBALS['db'];
                    $sql = "select lm_name,lm_pyname from tm_lanmulist where lm_parent = ".$GLOBALS['lmid'];
                    $sonrs = $DB->query($sql);
                    $sonlis = "";
                    while ($sonrow = $sonrs->fetch()){
                        $sonli="";
                       $sonli = str_replace('{tm:son_navlink}',SITE_URL.$sonrow['lm_pyname'], $sonhtml);
                 
                         $sonli = str_replace('{tm:son_navname}',$sonrow['lm_name'], $sonli);
                         $sonlis .= $sonli;
                    }
                   return $sonlis;
               },$li ); //子栏目
            $rt .= $li;
      }
     
      return $rt;
}

function classactive($strclass,$classname){
     global $paramarr,$DB;
     if(count($paramarr) > 0){
         $dqparam = $paramarr[0];
         $row = $DB->query("select lm_id from tm_lanmulist where lm_pyname = '$strclass'");
         $row = $row->fetch();
         if($row){
          
             $sql = "select lm_id from tm_lanmulist where lm_pyname = '$dqparam' and lm_parent = ".$row['lm_id'];
             
             $row = $DB->query($sql)->fetch();
             if(intval($row['lm_id'])>0){
                  echo $classname;
             }
         }
     }
     if(in_array($strclass, $paramarr)){
      
         echo $classname;
     }
     
}
function checkIfActive($string,$active) {
	$array=explode(',',$string);
	$php_self=substr($_SERVER['REQUEST_URI'],strrpos($_SERVER['REQUEST_URI'],'/')+1,strrpos($_SERVER['REQUEST_URI'],'.')-strrpos($_SERVER['REQUEST_URI'],'/')-1);
	if (in_array($php_self,$array)){
		return $active;
	}else
		return null;
}

/*
 * 文章循环标签
 */
function tag_forarticle($p,$html){

     $p = preg_replace('/\s+/', ' ', $p);//去除多个空格
     $param = explode(' ', $p);
     
     $lmid = "";//文章所属栏目ID
     $num = 0; // 加载的数量
     $titlelen = 10;//文章标题长度
     
     $article_ish = "";//是否热门
     $article_isc = "";//是否推荐
     $article_isf = "";//是否幻灯
     $article_isj = "";//是否外链
     $article_sui = "";//随机
     
     foreach ($param as $k => $v){
         $temparr = explode('=', $v);
         if(empty($temparr[0]) || $temparr[0] == "" ||$temparr[0] == " ")             continue;
         $k = $temparr[0];
         $v = $temparr[1];
         // echo var_dump($temparr)."<br>";
         if($k == "lmid" && $v != "" && $v != null){
             $lmid = $v;
         }
         //获取数量
         if($k == "num" && $v != "0" && $v !=0 && $v != ""){
            $num = $v;
         }
         //标题长度
         if($k =="titlelen" && $v != "0" && $v !=0 && $v != ""){
             $titlelen = $v;
         }
         
            //文章属性判断
          if($k == "rem" && $v != ""){
               $article_ish = $v;
           }
           if($k == "tui" && $v != ""){
               $article_isc = $v;
           }
           if($k == "huand" && $v != ""){
               $article_isf = $v;
           }
           if($k == "wlink" && $v != ""){
               $article_isj = $v;
           }
           if($k == "sui" && $v != ""){
               $article_sui = $v;
           }
         
     }
     
       $attrwhere = "";
     if($article_ish == 1){
         $attrwhere .= " and article_ish = 1";
     }
     if($article_isc == 1){
         $attrwhere .= " and article_isc = 1";
     }
     if($article_isf == 1){
         $attrwhere .= " and article_isf = 1";
     }
     if($article_isj == 1){
         $attrwhere .= " and article_isj = 1";
     }
     $order = "artice_sort desc";
     if($article_sui == 1){
         $order = "rand()";
     }
     
     global $DB;
     $lmnpyame = "";
     $articleurl = "";
     if($lmid == ""){
         $lmnme = getsonlm();
        
         if($lmnme != ""){
               $sql = "select lm_id,lm_pyname from tm_lanmulist where lm_pyname = '$lmnme' ".$attrwhere;
                $row = $DB->query($sql)->fetch();
                $lmid = $row['lm_id'];
                $lmnpyame = $row['lm_pyname'];
                $lmid = "and article_lm_id = ".$lmid;
                $articleurl = SITE_URL.$lmnpyame."/";
         }
     }
     if($lmid != "" && !strexists($lmid, "and")){
           $lmid = "and article_lm_id in($lmid)";
     }

    $sql = "select * from tm_article_list where artice_status = 1 ".$lmid.$attrwhere." order by $order limit ".$num;

  /*  $sqlall = file_get_contents("1.txt");
    $sqlall = $sqlall.$sql;
    file_put_contents("1.txt",$sqlall);*/

    //exit($sql."---".$attrwhere);
   //      exit($lmid);
    //exit($sql);
     $rs = $DB->query($sql);
     $rt = "";
  

      while ($row = $rs->fetch()){
          $aid = $row['article_id'];
          $li = str_replace('{tm:atic_id}',$row['article_id'], $html);
           $li = str_replace('{tm:atic_alltitle}',$row['article_title'], $li);
          $li = str_replace('{tm:atic_title}',substr_utf8($row['article_title'],$titlelen), $li);
          $li = str_replace('{tm:atic_time}',$row['article_addtime'], $li);
          $li =  str_replace('{tm:atic_author}',$row['article_author'], $li);
          $li = str_replace('{tm:atic_desc}',$row['article_description'], $li);
          $li = str_replace('{tm:atic_key}',$row['article_keywords'], $li);

          $li = str_replace('{tm:atic_images}',SITE_URL."upload/img/".$row['article_images'], $li);
        
                $lmid = $row['article_lm_id'];
                $sql = "select lm_id,lm_pyname from tm_lanmulist where lm_id = '$lmid'";
                $row = $DB->query($sql)->fetch();
                $lmnpyame = $row['lm_pyname'];
                $articleurl = SITE_URL.$lmnpyame."/";
         
         
        $li = str_replace('{tm:atic_link}',$articleurl."article_".$aid.".html", $li);
          
          $rt .= $li;
         
      }
 
    return $rt;
}

/*
 * 获得当前栏目ID
 */
function getsonlm(){
    global $paramarr;
   // exit(var_dump($paramarr));
    $sonlmname = "";
    for($i=count($paramarr)-1;$i>=0;$i--){
        $t = $paramarr[$i];
        if(strexists($t, ".")){
            continue;
        }else{
            $sonlmname = $t;
            break;
        }
    }
    return $sonlmname;
}

/*
 * 获取文章url
 */
function getacticleurl(){
    global $paramarr;
    $acticleurl = SITE_URL;
    for($i=0;$i< count($paramarr);$i++){
        $t = $paramarr[$i];
        if(strexists($t, ".") || strexists($t, " ") || $t == ""){
            continue;
        }else{
            $acticleurl .= $t;
        }
    }
    return $acticleurl;
}

/*
 * 截取指定长度的字符
 * @param $str string 待处理的字符串
 * @param $len int 截取的字符数量
 * @param $tail string 超过部分代替字符
 * return String 处理后的字符串
 */
function substr_utf8($str,$len,$tail="..."){
    if(mb_strlen($str,"utf-8") > $len){
        $rstr = mb_substr($str,0,$len,'utf-8');
        $rstr .= $tail;
    }else{
        $rstr = $str;
    }
    return $rstr;
}

/*
 * 栏目页面 遍历article标签的解析
 * time: 2018.4.27
 */
function lmarticle($p1,$p2){
     $p1 = preg_replace('/\s+/', ' ', $p1);//去除多个空格
     $param = explode(' ', $p1);
     $num = 5;//默认提取数量
     $titlelen = 30;//默认标题长度
     
     $article_ish = "";//是否热门
     $article_isc = "";//是否推荐
     $article_isf = "";//是否幻灯
     $article_isj = "";//是否外链
       $article_sui = "";//随机
     foreach ($param as $v){
           $temp = explode('=', $v);
          
           //获取栏目ID
           if($temp[0] == "lmid" && $temp[1] != ""){
               $lmid = $temp[1];
           }
           //获取提取数量
           if($temp[0] == "num" && $temp[1] != ""){
               $num = $temp[1];
           }
           //获取标题截取的字符数量
           if($temp[0] == "titlelen" && $temp[1] != ""){
               $titlelen = $temp[1];
           }
           
           //文章属性判断
          if($temp[0] == "rem" && $temp[1] != ""){
               $article_ish = $temp[1];
           }
           if($temp[0] == "tui" && $temp[1] != ""){
               $article_isc = $temp[1];
           }
           if($temp[0] == "huand" && $temp[1] != ""){
               $article_isf = $temp[1];
           }
           if($temp[0] == "wlink" && $temp[1] != ""){
               $article_isj = $temp[1];
           }
           if($temp[0] == "sui" && $temp[1] != ""){
               $article_sui = $v;
           }
           
     }
     
     $attrwhere = "";
     if($article_ish == 1){
         $attrwhere .= " and article_ish = 1";
     }
     if($article_isc == 1){
         $attrwhere .= " and article_isc = 1";
     }
     if($article_isf == 1){
         $attrwhere .= " and article_isf = 1";
     }
     if($article_isj == 1){
         $attrwhere .= " and article_isj = 1";
     }
     $order = "artice_sort desc";
     if($article_sui == 1){
         $order = "rand()";
     }
     global $tag_lminfo;
     $bindex = !empty($_SESSION['cpageintdex'])?$_SESSION['cpageintdex']-1:0;
     $bindex = $bindex*$num;
     if(empty($lmid) || $lmid == ""){
         $lmid = $tag_lminfo['lm_id'];
         $sql = "select * from tm_article_list where artice_status = 1 and article_lm_id = ".$lmid." or article_lm_id in (select lm_id from tm_lanmulist where lm_parent = ".$lmid.") ".$attrwhere." order by artice_sort desc limit  $bindex,$num";
     }else{
         $sql = "select * from tm_article_list where artice_status = 1 and article_lm_id in (".$lmid.")  ".$attrwhere." order by artice_sort desc limit $bindex,$num";
     }
  
     global $DB;
     $rs = $DB->query($sql);
      $rt = "";
     while ($row = $rs->fetch()){
          $aid = $row['article_id'];
          $li = str_replace('{tm:atic_id}',$row['article_id'], $p2);
          $li = str_replace('{tm:atic_alltitle}',$row['article_title'], $li);
          $li = str_replace('{tm:atic_title}',substr_utf8($row['article_title'],$titlelen), $li);
          $li = str_replace('{tm:article.description/}',$row['article_description'], $li);
          $li = str_replace('{tm:article.keywords/}',$row['article_keywords'], $li);
          $li = str_replace('{tm:atic_time}',$row['article_addtime'], $li);
          $li =  str_replace('{tm:atic_author}',$row['article_author'], $li);
        //  $li = str_replace('{tm:atic_author}',$row['article_author'], $li);
          $li = str_replace('{tm:atic_images}',SITE_URL."upload/img/".$row['article_images'], $li);
          
          $lid= $row['article_lm_id'];
          $lrs = $DB->query("select lm_pyname from tm_lanmulist where lm_id =".$lid." limit 1")->fetch();
       
          if($row['article_isj'] == 1){
              $articlelink = $row['article_isj_url'];
          }else{
              $articlelink = SITE_URL.$lrs['lm_pyname']."/article_".$aid.".html";
          }
          $li = str_replace('{tm:atic_link}',$articlelink, $li);
          $rt .= $li;
     }
     return $rt;



}

/*
 * 栏目导航 遍历解析
 * time:2018.4.27
 */
function lmnav($p,$p2){
      $p = preg_replace('/\s+/', ' ', $p);//去除多个空格
      $param = explode(' ', $p);
   
      $parent = "";//栏目列表 默认全部
      $num = 5; // 加载的数量
      $class = ""; //选中样式
      $cascade =0;
      foreach ($param as $k => $v){
          $temp = explode('=', $v);
          if($temp[0] == "parent" && $temp[1] != ""){
              $parent = $temp[1];
          }
          if($temp[0] == "num" && $temp[1] != ""){
              $num = $temp[1];
          }
          if($temp[0] == "class" && $temp[1] != ""){
              $class = $temp[1];
          }
          if($temp[0] == "cascade" && $temp[1] != ""){
              $cascade = $temp[1];
          }
          
      }
      global $tag_lminfo,$DB;
     
      if($parent == "" && $tag_lminfo){
          $parent = $tag_lminfo['lm_id'];
      }
      
      //级联导航
      if($cascade && intval($parent) > 0){
        
          $sql = "select lm_parent from tm_lanmulist where lm_status = 1 and lm_id = ".$parent;
          $checkpr = $DB->query($sql)->fetch();
          if($checkpr && intval($checkpr['lm_parent']) >0){
              $pllm_id = $checkpr['lm_parent'];
              $sql = "select * from tm_lanmulist where lm_parent = ".$pllm_id;
             // exit($sql);
               $checkpr = $DB->query($sql);
               $parent=$pllm_id;
               while ($checkprow = $checkpr->fetch()){
                    if($parent!=""){
                        $parent.=",";
                    }
                    $parent .= $checkprow['lm_id'];
               }
              
          }
         // echo $parent."<br>";
      }
      
      
      if($parent == ""){
           $sql = "select * from tm_lanmulist  where lm_status = 1 order by lm_sort desc limit ".$num;
      }else{
           $sql = "select * from tm_lanmulist  where lm_status = 1 and lm_parent in ($parent)  order by lm_sort desc limit ".$num;
      }
      $rs = $DB->query($sql);
      $rt = "";
      $GLOBALS['c'] = $class;
     //  echo "---".$parent."<br>";
      while ($row = $rs->fetch()){
           $GLOBALS['l'] =$row['lm_pyname'];
           
           $li =  str_replace('{tm:navlink}',SITE_URL.$row['lm_pyname'], $p2);
           $li =str_replace('{tm:navname}',$row['lm_name'], $li);
           $li = str_replace('{tm:ctypeid}',$row['lm_id'], $li);
           $li=preg_replace_callback('/class="([^\"]*)"/',function($ms){   return "class=\"".$ms[1]." <?=classactive('".$GLOBALS['l'] ."','".$GLOBALS['c']."')?>\""; },$li ); //当前栏目
            
           $rt .= $li;
      }
    
      return $rt;
}

/*
 * 分页标签解析
 * time:2018.5.8
 */
function pagelist($p,$p2){
    $param = explode(' ', $p);
    $listsize= 5;
    //提取分页属性
    foreach ($param as $k => $v){
        $temp = explode('=', $v);
        if($temp[0] == "listsize"){
            $listsize = $temp[1];
        }
        
    }
    //获取当前页
    $pagebindex = !empty($_SESSION['cpageintdex'])?$_SESSION['cpageintdex']:1;
    //获得当前栏目、数据库链接、加载文件路径
    global $tag_lminfo,$DB,$loadfilepath;
   // if($tag_lminfo && $loadfilepath['path'] == ""){
        $loadfilepath['path'] = $tag_lminfo['lm_pyname']."/";
   // }
    //获得当前栏目ID
    $lmid = $tag_lminfo['lm_id'];
    $li ="";
    
    //获得当前栏目的文章数量
    $sql = "select count(article_id) from tm_article_list  where artice_status = 1 and article_lm_id = ".$lmid." or article_lm_id in (select lm_id from tm_lanmulist where lm_parent = ".$lmid.") ";
    
    //获得总行数
    $rownum = $DB->query($sql)->fetch();
    if($rownum[0] ==0)return"";
    //获得页数
    $pagesize = intval($rownum[0]/$listsize);
     if ($rownum[0]%$listsize)
    {
     $pagesize++;
     }
     //记录页数
     $_SESSION['page'] = $pagesize;
     if($pagesize > 1){
         $li .= fpagehtml_li("./","首页");
     }
    
    if(!strexists($loadfilepath['path'], "/")){
        $loadfilepath['path'] = $loadfilepath['path']."/";
    }
    //当前页不是第一页，显示上一页
    if($pagebindex >1){
         $link = SITE_URL.$loadfilepath['path']."list_".($pagebindex-1).".html";
         $li .= fpagehtml_li($link,"上一页");
    }
    //当前页不是最后一页，显示下一页
    if($pagebindex != $pagesize){
         $link = SITE_URL.$loadfilepath['path']."list_".($pagebindex+1).".html";
         $li .= fpagehtml_li($link,"下一页");
    }
     if($pagesize > 1){
              $li.=  fpagehtml_li(SITE_URL.$loadfilepath['path']."list_".$pagesize.".html","尾页");
       }
      // exit($li);
         $li.=  fpagehtml_li("#","",$pagesize,SITE_URL.$loadfilepath['path'],$pagebindex);
         $li.=  fpagehtml_li("#","共".$pagesize."页/".$rownum[0]."条");
 //     exit(htmlspecialchars($li));
    return $li;
}
/*
 * 分页html
 */
function fpagehtml_li($u,$i,$option =0,$au ="",$pagebindex=0){
    $html = '<li class="page_li"><a href="'.$u.'">'.$i.'</a></li>';
    if($option){
         $html = "";
         $op = "";
         $op .= "<option value='#'>选择页</option>";
        for($i=1;$i<=$option;$i++){
            $lk =$au."list_".$i.".html";
            $selected="";
            if($i==$pagebindex) $selected="selected";
            $op .= "<option value='$lk' $selected>".$i."</option>";
        }
          $html = '<li class="page_li"><select  onchange="pagejump(this.value)">'.$op.'</select></li>';
    }
    return $html;
}

function tag_articleimageslist($p,$p2){
    $list = explode(",", $GLOBALS['list']);
    $li = "";
    foreach ($list as $value) {
        $li .= str_replace('{tm:article.imageslistsrc}',SITE_URL."upload/img/".$value, $p2);
    }
    return $li;
 
}

//幻灯片
function tag_forslides($p,$p2){
   //   exit(123);
      
      $p = preg_replace('/\s+/', ' ', $p);//去除多个空格
      $param = explode(' ', $p);
      $num = 0;
     // var_dump($param);
      foreach ($param as $value) {
          $value = explode("=", $value);
          if($value[0] == "num" || $value[1] != ""){
              $num = $value[1];
          }
      }
      global $DB;
      $sql = "select * from tm_slides where slides_status = 1 limit ".$num;
    
      $rs = $DB->query($sql);
      $lis = "";
      while ($row = $rs->fetch()){
            $li = "";
            $li .= str_replace('{tm:slides.title}',$row['slides_name'], $p2);
            $li = str_replace('{tm:slides.target}',$row['slides_target'], $li);
            $li = str_replace('{tm:slides.link}',$row['slides_url'], $li);
            $li = str_replace('{tm:slides.images}',SITE_URL."upload/img/".$row['slides_images'], $li);
            $lis.=$li;
      }
 
      return $lis;
}
//友情链接
function tag_forlinks($p,$p2){
      $p = preg_replace('/\s+/', ' ', $p);//去除多个空格
      $param = explode(' ', $p);
      $num = 0;
      foreach ($param as $value) {
          $value = explode("=", $value);
          if($value[0] == "num" || $value[1] != ""){
              $num = $value[1];
          }
      }
      global $DB;
      $sql = "select * from tm_links where link_status = 1 limit ".$num;
    
      $rs = $DB->query($sql);
      $lis = "";
      while ($row = $rs->fetch()){
            $li = "";
            $li .= str_replace('{tm:links.title}',$row['link_name'], $p2);
        
            $li = str_replace('{tm:links.link}',$row['link_url'], $li);
            $lis.=$li;
      }
 
      return $lis;
}