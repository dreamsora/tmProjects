<?php



class tmtag{
    public $template_tag_left = '{';     //模板左标签
    public $template_tag_right = '}';    //模板右标签
    
    
    public $systag = array();//系统标签
    public function __construct() {

    }
    
    
  //=======================================
  //            定义标签函数
  //======================================
    /*
     * 【系统 标签库1】标准标签
     */
    public static function systemvar(){
        $sysvar = array();
        $sysvar['{tm:global.cfg_basehost/}'] = SITE_URL;   //网站的地址
        $sysvar['{tm:global.cfg_style/}'] = TEMP_URL_."style/"; //  style文件夹地址
        $sysvar['{tm:global.cfg_css/}'] = TEMP_URL_."css/"; //css文件夹地址
        $sysvar['{tm:global.cfg_js/}'] = TEMP_URL_."js/";  // js文件夹地址
        $sysvar['{tm:global.cfg_images/}'] = TEMP_URL_."images/"; //images文件夹地址
        
        /*
         * 系统参数
         * 将系统参数转为标签
        */
        $webconfig = system::webinfoquery();
        foreach ($webconfig as $k => $v){
            if($k =="logo"){
                $sysvar['{tm:global.'.$k.'/}'] = SITE_URL."/upload/logo/".$v;
                continue;
            }
            $sysvar['{tm:global.'.$k.'/}'] = $v;
        }
        $zdyvar = system::zdyvarquery();
        while ($zdyrow = $zdyvar->fetch()){
            $sysvar['{tm:zdy.'.$zdyrow['var_key'].'/}'] = $zdyrow['var_value'];
        }
        
        return $sysvar;
    }

     /*
     * 【系统 标签库2】 标准空格标签
     */
    public static function systemspvar(){
        $sysvar = array();
        $sysvar['{tm:global.cfg_basehost / }'] = SITE_URL;   //程序安装的地址
        $sysvar['{tm:global.cfg_style / }'] = TEMP_URL."style/"; //  style文件夹地址
        $sysvar['{tm:global.cfg_css / }'] = TEMP_URL."css/"; //css文件夹地址
        $sysvar['{tm:global.cfg_js / }'] = TEMP_URL."js/";  // js文件夹地址
        $sysvar['{tm:global.cfg_images / }'] = TEMP_URL."images/"; //images文件夹地址
        
        /*
         * 系统参数
         * 将系统参数转为标签
        */
        $webconfig = system::webinfoquery();
        foreach ($webconfig as $k => $v){
            $sysvar['{tm:global.'.$k.' / }'] = $v;
        }
        $zdyvar = system::zdyvarquery();
        while ($zdyrow = $zdyvar->fetch()){
            $sysvar['{tm:zdy.'.$zdyrow['var_key'].' / }'] = $zdyrow['var_value'];
        }
        return $sysvar;
    }
    
    /*
     * 【栏目 标签库】基本固定标签
     */
    public static function lmvar($lmrow){
         $lmtag = array();
         $lmtag['{tm:lm.id/}'] = 'lm_id';
         $lmtag['{tm:lm.title/}'] = 'lm_name';
         $lmtag['{tm:lm.ftitle/}'] = 'lm_fname';
         $lmtag['{tm:lm.images/}'] = 'lm_images';
         $lmtag['{tm:lm.desc/}'] = 'lm_desc';
         $lmtag['{tm:lm.key/}'] = 'lm_key';
         $lmtag['{tm:lm.name/}'] = 'lm_pyname';
         $lmtag['{tm:lm.boby/}'] = 'lm_text';
         $lmtag['{tm:lm.time/}'] = 'lm_addtime';
         $lmtag['{tm:lm.id / }'] = 'lm_id';
         $lmtag['{tm:lm.desc / }'] = 'lm_desc';
         $lmtag['{tm:lm.key / }'] = 'lm_key';
         $lmtag['{tm:lm.ftitle / }'] = 'lm_fname';
         $lmtag['{tm:lm.images / }'] = 'lm_images';
         $lmtag['{tm:lm.title / }'] = 'lm_name';
         $lmtag['{tm:lm.name / }'] = 'lm_pyname';
         $lmtag['{tm:lm.boby / }'] = 'lm_text';
         $lmtag['{tm:lm.time / }'] = 'lm_addtime';
         return $lmtag;
    }
 
     /*
     * 【文章 标签库】文章页面标签
     */
    public static function tag_article(){
            $ataf = array();
            $ataf['{tm:article.title/}'] = 'article_title';
            $ataf['{tm:article.description/}'] = 'article_description';
            $ataf['{tm:article.keywords/}'] = 'article_keywords';
            $ataf['{tm:article.images/}'] = 'article_images';
            //$ataf['{tm:article.imageslist/}'] = 'article_imageslist';
            $ataf['{tm:article.text/}'] = 'article_text';
            $ataf['{tm:article.addtime/}'] = 'article_addtime';
            $ataf['{tm:article.author/}'] = 'article_author';
            
            $ataf['{tm:article.title /}'] = 'article_title';
            $ataf['{tm:article.description /}'] = 'article_description';
            $ataf['{tm:article.keywords /}'] = 'article_keywords';
            $ataf['{tm:article.images /}'] = 'article_images';
            //$ataf['{tm:article.imageslist /}'] = 'article_imageslist';
            $ataf['{tm:article.text /}'] = 'article_text';
            $ataf['{tm:article.addtime /}'] = 'article_addtime';
            $ataf['{tm:article.author /}'] = 'article_author';
            
            $ataf['{tm:article.title / }'] = 'article_title';
            $ataf['{tm:article.description / }'] = 'article_description';
            $ataf['{tm:article.keywords / }'] = 'article_keywords';
            $ataf['{tm:article.images / }'] = 'article_images';
           // $ataf['{tm:article.imageslist / }'] = 'article_imageslist';
            $ataf['{tm:article.text / }'] = 'article_text';
            $ataf['{tm:article.addtime / }'] = 'article_addtime';
            $ataf['{tm:article.author / }'] = 'article_author';

            return $ataf;
    }
    
  //=======================================
  //            解析函数
  //======================================

    /*
     * 【解析】系统标签库 
     */
    public static function system_tag_replace($html){
        $tagarr = self::systemvar();
        foreach ($tagarr as $k => $v){
            $html = str_replace($k,$v,$html);
        }
        /*
         * 带空格替换 固定标签+系统标签+自定义标签
         */
        $html = preg_replace('/\s+/', ' ', $html);//去除多个空格
        $tagarr = self::systemspvar(); // 带空格的TM标签
        foreach ($tagarr as $k => $v){
            $html = str_replace($k,$v,$html);
        }
       
        return $html;
    }

    /*
     * 【解析】 栏目高级标签
     */
    public static function lmgjtag($lmrow,$html){
          $tp_tag_left = "{";
          $tp_tag_right = "}";
          $GLOBALS['tag_lminfo'] =  $lmrow;
          $html=preg_replace_callback('/'.$tp_tag_left.'tm:article\s+(.+)\s*'.$tp_tag_right.'\s+(.+)\s*{\/tm:article}/',function($ms){ return lmarticle($ms[1],$ms[2]); },$html ); //文章循环标签
          $html=preg_replace_callback('/'.$tp_tag_left.'tm:nav\s+(.+)\s*'.$tp_tag_right.'\s+(.+)\s*{\/tm:nav}/',function($ms){ return lmnav($ms[1],$ms[2]); },$html ); //导航循环标签
           $html=preg_replace_callback('/{tm:slides\s+(.+)\s* }\s+(.+)\s*{\/tm:slides}/',function($ms){ return tag_forslides($ms[1],$ms[2]); },$html ); //幻灯片循环标签
          
          return $html;
    }
    
    /*
     * 检查是否含有分页标签
     */
    public static function checjpagelist($html){
        if(strexists($html, "{tm:pagelist") || strexists($html, "{/tm:pagelist}")){
            return true;
        }else{
            return false;
        }
    }
 
    /*
     * 【解析】栏目标签库 
     */
    public static function lm_tag_replace($lmrow,$html){
        $lmtag = self::lmvar($lmrow);
        foreach ($lmtag as $k => $v){
              if($v == "lm_images"){
                 $html = str_replace($k,SITE_URL."upload/img/".$lmrow[$v],$html);
                 continue;
            }
            $html = str_replace($k,$lmrow[$v],$html);
        }
        return $html;
    }


    /*
     * 【解析】 高级解析
     */
    public static function publi_gh_repalace($str){
           $tp_tag_left = "{";
           $tp_tag_right = "}";
           $str=preg_replace_callback('/'.$tp_tag_left.'tm:include\s+(.+)'.$tp_tag_right.'/',function($ms){ return "<?php include incde(".$ms[1]."); ?>"; },$str );//替换引入标签
           $str=preg_replace_callback('/'.$tp_tag_left.'tm:php\s+(.+)\s*'.$tp_tag_right.'/',function($ms){ return "<?php ".$ms[1]."?>"; },$str ); //PHP自定义代码标签
           return $str;
    }


    //=======================================
    //          执行解析
    //=======================================
    /*
     * 栏目页面解析
     * @param $lmrow string 栏目信息
     * @param $html string 模板页面
     */
    public static function tpl_lm_replace($lmrow,$html){
        $html = self::publi_gh_repalace($html);
        $html = self::system_tag_replace($html);
        $html = self::lm_tag_replace($lmrow,$html);
        $html = self::lmgjtag($lmrow, $html);
        $html = str_replace('{tm:global.position/}', self::getaddress($lmrow),$html);
        return $html;
    }
    /*
     * 解析栏目分页标签
     */
    public static function lm_pagelist_rep($row,$html){
         $tp_tag_left = "{";
          $tp_tag_right = "}";
         $html=preg_replace_callback('/'.$tp_tag_left.'tm:pagelist\s+(.+)\s*'.$tp_tag_right.'\s+(.+)\s*{\/tm:pagelist}/',function($ms){ return pagelist($ms[1],$ms[2]); },$html ); //分页标签
         return $html;
    }
    
    /*
     * 获取当前位置
     */
    public static  function getaddress($lmrow){

        $a = '<a href="'.SITE_URL.'">首页</a>';
        global $DB;
        if($lmrow['lm_parent']){
            $sql = "select * from tm_lanmulist where lm_id = ".$lmrow['lm_parent'];
            $plmrow = $DB->query($sql)->fetch();
            if($plmrow){
                $a .= " > ";
                $a .= '<a href="'.SITE_URL.''.$plmrow['lm_pyname'].'">'.$plmrow['lm_name'].'</a>';
            }
            
        }
        
         $a .= " > ";
         $a .= '<a href="'.SITE_URL.''.$lmrow['lm_pyname'].'">'.$lmrow['lm_name'].'</a>';
          
        return $a;
    }



    /*
     * 解析标准固定标签
     */
    public static function tpl_replace($html){
       
        /*
         * 标签替换成php
         */
        $html = self::tpl_tmtafreplace($html); 
        
        /*
         * 初步替换固定标签+系统标签+自定义标签
         */
        $tagarr = self::systemvar();
        foreach ($tagarr as $k => $v){
            $html = str_replace($k,$v,$html);
        }
        
        /*
         * 带空格替换 固定标签+系统标签+自定义标签
         */
        $html = preg_replace('/\s+/', ' ', $html);//去除多个空格
        $tagarr = self::systemspvar(); // 带空格的TM标签
        foreach ($tagarr as $k => $v){
            $html = str_replace($k,$v,$html);
        }
        
        return $html;
    }



    /*
     * tm高级标签的替换
     */
    public static  function tpl_tmtafreplace($str){
        $tp_tag_left = "{";
        $tp_tag_right = "}";
       // exit("开始解析...");

     /*  $str = preg_replace("/".$tp_tag_left."tm:include\s+(.+)".$tp_tag_right."/", "<?php include incde(\\1); ?>", $str); //替换引入标签
        $str = preg_replace("/".$tp_tag_left."php\s+(.+)\s*".$tp_tag_right."/", "<?php \\1?>", $str );
        */
        
       $str=preg_replace_callback('/'.$tp_tag_left.'tm:include\s+(.+)'.$tp_tag_right.'/',function($ms){ return "<?php include incde(".$ms[1]."); ?>"; },$str );//替换引入标签
       $str=preg_replace_callback('/'.$tp_tag_left.'tm:php\s+(.+)\s*'.$tp_tag_right.'/',function($ms){ return "<?php ".$ms[1]."?>"; },$str ); //PHP自定义代码标签
       
       $str=preg_replace_callback('/'.$tp_tag_left.'tm:nav\s+(.+)\s*'.$tp_tag_right.'\s+(.+)\s*{\/tm:nav}/',function($ms){ return tag_fornav($ms[1],$ms[2]); },$str ); //导航循环标签
       
       $str=preg_replace_callback('/'.$tp_tag_left.'tm:article\s+(.+)\s*'.$tp_tag_right.'\s+(.+)\s*{\/tm:article}/',function($ms){ return tag_forarticle($ms[1],$ms[2]); },$str ); //文章循环标签
       
       $str=preg_replace_callback('/'.$tp_tag_left.'tm:slides\s+(.+)\s*'.$tp_tag_right.'\s+(.+)\s*{\/tm:slides}/',function($ms){ return tag_forslides($ms[1],$ms[2]); },$str ); //幻灯片循环标签
         
       $str=preg_replace_callback('/'.$tp_tag_left.'tm:links\s+(.+)\s*'.$tp_tag_right.'\s+(.+)\s*{\/tm:links}/',function($ms){ return tag_forlinks($ms[1],$ms[2]); },$str ); //幻灯片循环标签
       
        return $str;
    }

    /*
     * 文章页的替换 
     */
    public static function tpl_articlereplace($arow,$html,$lmrow=null){
         $tp_tag_left = "{";
        $tp_tag_right = "}";
        $tagarr = self::tag_article();
        
        //文章固定标签
        foreach ($tagarr as $k => $v){
            if($v == "article_images"){
                 $html = str_replace($k,SITE_URL."upload/img/".$arow[$v],$html);
                 continue;
            }
            $html = str_replace($k,$arow[$v],$html);
        }
        
        
        //自定义标签替换
        $article_zdy = $arow['article_zdy'];
        if($article_zdy){
            $zdyarr = explode("|", $article_zdy);
            foreach ($zdyarr as $value) {
                $kv = explode("=", $value);
                $html = str_replace("{tm:article.".$kv[0]."/}",$kv[1],$html);
            }
        }
        
        //文章页面图集遍历
        if(strexists($html, "tm:article.imageslist")){
           $GLOBALS['list'] = $arow['article_imageslist'];
           $html=preg_replace_callback('/'.$tp_tag_left.'tm:article.imageslist\s+(.+)\s*'.$tp_tag_right.'\s+(.+)\s*{\/tm:article.imageslist}/',function($ms){ return tag_articleimageslist($ms[1],$ms[2]); },$html ); //文章中的图集
        
        }
        //文章页面 上一篇
        if(strexists($html, "{tm:article.before/}")){
           global $DB;
            //$beforers = $DB->query("select * tm_article_list");
            $beforers = $DB -> query("select * from tm_article_list where artice_status = 1 and article_lm_id=".$lmrow['lm_id']." and article_id <".$arow['article_id']." order by article_id desc limit 1")->fetch();
           $before = "无上一篇";
            if($beforers){
                 $link =   SITE_URL.$lmrow['lm_pyname']."/article_".$beforers['article_id'].".html";
                 $before = "<a href='".$link."'>上一篇:".substr_utf8($beforers['article_title'],20)."</a>";
            }
            $html = str_replace("{tm:article.before/}",$before,$html);
            
        }
        
        //文章页面 下一篇
        if(strexists($html, "{tm:article.next/}")){
             global $DB;
            $next = "无下一篇";
            $nextrs = $DB->query("select * from tm_article_list where artice_status = 1 and article_lm_id=".$lmrow['lm_id']." and article_id >".$arow['article_id']." order by article_id desc limit 1");
      
         //   exit("select * from tm_article_list where artice_status = 1 and article_lm_id=".$lmrow['lm_id']." and article_id >".$arow['article_id']." order by article_id desc limit 1");
          if($nextrs = $nextrs->fetch()){
                  $link = SITE_URL.$lmrow['lm_pyname']."/article_".$nextrs['article_id'].".html";
                    $next = "<a href='".$link."'>上一篇:".substr_utf8($nextrs['article_title'],20)."</a>";
            }
        
         
            if($nextrs){
                 $link = SITE_URL.$lmrow['lm_pyname']."/article_".$nextrs['article_id'].".html";
            $next = "<a href='".$link."'>上一篇:".substr_utf8($nextrs['article_title'],20)."</a>";
            }
           
            $html = str_replace("{tm:article.next/}",$next,$html);
            
        }
       
        

        //文章页面位置 栏目标题 循环
        if(strexists($html, "{tm:global.position/}") || strexists($html, "{tm:article.lmname/}") || strexists($html, "{tm:article.lmfname/}")){
            
                 global $DB;
                $sql = "select * from  tm_lanmulist where lm_id =".$arow['article_lm_id'];
                $lmrow = $DB->query($sql)->fetch();   
            
                $html = str_replace('{tm:global.position/}', self::getaddress($lmrow),$html);
                $html = str_replace('{tm:article.lmname/}', $lmrow['lm_name'],$html);
                $html = str_replace('{tm:article.lmfname/}', $lmrow['lm_fname'],$html);
                
                $html = self::lmgjtag($lmrow, $html);
                $html = self::lm_tag_replace($lmrow, $html);

        }
      
        return $html;
    }

}