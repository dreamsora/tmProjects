<?php

/*
 * 缓存文件生成类
 */

class createcache{
    private $cachepath = ''; //缓存文件路径
    private $tp_name = '';//当前模板名称
    private $tp_path = '';//
    private $lmdiralllist = array();//栏目文件夹列表
    private $tag = '';//标签解析类

    public function __construct() {
        $ret = system::query('tm_config_webinfo',"k = 'webtp'");
        if(!$ret) debug::showbug("当前模板无效","请恢复系统默认设置,或尝试重新安装！",1);
        
        $this->tp_name = $ret['webtp']; // 设置模板名称
        $this->tp_path = TEMP_PATH.$this->tp_name;//模板全路径
        $this->cachepath = APPLICATION_PATH.CACHE_DIR."/"; //设置缓存目录文件夹
        if(!is_dir($this->cachepath)){
            //创建缓存目录文件夹
            mkdir ($this->cachepath,0777,true);
        }
        if(!is_dir($this->tp_path)) debug::showbug("当前模板无效","请在后台网站设置中填入可用的模板名称！如果不能使用,请恢复系统默认设置,或尝试重新安装！",1);
        if(!is_dir($this->cachepath)) debug::showbug("当前缓存目录无效","请确保缓存目录有写入权限！",1);
        $this->tag = system::load_class('tmtag');//获取标签库
        
        $this->lmdiralllist = self::getalllmbydb();//获取数据库中所有的栏目
        
      }
    
    /*
     * 初始化缓存目录 [创建缓存目录]
     */
    public function init(){
         $this->createindexpage(1);//创建首页[强制创建]
         $this->createlmlist();//创建所有栏目
         $this->create_lmindex(1); //创建栏目首页
    }
    
    /*
     * 获取数据库中所有的栏目
     */
    public static function getalllmbydb(){
        global $DB;
        $lmlist = array();
        $sql = "select lm_id,lm_pyname from tm_lanmulist where lm_status = 1";
         $res = $DB->query($sql);
         while ($row = $res->fetch()){
            array_push($lmlist, $row['lm_pyname']);
        }
        return $lmlist;
    }
    
    //============================
    //          栏目的创建
    //============================
    
    /*
     * 创建网站首页页面
     *  $forcibly 0/1 是否强制创建
     */
    public function createindexpage($forcibly = 0){
         $mdpath = $this->tp_path."/index.html"; //模板文件路径
         $cfile =  $this->cachepath.""."index.tm.php";//缓存文件路径
         if($forcibly || filemtime($mdpath) <  filemtime($cfile)  ){
                   $html = file_get_contents($mdpath);//获取模板文件
                    /*
                     * 处理模板标签
                     */
                   $tag = $this->tag;
                   $html = $tag::tpl_replace($html);
                    
                   file_put_contents($cfile, $html);//写出模板
         } 
    }
    
    /*
     * 创建数据库中所有栏目的文件夹
     * 
     */
    public function createlmlist(){
       
        $list = $this->lmdiralllist;
        foreach ($list as $value){
            $lmdirpath = $this->cachepath.$value;
            if (!is_dir($lmdirpath)){
                mkdir ($lmdirpath,0777,true);
            }
        }
    }
    
     /*
     * 创建所有栏目首页
     * $forcibly 0/1 是否强制创建
     */
    public function create_lmindex($forcibly = 0){
        
        $list = $this->lmdiralllist;
    
        foreach ($list as $v){
          
            global $DB;
            
            /*
             * 获取栏目信息
             */
            $sql = "select * from tm_lanmulist where lm_pyname = '$v' limit 1";
            $row = $DB->query($sql)->fetch();
            $md = $row['lm_pagemodel'];//当前分页的页面类型模板
             // echo $v."---".$row['lm_pagemodel'].'<br>';
            $mdpath = $this->tp_path."/".$md; //模板文件路径
            
            $chpath = $this->cachepath.$v; //缓存文件夹路径 [栏目路径]
            
            $cfile =  $chpath."/"."index.tm.php";//缓存文件路径
         
            if($forcibly || filemtime($mdpath) <  filemtime($cfile)  ){
                   $html = file_get_contents($mdpath);//获取模板文件 
                      $tag = $this->tag;
                 
                    /*
                    * 处理模板标签
                    */
                 
                    $html =$tag->tpl_lm_replace($row,$html);
                   // $html =$tag::tpl_replace($html);
                   // 
                      // 是否含有分页标签
                    if($tag->checjpagelist($html)){
                       !empty($_SESSION['page'])?"":$_SESSION['page']=0;
                       unset($_SESSION['page']);
                       $html = $tag::lm_pagelist_rep($row,$html);
                       
                       /*
                        * 含有分页标签
                        */
                       $pagesize = empty($_SESSION['page'])?1:$_SESSION['page'];//获取分页数量
                       //exit($pagesize."-*-");
                       for($i=1;$i<=$pagesize;$i++){
                           $pagelisthtml = file_get_contents($mdpath);//获取模板文件 
                           
                           $_SESSION['cpageintdex'] = $i;
                           $pagelisthtml =$tag->tpl_lm_replace($row,$pagelisthtml);
                           $pagelisthtml = $tag::lm_pagelist_rep($row,$pagelisthtml);
                           unset($_SESSION['cpageintdex']);
                           file_put_contents( $chpath."/list_".$i.".tm.php", $pagelisthtml);//写出模板
                       }
                       
                    }
                   
                    file_put_contents($cfile, $html);//写出模板
            }
         
            
        }
        //exit("创建所有栏目首页借结束");
    }
    

    //============================
    //          文章的创建
    //============================
     /*
     * 创建文章页面
     */
    public function createarticle(){
        /* $fname = "article_article";
      
         $mdpath = $this->tp_path."/".$fname.".html"; //模板文件路径
        
         if(!file_exists($mdpath)){
             exit("文章模板页面不存在！");
         }
         *   $html = file_get_contents($mdpath);//获取模板文件
         */
        
         
         $sql = "select * from tm_article_list where artice_status = 1";
       
         global $DB;
         $rs = $DB->query($sql);
         while ($row = $rs->fetch()){
             
             $lmid = $row['article_lm_id'];
             $lmrow = $DB->query("select lm_id,lm_pyname,lm_articlemodel from tm_lanmulist where lm_id =".$lmid)->fetch();
             $fname = $lmrow['lm_articlemodel']==""?"article_article.html":$lmrow['lm_articlemodel'];
             if(strexists($fname, ".html")){
                    $mdpath = $this->tp_path."/".$fname; //模板文件路径
             }else{
                   $mdpath = $this->tp_path."/".$fname.".html"; //模板文件路径
             }
           
            // echo $lmid.'---'.$fname."---".$mdpath."<br>";
            if(!file_exists($mdpath)){
                exit("文章模板页面不存在！");
            //   debug::showbug("文章的模板文件不存在", "找不到模板文件：".$mdpath);
            }
             $html = file_get_contents($mdpath);//获取模板文件
             
             
             $thtml = $html;
             $tag = $this->tag;
             $thtml = $tag::tpl_replace($thtml);
             $thtml = $tag::tpl_articlereplace($row,$thtml,$lmrow);
            
             $cfile =  $this->cachepath.$lmrow['lm_pyname']."/article_".$row['article_id'].".tm.php";//缓存文件路径
             file_put_contents($cfile, $thtml);//写出模板
         } 
        
     //   exit();
    }
    
    /*
     * 批量批量文件夹
     * param $dirlist array 待创建的文件夹列表
     * param $path string 文件夹穿件的路径
     */
    public function createdirlist($dirlist,$path = ""){
        if(!$dirlist) return false;
        foreach($dirlist as $k => $v){
            if(empty($path)){
                $v = $this->cachepath.$v;
            }else{
                 $v = $path.$v;
            }
            if (!file_exists($v)){
                mkdir ($v,0777,true);
            }
        }
                
    }
    
    /*
     * 创建单文件夹
     */
    public function createdlm($dirname,$path){
        if(empty($path)){
             $dirname = $this->cachepath.$dirname;
        }else{
             $dirname = $path.$dirname;
        }
        if (!file_exists($dirname)){
            mkdir ($dirname,0777,true);
        } 
    }
    
    
   
    
   
    
    /*
     * 创建谋个文件
     */
    public function createfile($fname){
         $mdpath = $this->tp_path."/".$fname.".html"; //模板文件路径
         $cfile =  $this->cachepath.$fname.".tm.php";//缓存文件路径
     
         if(!file_exists($cfile) || filemtime($mdpath) >  filemtime($cfile)  ){
                   $html = file_get_contents($mdpath);//获取模板文件
                    /*
                    * 处理模板标签
                    */
                   $tag = $this->tag;
                  $html = $tag::tpl_replace($html);
                    
                    file_put_contents($cfile, $html);//写出模板
         }
         return $cfile;//返回缓存文件目录
      
    }
    
   
    
}
