<?php

/*
 * 路由解析类 & 参数处理类
 */

class param{
    private $url = '';//当前网址全路径
    private $path = '';//域名后方路径
    private $cachepath =''; //模板文件夹
    public function __construct() {
        $this->url =  get_url();
        $this->path = get_path_info();
        //echo $this->url."----".$this->path;
         $this->cachepath = APPLICATION_PATH.CACHE_DIR."/"; //设置缓存文件夹
        $this->checkurl();
        
    }
    
    /*
     * 验证路由
     */
    public function checkurl(){
       // if($this->path!=null) check_string(SERVER_PORT.HTTP_HOST.$this->path,$this->url,1);//路由验证
    }
    
    /*
     * 解析路径 得到域名后面所有的参数 以/分割
     */
    public function resolvepath(){
        $path = $this->path;
        $patharr = explode("/",$path);
        $retarr = array();
        foreach ($patharr as $k => $v){
            if($v == "" || $v == null || $v == " ")continue;
            array_push($retarr, $v);
        }
        return $retarr;
    }
    
    /*
     * 是否合法地址
     */
    public function checkpath($paramarr){
        if(!$paramarr){ return "index"; } // 路由为空 默认访问首页
        
    }
    
    
    /*
     * 拼接地址 获得当前地址对应的缓存文件
     */
    public function spliceurl($retarr){
        
        /*
         * 无任何参数，访问首页
         */
        if(!$retarr || $retarr[0] == null || $retarr[0] == "" || count($retarr) == 0){
            $parr = array("path"=>"","apath" =>$this->cachepath."index.tm.php" ); //返回文件路径的全部地址
            return $parr;
        }
        
        
        $apath = "";
        $path = "";
   
        foreach ($retarr as $k => $v){
                if($apath != ""){
                    $path .= '/';
                    $apath .= '/';
                }
                
                if($k+1 == count($retarr)){
                    if(strexists($v, ".".URL_TAIL)){
                        $wstr= substr($v,0,strrpos($v,'.'));  
                        $apath .= $wstr.".tm.php";
                       // exit($apath);
                        break;
                    }
                }
                $apath .= $v;
                if(!strexists($v, ".html")){
                       $path.= $v;
                }
                
        }
        if(!strexists($apath, ".tm.php")){
            $apath .="/index.tm.php";
        }
        return array("path"=>$path,"apath" =>$this->cachepath.$apath );
        
    }
    
    
}
