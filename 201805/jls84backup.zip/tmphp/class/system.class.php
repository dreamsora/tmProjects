<?php
/**
 *
 * @author ayang
 */

/*
 * 
 */
class system {
    
    //===========================================
    //              查询 
    //===========================================
    
    /*
     * 查询配置文件
     * $param $tablename String 表名
     */
    public static function query($tablename,$where = 1){
        global $DB;
        $sql = "SELECT k,v FROM `$tablename` where ".$where;
        $row = $DB->query($sql);
        return self::processreturndata($row);
    }
    
    /*
     * 网站信息查询
     */
    public static function webinfoquery(){
        global $DB;
        $sql = "select k,v from tm_config_webinfo";
        $row = $DB->query($sql);
        
        return self::processreturndata($row);
    }
    
    /*
     * 自定义变量获取
     */
    public static function zdyvarquery(){
        global $DB;
        $sql = "select * from tm_customizevar";
        $row = $DB->query($sql);
        return $row;
    }


    /*
     * 将返回结果集转为数组类型
     */
    public static function processreturndata($row){
        if(!$row){
            return false;
        }
        while ($r = $row -> fetch()){
            $conf[$r['k']]=$r['v'];
        }
     
        return $conf;
    }
    
    //===========================================
    //              加载 
    //=========================================== 
    
    /*
     * 加载类文件
     * @param string $classname 类名 
     * @param string $path 扩展地址
     * @param intger $initialize 是否初始化
     */
     public static function load_class($classname,$path = '', $initialize = 1){
          if(empty($path))  $path = TM_PATH."class".DIRECTORY_SEPARATOR.$classname.".class.php";
         
          if(file_exists($path)){
                include $path;
                if($initialize){
                    return new $classname;
                }
          }else{
               debug::showbug("系统类文件被损坏","类:".$classname."不存在,目标文件:".$path."找不到",1);
         }
     }
    
    /*
     * 加载函数文件
     * @param string $filename 函数文件名 
     * @param string $path 扩展地址
     */
    public static function load_funs($filename,$path = ''){
        if(empty($path)) $path = TM_PATH."function".DIRECTORY_SEPARATOR.$filename.".php";
        if(file_exists($path)){
            include $path;
        }else{
            debug::showbug("系统函数文件被损坏","类:".$filename."不存在,目标文件:".$path."找不到",1);
        }
    }

    
}
