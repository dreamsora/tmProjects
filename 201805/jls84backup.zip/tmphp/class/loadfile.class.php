<?php


/*
 * 加载文件类
 */

class loadfile{
    private $loadpath = '';//加载地址
    
    /*
     * 加载文件
     */
    public static function inc($paramarr){
        $path = $paramarr['apath'];
     
        if(file_exists($path)){
            include $path;
        }else{
            if(APP_DEBUG){
                debug::showbug("文件不存在","目标文件".$path."找不到",1);
            }else{
                debug::showbug("404","目标文件".$path."找不到",1);
            }
            
        }
    }
    
    
    
}