<?php

class debug{
    
    
    public static function bughtml($msg,$tis ){
        $html = '<!DOCTYPE html>
<!--
拓谋网络 - BY：ayang
-->
<html>
    <head>
        <title>出错了！拓谋CMS - DEBUG</title>
        <meta charset="UTF-8">
       <meta name="viewport" content="target-densitydpi=device-dpi, width=480px, user-scalable=no">
    </head>
    <body>
        <h1 style="font-size: 40px;">哎呀！error ~_~</h1>
      
        <h2>错误信息：<font color=red>'.$msg.'</font></h2>';
    if(APP_DEBUG){
         $html .=' <p >错误提示：<font color=blue>'.$tis.'</font></p>';
    }   
                
     $html .='<span>runtime:'.date('Y-m-d H:i:s').'</span>
    </body>
</html>
';
        return $html;
    }


    public static function  showbug($msg="无错误信息!",$tis="无错误提示",$die = 0){
        echo self::bughtml($msg,$tis);
        if($die) exit();
       
    }
}