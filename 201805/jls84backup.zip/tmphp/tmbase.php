<?php
//error_reporting(0);
date_default_timezone_set('Asia/Shanghai');
//===================================================================
//                      程序基本参数
//===================================================================
//设置系统的输出字符为utf-8
header('Content-Type:text/html;charset=utf-8'); 

//核心文件路径
define('TM_PATH', dirname(__FILE__).DIRECTORY_SEPARATOR);

//模板应用目录
define('TEMP_PATH', APPLICATION_PATH.'templets'.DIRECTORY_SEPARATOR);

//主机协议 https || http
define('SERVER_PORT', isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://');

//当前访问的主机名 www.xxx.com
define('HTTP_HOST', (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : ''));

//访问来源
define('HTTP_REFERER', isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '');

//IS_CGI
define('IS_CGI', (0 === strpos(PHP_SAPI,'cgi') || false !== strpos(PHP_SAPI,'fcgi')) ? 1 : 0 );
//当前文件名
if(IS_CGI) {
	//CGI/FASTCGI模式下
	$_temp  = explode('.php', $_SERVER['SCRIPT_NAME']);
	define('PHP_FILE', rtrim(str_replace($_SERVER['HTTP_HOST'], '', $_temp[0].'.php'), '/'));
}else {
	define('PHP_FILE', rtrim($_SERVER['SCRIPT_NAME'], '/'));
}

//程序安装路径 /                          /20180407/05/
define('SITE_PATH', str_replace('index.php', '', PHP_FILE));

//程序URL地址 http://www.05.com/        http://localhost/20180407/05/
define('SITE_URL', SERVER_PORT.HTTP_HOST.SITE_PATH);

//模板应用目录
define('TEMP_URL', SITE_URL.'templets/');

//系统开始时间 1523514864.1186
define('SYS_START_TIME', microtime(true));

//系统时间 1523514864
define('SYS_TIME', time());

define("URL_TAIL", 'html');//文件后缀尾巴
define('CACHE_DIR', "cache");//缓存文件存放目录

//===================================================================
//                      数据库参数
//===================================================================

//数据库配置文件是否存在
$installurl = SITE_URL."install/";
if(!file_exists(TM_PATH.'database.php')){
      header('Location:'.$installurl);exit();
}
$data = require TM_PATH.'database.php'; //加载数据库配置文件

//数据库是否已配置
if($data['db_name'] == '' || $data['db_user'] == '' || $data['db_host'] == ''){
     header('Location:'.$installurl);exit();
}
$dsn="mysql:host=".$data['db_host'].";dbname=".$data['db_name'];
try {
    $DB = new PDO($dsn, $data['db_user'], $data['db_pwd']); //初始化一个PDO对象
} catch (PDOException $e) {
    die ("Error!: " . $e->getMessage() . "<br/>");
}
$DB->exec("set names utf8");


//===================================================================
//                      加载核心文件
//===================================================================
 if(!file_exists(TM_PATH.'class/system.class.php') || !file_exists(TM_PATH.'class/debug.class.php')){
        if(APP_DEBUG)  echo '系统文件已损坏,请下载完整的安装包';
        exit();
}
require TM_PATH.'class/system.class.php';//系统配置类
$webinfo_conf = system::webinfoquery();//获得网址配置
define("MB_NAME", $webinfo_conf['webtp']);//获得当前使用的模板

system::load_funs("function");//加载核心函数文件
system::load_funs("indexfunction");//加载核心函数文件
system::load_class("debug");//加载BUG类
$param = system::load_class("param");//加载参数处理类

$create = system::load_class("createcache"); //加载生成缓存文件类
$loadfile = system::load_class("loadfile");//加载 加载文件类

define('TEMP_URL_', SITE_URL.'templets/'.$webinfo_conf['webtp']."/");//当前模板路径url

// 获取当前的参数

$paramarr = $param->resolvepath();//获取解析好的路由地址

$loadfilepath = $param->spliceurl($paramarr); // 拼接地址 当前地址访问的文件 



//初始化首页
if(!file_exists(TM_PATH.'init.lock') || APP_DEBUG){
    $ben=microtime(true);
    $create->init();
    $end=microtime(true);
    $timec = $end-$ben;
  //   exit("111");
    file_put_contents(TM_PATH.'init.lock', date('Y-m-d H:i:s')."->首页/栏目/初始化完成！耗时：".$timec);
}
//初始化文章
if(!file_exists(TM_PATH.'articleinit.lock') || APP_DEBUG){
    $ben=microtime(true);
    $create->createarticle();
    $end=microtime(true);
    $timec = $end-$ben;

    file_put_contents(TM_PATH.'articleinit.lock',date('Y-m-d H:i:s'). "->文章初始化完成！耗时：".$timec);
}
    //$create->createarticle();
    $create->createfile("search");
   
$loadfile->inc($loadfilepath);//加载当前访问的文件
