SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS `tm_admin`;
CREATE TABLE `tm_admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_user` varchar(30) NOT NULL,
  `admin_pass` varchar(30) NOT NULL,
  `admin_phone` varchar(30) DEFAULT NULL,
  `admin_qq` varchar(20) DEFAULT NULL,
  `admin_eamil` varchar(50) DEFAULT NULL,
  `admin_qx_article` int(11) NOT NULL DEFAULT '0',
  `admin_qx_lm` int(11) NOT NULL DEFAULT '0',
  `admin_qx_web` int(11) NOT NULL DEFAULT '0',
  `admin_qx_system` int(11) NOT NULL DEFAULT '0',
  `admin_status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
INSERT INTO `tm_admin` VALUES ('1', 'admin', '123456', '', '8888888', '', '1', '1', '1', '1', '1');
DROP TABLE IF EXISTS `tm_articlezdyzd`;
CREATE TABLE `tm_articlezdyzd` (
  `articlezdyzd_id` int(11) NOT NULL AUTO_INCREMENT,
  `articlezdyzd_name` varchar(200) DEFAULT NULL,
  `articlezdyzd_kv` text,
  PRIMARY KEY (`articlezdyzd_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
INSERT INTO `tm_articlezdyzd` VALUES ('1', '软件', '下载地址:dowm:text|软件密码:pass:txt|软件截图:softimages:images');
INSERT INTO `tm_articlezdyzd` VALUES ('2', '商城', '尺寸:size:txt|颜色:color:txt|库存:kc:txt');
DROP TABLE IF EXISTS `tm_article_list`;
CREATE TABLE `tm_article_list` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `article_lm_id` int(11) NOT NULL,
  `article_title` varchar(250) DEFAULT NULL COMMENT '文章标题',
  `article_description` varchar(200) DEFAULT '' COMMENT '文章描述',
  `article_keywords` varchar(200) DEFAULT NULL COMMENT '文章关键字',
  `article_images` varchar(200) DEFAULT NULL,
  `article_imageslist` varchar(200) DEFAULT NULL,
  `article_text` text COMMENT '文章内容',
  `article_addtime` datetime DEFAULT NULL COMMENT '添加时间',
  `article_author` varchar(50) DEFAULT NULL COMMENT '文章作者',
  `article_ish` int(11) NOT NULL DEFAULT '0',
  `article_isc` int(11) NOT NULL DEFAULT '0',
  `article_isf` int(11) NOT NULL DEFAULT '0',
  `article_isj` int(11) NOT NULL DEFAULT '0',
  `article_isj_url` text,
  `artice_sort` int(11) DEFAULT '5',
  `article_zdy` text,
  `artice_status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`article_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `tm_config_webinfo`;
CREATE TABLE `tm_config_webinfo` (
  `k` varchar(200) NOT NULL,
  `v` text,
  PRIMARY KEY (`k`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
INSERT INTO `tm_config_webinfo` VALUES ('webname', '拓谋CMS');
INSERT INTO `tm_config_webinfo` VALUES ('webkey', '拓谋CMS');
INSERT INTO `tm_config_webinfo` VALUES ('webdes', 'CMS系统');
INSERT INTO `tm_config_webinfo` VALUES ('webtp', 'default');
INSERT INTO `tm_config_webinfo` VALUES ('beian', '湘A1234968412564');
INSERT INTO `tm_config_webinfo` VALUES ('footer', '等所发生的');
INSERT INTO `tm_config_webinfo` VALUES ('flinks', '\r\n<li><a href=\"http://www.tuomou.com/\" target=\"_blank\">拓谋网络</a> </li>\r\n                  \r\n                  <li><a href=\"www.tuomou.com/\" target=\"_blank\">拓谋主机</a> </li>\r\n                  \r\n                  <li><a href=\"http://www.tuomou.com/\" target=\"_blank\">响应式拓谋模板</a> </li>');
INSERT INTO `tm_config_webinfo` VALUES ('kqqq', '123456789');
INSERT INTO `tm_config_webinfo` VALUES ('telephone', '8888-888');
INSERT INTO `tm_config_webinfo` VALUES ('address', '湖南省长沙市岳麓区湖南大学科技园');
INSERT INTO `tm_config_webinfo` VALUES ('logo', '1524712548.png');
DROP TABLE IF EXISTS `tm_customizevar`;
CREATE TABLE `tm_customizevar` (
  `var_id` int(11) NOT NULL AUTO_INCREMENT,
  `var_name` varchar(30) DEFAULT NULL,
  `var_key` varchar(50) DEFAULT NULL,
  `var_value` text,
  PRIMARY KEY (`var_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
INSERT INTO `tm_customizevar` VALUES ('1', '首页轮播文字1(小字)', 'index_lb_xz_1', '2018 - 找我们做网站我们只收取空间域名成本价，免取网站高额制作费用。.');
INSERT INTO `tm_customizevar` VALUES ('2', '首页轮播文字1(大字)', 'index_lb_dz_1', '打破传统-企业免网站制作费');
INSERT INTO `tm_customizevar` VALUES ('3', '首页轮播文字1(链接)', 'index_lb_url_1', 'http://wpa.qq.com/msgrd?v=3&uin=123456789&site=qq&menu=yes');
INSERT INTO `tm_customizevar` VALUES ('4', '首页轮播文字1(按钮)', 'index_lb_btn_1', '马上咨询');
INSERT INTO `tm_customizevar` VALUES ('5', '首页轮播文字2(小字)', 'index_lb_xz_2', '主流三合一响应式网站');
INSERT INTO `tm_customizevar` VALUES ('6', '首页轮播文字2(大字)', 'index_lb_dz_2', '一个网站就能自动适应PC端+平板端+手机端使用');
INSERT INTO `tm_customizevar` VALUES ('7', '首页轮播文字2(链接)', 'index_lb_url_2', '#');
INSERT INTO `tm_customizevar` VALUES ('8', '首页轮播文字2(按钮)', 'index_lb_btn_2', '体验一下');
INSERT INTO `tm_customizevar` VALUES ('9', '首页轮播文字3(大字)', 'index_lb_dz_3', '为企业所想 满足企业需求');
INSERT INTO `tm_customizevar` VALUES ('10', '首页轮播文字3(小字)', 'index_lb_xz_3', '升级以您的需求为导向,提升以您的价值为目标');
INSERT INTO `tm_customizevar` VALUES ('11', '首页轮播文字3(链接)', 'index_lb_url_3', '#');
INSERT INTO `tm_customizevar` VALUES ('12', '首页轮播文字3(按钮)', 'index_lb_btn_3', '咨询客服');
DROP TABLE IF EXISTS `tm_form`;
CREATE TABLE `tm_form` (
  `frm_id` int(11) NOT NULL AUTO_INCREMENT,
  `frm_name` varchar(30) DEFAULT NULL,
  `frm_frmname` varchar(30) DEFAULT NULL,
  `frm_addtime` datetime DEFAULT NULL,
  `frm_list_model` varchar(30) DEFAULT NULL,
  `frm_con_model` varchar(30) DEFAULT NULL,
  `frm_put_model` varchar(30) DEFAULT NULL,
  `frm_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`frm_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `tm_lanmulist`;
CREATE TABLE `tm_lanmulist` (
  `lm_id` int(11) NOT NULL AUTO_INCREMENT,
  `lm_name` varchar(100) DEFAULT NULL COMMENT '栏目名称',
  `lm_fname` varchar(100) DEFAULT NULL,
  `lm_images` varchar(200) DEFAULT NULL,
  `lm_desc` varchar(200) DEFAULT NULL,
  `lm_key` varchar(200) DEFAULT NULL,
  `lm_pyname` varchar(200) NOT NULL COMMENT '栏目拼音名称',
  `lm_pagetype` int(11) DEFAULT NULL COMMENT '[栏目页面类型]1:单页面，2：列表页面，3：图文页面，4：外联',
  `lm_pagemodel` varchar(30) NOT NULL,
  `lm_articlemodel` varchar(40) DEFAULT NULL,
  `lm_addtime` datetime DEFAULT NULL,
  `lm_text` text,
  `lm_sort` int(11) DEFAULT '5' COMMENT '栏目排序',
  `lm_parent` int(11) DEFAULT NULL COMMENT '上级栏目ID',
  `lm_status` int(11) DEFAULT NULL COMMENT '栏目状态',
  PRIMARY KEY (`lm_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `tm_links`;
CREATE TABLE `tm_links` (
  `link_id` int(11) NOT NULL AUTO_INCREMENT,
  `link_name` varchar(30) DEFAULT NULL,
  `link_url` varchar(100) DEFAULT NULL,
  `link_sort` int(11) DEFAULT NULL,
  `link_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`link_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
INSERT INTO `tm_links` VALUES ('1', '百度一下', 'www.baidu.com', '1', '1');
DROP TABLE IF EXISTS `tm_pagetype`;
CREATE TABLE `tm_pagetype` (
  `pt_id` int(11) NOT NULL AUTO_INCREMENT,
  `pt_name` varchar(30) DEFAULT NULL,
  `pt_model` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`pt_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
INSERT INTO `tm_pagetype` VALUES ('1', '单页封面', 'index_article.html');
INSERT INTO `tm_pagetype` VALUES ('2', '列表文字', 'list_article.html');
INSERT INTO `tm_pagetype` VALUES ('3', '图文展示', 'list_image.html');
DROP TABLE IF EXISTS `tm_slides`;
CREATE TABLE `tm_slides` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slides_name` varchar(50) DEFAULT NULL,
  `slides_images` varchar(100) DEFAULT NULL,
  `slides_url` varchar(200) DEFAULT NULL,
  `slides_target` varchar(30) DEFAULT NULL,
  `slides_sort` int(11) DEFAULT NULL,
  `slides_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
INSERT INTO `tm_slides` VALUES ('1', '幻灯片2', '1524193889.png', 'www.eachnet.com', '_blank', '5', '1');
INSERT INTO `tm_slides` VALUES ('2', '幻灯片3', '1524203536.png', 'www.windows.com', '_parent', '5', '1');