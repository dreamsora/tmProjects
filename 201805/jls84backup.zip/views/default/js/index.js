/**
 * Created by tonk on 2016/11/4.
 *//*
*/
$(function () {
    var num=0
    $('#main').click(function () {
        num++
        if(num%2==0){
            alert('取消收藏')
        }
        else {
            alert('收藏成功')
        }
    })
})
$(function () {
    var banner=document.getElementById('banner')
    var oul=banner.getElementsByTagName('ul')[0]
    var dd=document.getElementsByClassName('d1')
    var oli=banner.getElementsByTagName('li')
    var num=0
   for(var i=0;i<dd.length;i++){
        oli[i].index=i
        oli[i].onmousemove=function () {
            num = this.index
            fun()
        }
    }
    function fun() {
        for (j = 0; j <dd.length;j++) {
            oli[j].style.background= '#99cff0'
            dd[j].style.opacity=0
        }
        oli[num].style.background= '#0457a5'
        dd[num].style.opacity=1
    }

    time = setInterval(function () {
        num++
        if (num == dd.length) {
            num = 0
        }
        fun()
    }, 5000)
    banner.onmouseover = function () {
        clearInterval(time)
    }
    banner.onmouseout = function () {
        time = setInterval(function () {
            num++
            if (num == dd.length) {
                num = 0
            }
            fun()
        }, 5000)
    }
})

//banner轮播修饰

$(function () {
    var k2=document.getElementsByClassName('k2')
    var k1=document.getElementsByClassName('k1')
    var tp=document.getElementsByClassName('tab1')
    for(var i=0;i<k2.length;i++){
        k2[i].index=i
        k2[i].onclick=function () {
            for(var j=0; j<k2.length;j++){
                k2[j].style.background='#fff'
                k2[j].style.borderColor='#e5e5e5'
                k1[j].style.color='#404040'
                tp[j].style.display='none'
            }
            k2[this.index].style.background='#0457a5'
            k2[this.index].style.borderColor='#0457a5'
            k1[this.index].style.color='#fff'
            tp[this.index].style.display='block'
        }
    }
})

/********右侧头部********/
$(function () {
    var k3=document.getElementsByClassName('k3')
    var k4=document.getElementsByClassName('k4')
   var arr=['images/lin.png','images/lin1.png']
    for(i=0;i<k3.length;i++){
        k3[i].index=i
        k3[i].onclick=function () {
            for(var j=0; j<k3.length;j++){
              k3[j].style.backgroundImage='url('+arr[0]+')'

                k4[j].style.color='#7c7c7c'
            }
            k3[this.index].style.backgroundImage='url('+arr[1]+')'

            k4[this.index].style.color='#fff'

        }
    }
})
/***********左侧列表切换背景*************/
$(function(){
    var arr=['images/clib1.png','images/clib1.png','images/clib.png']
    var num=0
    $('.lt').click(function(){
        num--
        if(num==-1){
            num=arr.length
        }
        $('.bac').attr('src',arr[num])

    })
    $('.rt').click(function(){
        num++
        if(num==arr.length){
            num=0
        }
        $('.bac').attr('src',arr[num])
    })
})
$(function(){
    var dem=document.getElementById('demo')
    var dem2=document.getElementById('dem')
    var de=dem2.offsetHeight

    function scr() {
        dem.scrollTop++
        if(dem.scrollTop==284){
            dem.scrollTop=0
        }
    }
      var time=setInterval(scr,30)
    $('#dem').mouseover(function () {
        clearInterval(time)
        }
    )
    $('#dem').mouseout(function () {
        time=setInterval(scr,30)
    })
})

$(function () {
    var n=document.getElementsByClassName('n1')
    var n1=document.getElementsByClassName('ne1')
    var ti=document.getElementsByClassName('tip1')
    for(i=0;i<n.length;i++){
        n[i].index=i
        n[i].onclick=function () {
            for(j=0;j<n.length;j++){
                n1[j].style.color='#909090'
              ti[j].style.display='none'
            }
            n1[this.index].style.color='#0457a5'
            ti[this.index].style.display='block'
        }
    }
    
})

$(function () {
   $('#lr').click(function () {
       $('.show-sec').css({'transform':'translateX(-925px)','transition':'0.5s'})

   })
$('#gr').click(function () {
    $('.show-sec').css({'transform':'translateX(0px)','transition':'0.5s'})
})

})
$(function(){
    var col1=document.getElementById('coll1')
    var col2=document.getElementById('coll2')
    var col=document.getElementById('coll')
    var num=0
    $('#lt').click(function(){
        $('#coll1').css({'transform':'translateX(-980px)','transition':'0.5s'})

    })

    $('#gt').click(function(){
        $('#coll1').css({'transform':'translateX(0px)','transition':'0.5s'})

    })
})