<?php
include 'admintm.php';
if($adminrow['admin_qx_lm'] != 1){
    exit("您没有该页面的权限！");
}
?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title>Table</title>
		<link rel="stylesheet" href="plugins/layui/css/layui.css" media="all" />
		<link rel="stylesheet" href="css/global.css" media="all">
		<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/table.css" />
	</head>

	<body>
		<div class="admin-main">

			<blockquote class="layui-elem-quote">
				<a href="javascript:;" 	class="layui-btn layui-btn-lg" id="add">
					<i class="layui-icon">&#xe608;</i> 添加栏目
				</a>
				<a href="javascript: location.reload();"  class="layui-btn layui-btn-normal" >
					<i class="layui-icon">&#x1002;</i>  刷新页面
				</a>
                            <a onclick="createcache_lm()" class="layui-btn layui-btn-sm layui-btn-danger">
					<i class="layui-icon">&#xe62c;</i> 生成缓存文件
				</a>
				
			</blockquote>
			<fieldset class="layui-elem-field">
				<legend>栏目列表    <a href="javascript: location.reload();"  class="layui-btn layui-btn-primary layui-btn-mini" ><i class="layui-icon">&#x1002;</i>  刷新</a></legend>
				<div class="layui-field-box">
					<table class="site-table table-hover">
						<thead>
							<tr>
							<th>顶级</th>
								<th>栏目ID</th>
								<th>栏目名称</th>
								<th>栏目标识</th>
								<th>页面类型</th>
                                                                <th>页面模板</th>
								<th>排序值</th>
                                                                <th>状态</th>
								
								<th>操作</th>
							</tr>
						</thead>
						<tbody>
                                                    
                                                    <?php
                                                    $sql = "select * from tm_lanmulist where lm_parent is null or lm_parent = 0";
                                                    $rs = $DB->query($sql);
                                                    while ($row = $rs->fetch()){
                                                        ?>
                                                            <tr>
								<td style="text-align:center;">
                                                                    <?php
                                                                    if($row['lm_parent'] == null || $row['lm_parent'] == 0){
                                                                        echo '   <i class="layui-icon" style="color:green;"></i>';
                                                                    }
                                                                    ?>
                                                              
                                                                </td>
								<td><?=$row['lm_id']?></td>
								<td><?=$row['lm_name']?></td>
								<td><?=$row['lm_pyname']?></td>
								<td><?=pagetype($row['lm_pagetype'])?></td>
								<td><?=$row['lm_pagemodel']?></td>
								<td><?=$row['lm_sort']?></td>
								<td><?=lmstatus($row['lm_id'],$row['lm_status'])?></td>
                                                            
								
								<td>
                                                                    <a href="<?=SITE_URL?>/<?=$row['lm_pyname']?>" target="_blank" class="layui-btn layui-btn-normal layui-btn-mini">预览</a>
									<a onclick="editlm(<?=$row['lm_id']?>)" class="layui-btn layui-btn-mini">编辑</a>
                                                                        <a onclick="deletelmbyid(<?=$row['lm_id']?>)" data-id="1" data-opt="del" class="layui-btn layui-btn-danger layui-btn-mini">删除</a>
								</td>
							</tr>
                                                            <?php
                                                            
                                                            $sql = "select * from tm_lanmulist where lm_parent = ".$row['lm_id'];
                                                            $rss = $DB->query($sql);
                                                            while ($roww = $rss->fetch()){
                                                                ?>
                                                        <tr style="height: 20px;font-size: 12px;">
								<td style="text-align:right;"><i class="layui-icon">&#xe602;</i>  </td>
								<td><?=$roww['lm_id']?></td>
								<td><?=$roww['lm_name']?></td>
								<td><?=$roww['lm_pyname']?></td>
								<td><?=pagetype($roww['lm_pagetype'])?></td>
								<td><?=$roww['lm_pagemodel']?></td>
								<td><?=$roww['lm_sort']?></td>
								<td><?=lmstatus($roww['lm_id'],$roww['lm_status'])?></td>
                                                            
								
								<td>
                                                                    <a href="<?=SITE_URL?>/<?=$roww['lm_pyname']?>" target="_blank" class="layui-btn layui-btn-normal layui-btn-mini">预览</a>
									<a onclick="editlm(<?=$roww['lm_id']?>)" class="layui-btn layui-btn-mini">编辑</a>
									<a onclick="deletelmbyid(<?=$roww['lm_id']?>)"  data-id="1" data-opt="del" class="layui-btn layui-btn-danger layui-btn-mini">删除</a>
								</td>
							</tr>
                                                                    <?php
                                                            } 
                                                    }
                                                    ?>
						</tbody>
					</table>

				</div>
			</fieldset>
			<div class="admin-table-page">
				<div id="page" class="page">
				</div>
			</div>
		</div>
            <script src="layui/jquery-1.8.2.min.js"></script>
		<script type="text/javascript" src="plugins/layui/layui.js"></script>
		<script>
			layui.config({
				base: 'plugins/layui/modules/'
			});

			layui.use(['icheck', 'laypage','layer'], function() {
				var $ = layui.jquery,
					laypage = layui.laypage,
					layer = parent.layer === undefined ? layui.layer : parent.layer;
				$('input').iCheck({
					checkboxClass: 'icheckbox_flat-green'
				});

				

				

				$('#add').on('click', function() {
                                                       layer.open({
                                                                    type: 2,
                                                                    title: '增加栏目',
                                                                    shadeClose: true,
                                                                    shade: false,
                                                                    maxmin: true, //开启最大化最小化按钮
                                                                    area: ['893px', '600px'],
                                                                    content: 'temp/lmmanage.php',
                                                                    end: function () {
                                                                        location.reload();
                                                                  }
                                                      });
                                   
                                   
				});


				$('.site-table tbody tr').on('click', function(event) {
					var $this = $(this);
					var $input = $this.children('td').eq(0).find('input');
					$input.on('ifChecked', function(e) {
						$this.css('background-color', '#EEEEEE');
					});
					$input.on('ifUnchecked', function(e) {
						$this.removeAttr('style');
					});
					$input.iCheck('toggle');
				}).find('input').each(function() {
					var $this = $(this);
					$this.on('ifChecked', function(e) {
						$this.parents('tr').css('background-color', '#EEEEEE');
					});
					$this.on('ifUnchecked', function(e) {
						$this.parents('tr').removeAttr('style');
					});
				});
				$('#selected-all').on('ifChanged', function(event) {
					var $input = $('.site-table tbody tr td').find('input');
					$input.iCheck(event.currentTarget.checked ? 'check' : 'uncheck');
				});
			});
                        
                        function createcache_lm(){
                           var ii = layer.load(2, {shade:[0.1,'#fff']});
                            $.ajax({
                                    type : "POST",
                                    url : "ajax.php?act=createcache",
                                    data : {},
                                    dataType : 'json',
                                    success : function(data) {
                                         layer.close(ii);
                                         layer.msg(data.msg);
                                      
                                            
                                    },
                                    error:function(data){
                                             layer.close(ii);
                                            layer.msg('服务器错误');
                                            return;
                                            }
                            });

                        }
                        function editlm(id){
                               layer.open({
                                            type: 2,
                                            title: '编辑栏目',
                                            shadeClose: true,
                                            shade: false,
                                            maxmin: true, //开启最大化最小化按钮
                                            area: ['90%', '90%'],
                                            content: 'temp/lmmanage.php?id='+id,
                                            end: function () {
                                                location.reload();
                                          }
                              });
                        }
                        function deletelmbyid(id){
                            if(!confirm('你确定要删除该栏目吗？')){
                                return false;
                            }
                            var ii = layer.load(2, {shade:[0.1,'#fff']});
                            $.ajax({
                                    type : "POST",
                                    url : "ajax.php?act=deletelmbyid",
                                    data : {"id":id},
                                    dataType : 'json',
                                    success : function(data) {
                                         layer.close(ii);
                                         layer.msg(data.msg);
                                         if(data.code == 1){
                                                location.reload();
                                         }
                                            
                                    },
                                    error:function(data){
                                             layer.close(ii);
                                            layer.msg('服务器错误');
                                            return;
                                            }
                            });


                        }
                        
                        function lmstatusqh(id,sta){
                             var ii = layer.load(2, {shade:[0.1,'#fff']});
                             $.ajax({
                                    type : "POST",
                                    url : "ajax.php?act=lmstatusqh",
                                    data : {"id":id,"sta":sta},
                                    dataType : 'json',
                                    success : function(data) {
                                         layer.close(ii);
                                         layer.msg(data.msg);
                                         if(data.code == 1){
                                                location.reload();
                                         }
                                            
                                    },
                                    error:function(data){
                                             layer.close(ii);
                                            layer.msg('服务器错误');
                                            return;
                                            }
                            });
                        }
		</script>
	</body>

</html>