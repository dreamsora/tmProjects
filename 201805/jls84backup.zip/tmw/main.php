<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title></title>
		<link rel="stylesheet" href="plugins/layui/css/layui.css" media="all" />
		<link rel="stylesheet" href="css/main.css" />
	</head>

	<body>
		<div class="admin-main">
			<blockquote class="layui-elem-quote">
				
				<p>拓谋网络 www.tuomou.com</p>
                                <p>xxxxx.</p>
				
			</blockquote>
			<!-- <fieldset class="layui-elem-field">
				<legend>更新日志</legend>
				<div class="layui-field-box">
					
					<fieldset class="layui-elem-field layui-field-title">
						<legend>拓谋CMS - 版本号:# v1.1.1 2018-04-12~2018-05-12</legend>
						<div class="layui-field-box">
                                                    
                                                    
							<p>1、首页伪静态 + 缓存文件</p>
							<p>2、独立的tm标签使用</p>
							<p>3、开源CMS系统 非二开程序</p>
							<p>4、文章系统 栏目管理 文章管理</p>
                                                        <p>5、</p>
						</div>
					</fieldset>
                                    <fieldset class="layui-elem-field layui-field-title">
						<legend>本程序可能包括但不限于BUG</legend>
						<div class="layui-field-box">
                                                    
                                                    
							<p>1、标签不兼容,标签无法识别解析</p>
							<p>2、模板生成有误,模板路径有误</p>
							<p>3、图片无法上传，附件无法上传</p>
							<p>4、程序安全问题</p>
						</div>
					</fieldset>
				</div>
			</fieldset> -->
		</div>
	</body>

</html>