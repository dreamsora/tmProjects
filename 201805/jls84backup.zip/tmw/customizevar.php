<?php
include 'admintm.php';
if($adminrow['admin_qx_system'] != 1){
    exit("您没有该页面的权限！");
}

if(!empty($_GET['act']) && $_GET['act'] == 'edit'){
    $id = intval($_GET['id']);
    //$var_name = daddslashes($_POST['var_name']);
   // $var_key = daddslashes($_POST['var_key']);
    $var_value = daddslashes($_POST['var_value']);
    $sql = "update tm_customizevar set var_value ='$var_value' where var_id =".$id;
     if($DB->exec($sql)){
        exit('<script>alert("修改变量成功！");window.location.href="customizevar.php";</script>');
    }else{
        exit('<script>alert("修改变量失败！");window.history.go(-1);</script>');
    }
    
}elseif(!empty($_GET['act']) && $_GET['act'] == "add"){
    $var_name = daddslashes($_POST['var_name']);
    $var_key = daddslashes($_POST['var_key']);
    $var_value = daddslashes($_POST['var_value']);
    $sql = "insert into tm_customizevar(var_name,var_key,var_value) values('$var_name','$var_key','$var_value')";
    if($DB->exec($sql)){
          exit('<script>alert("添加变量成功！");window.location.href="customizevar.php";</script>');
    }else{
        exit('<script>alert("添加变量失败！");window.history.go(-1);</script>');
    }
    
    
}

?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title>Table</title>
		<link rel="stylesheet" href="plugins/layui/css/layui.css" media="all" />
		<link rel="stylesheet" href="css/global.css" media="all">
		<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/table.css" />
	</head>

	<body>
		<div class="admin-main">

			<fieldset class="layui-elem-field">
				<legend>自定义变量列表    <a href="javascript: location.reload();"  class="layui-btn layui-btn-primary layui-btn-mini" ><i class="layui-icon">&#x1002;</i>  刷新</a></legend>
				<div class="layui-field-box">
					<table class="site-table table-hover">
						<thead>
							<tr>
						
								<th>变量ID</th>
								<th>变量名称</th>
								<th>变量KEY</th>
								<th>变量值</th>
                                                                
								
								<th>操作</th>
							</tr>
						</thead>
						<tbody>
                                                    
                                                    <?php
                                                    $sql = "select * from tm_customizevar";
                                                    $rs = $DB->query($sql);
                                                    while ($row = $rs->fetch()){
                                                        ?>
                                                            <tr>
                                                <form action="?act=edit&id=<?=$row['var_id']?>" method="POST">
								
                                                    <td><input type="text" name="var_id" value="<?=$row['var_id']?>" disabled /></td>
                                                          <td ><input  type="text" name="var_name" value="<?=$row['var_name']?>" /></td>
                                                                <td><input type="text" name="var_key" value="<?=$row['var_key']?>" /><br>对应标签名：{tm:zdy.<?=$row['var_key']?>/}</td>
                                                   
                                                                <td><textarea rows="3" name="var_value"><?=$row['var_value']?></textarea></td>
                                                            
								
								<td>
                                                                    
                                                                    <input type="submit" value="修改保存"  class="layui-btn layui-btn-normal layui-btn-mini">
                                                                   <a onclick="deletevarbyid(<?=$row['var_id']?>)" data-id="1" data-opt="del" class="layui-btn layui-btn-danger layui-btn-mini">删除</a>
								</td>
						</form>	
                                                </tr>
                                                            <?php
                                                     
                                                    }
                                                    ?>
                                                <tr style="border: 1px salmon solid;">
                                                <form action="?act=add" method="POST">
								
                                                    <td>输入变量信息：</td>
                                                          <td ><input  type="text" name="var_name" value="" /></td>
                                                                <td><input type="text" name="var_key" value="" /></td>
                                                   
                                                                <td><textarea rows="3" name="var_value"></textarea></td>
                                                            
								
								<td>
                                                                    
                                                                    <input type="submit" value="添加变量"  class="layui-btn layui-btn-normal layui-btn-mini">
                                                              </td>
						</form>	
                                                </tr>
						</tbody>
					</table>

				</div>
			</fieldset>
			<div class="admin-table-page">
				<div id="page" class="page">
				</div>
			</div>
		</div>
            <script src="layui/jquery-1.8.2.min.js"></script>
		<script type="text/javascript" src="plugins/layui/layui.js"></script>
		<script>
			layui.config({
				base: 'plugins/layui/modules/'
			});
                        layui.use(['icheck', 'laypage','layer'], function() {
				var $ = layui.jquery,
					laypage = layui.laypage,
					layer = parent.layer === undefined ? layui.layer : parent.layer;
				$('input').iCheck({
					checkboxClass: 'icheckbox_flat-green'
				});
                                
                                
                            })
			function deletevarbyid(id){
                         
                             var ii = layer.load(2, {shade:[0.1,'#fff']});
                           
                             $.ajax({
                                    type : "POST",
                                    url : "ajax.php?act=deletevarbyid",
                                    data : {"id":id},
                                    dataType : 'json',
                                    success : function(data) {
                                         layer.close(ii);
                                         layer.msg(data.msg);
                                         if(data.code == 1){
                                                location.reload();
                                         }
                                            
                                    },
                                    error:function(data){
                                             layer.close(ii);
                                            layer.msg('服务器错误');
                                            return;
                                            }
                            });
                        }
                 
		</script>
	</body>

</html>