<?php

include 'admintm.php';

$act = !empty($_GET['act'])?$_GET['act']:null;


switch ($act){
    case 'deletelmbyid':
        $id = intval($_POST['id']);
        $sql = "delete from tm_lanmulist where lm_id =".$id;
        if($DB->exec($sql)){
            exit('{"code":1,"msg":"删除成功！"}');
        }else{
            exit('{"code":-1,"msg":"删除失败！"}');
        }
      break;
    case 'deleteartcbyid':
        $id = intval($_POST['id']);
        $sql = "delete from tm_article_list where article_id =".$id;
        if($DB->exec($sql)){
            exit('{"code":1,"msg":"删除成功！"}');
        }else{
            exit('{"code":-1,"msg":"删除失败！"}');
        }
        break;
    case 'deletesildesbyid':
        $id = intval($_POST['id']);
        $sql = "delete from tm_slides where id =".$id;
        if($DB->exec($sql)){
            exit('{"code":1,"msg":"删除成功！"}');
        }else{
            exit('{"code":-1,"msg":"删除失败！"}');
        }
        break;
    case 'deletebpsql':
        $filepath = $_POST['filepath'];
        $path = ROOT."beifen/".$filepath;
        if(!file_exists($path)){
              exit('{"code":-1,"msg":"删除失败,文件不存在！"}');
        }
        if(unlink($path)){
            exit('{"code":1,"msg":"删除成功！"}');
        }else{
            exit('{"code":-1,"msg":"文件删除失败！"}');
        }
        break;
    case 'deleteadminbyid':
        $id = intval($_POST['id']);
        $sql = "delete from tm_admin where admin_id =".$id;
        if($DB->exec($sql)){
            exit('{"code":1,"msg":"删除成功！"}');
        }else{
            exit('{"code":-1,"msg":"删除失败！"}');
        }
        break;
    case 'deletevarbyid':
        $id = intval($_POST['id']);
        $sql = "delete from tm_customizevar where var_id =".$id;
        if($DB->exec($sql)){
            exit('{"code":1,"msg":"删除成功！"}');
        }else{
            exit('{"code":-1,"msg":"删除失败！"}');
        }
        break;
    case 'lmstatusqh':
        $id = intval($_POST['id']);
        $sta = intval($_POST['sta']);    
        $sql = "update tm_lanmulist set lm_status = $sta  where lm_id =".$id;
        if($DB->exec($sql)){
            exit('{"code":1,"msg":"切换栏目状态成功！"}');
        }else{
            exit('{"code":-1,"msg":"切换栏目状态失败！"}');
        }
        break;
    case 'articlestatusqh':
        $id = intval($_POST['id']);
        $sta = intval($_POST['sta']);    
        $sql = "update tm_article_list set artice_status = $sta  where article_id =".$id;
        if($DB->exec($sql)){
            exit('{"code":1,"msg":"切换文章状态成功！"}');
        }else{
            exit('{"code":-1,"msg":"切换文章状态失败！"}');
        }
        break;
    case 'createcache':
        deldir(ROOT."cache/");
        unlink(ROOT."tmphp/init.lock");
         unlink(ROOT."tmphp/articleinit.lock");
        file_get_contents(SITE_URL);
         exit('{"code":1,"msg":"操作完成！"}');
        break;
    case 'getarticlezdyzd_kv':
        $articlezdyzd_id = intval($_POST['articlezdyzd_id']);
        $sql = "select * from tm_articlezdyzd where articlezdyzd_id = ".$articlezdyzd_id;
        $row = $DB->query($sql)->fetch();
        if($row){
            exit('{"code":1,"msg":"获取成功","data":"'.$row['articlezdyzd_kv'].'"}');
        }else{
                exit('{"code":-1,"msg":"没有获取到数据！"}');
        }
        
        break;
    case 'deletezd':
        $zd = $_POST['zd'];
        $frm = $_POST['frm'];
        $sql = 'alter table `'.$frm.'` drop column '.$zd;
        if($DB->query($sql)){
            exit('{"code":1,"msg":"删除成功！"}');
        }else{
            exit('{"code":-1,"msg":"删除失败！"}');
        }
        break;
    case 'deletefrm':
        $id = intval($_POST['id']);
        $sql = "select frm_frmname from tm_form where frm_id = ".$id ." limit 1";
        $row = $DB->query($sql)->fetch();
        $biao = $row['frm_frmname'];
        $sql = "drop  table ".$biao;
        if($DB->query($sql)){
            $DB->query("delete from tm_form where frm_id = ".$id );
            exit('{"code":1,"msg":"删除成功！"}');
        }else{
            exit('{"code":-1,"msg":"删除失败！"}');
        }
        break;
        
    case 'setfrm':
        $val = $_POST['frm'];
        if(!empty($_SESSION['cfrm'])) unset($_SESSION['cfrm']);
        $_SESSION['cfrm'] = $val;
        if($_SESSION['cfrm'] == $val){
            exit('{"code":1,"msg":"设置成功！"}');
        }else{
            exit('{"code":-1,"msg":"设置失败！"}');
        }
        break;
    case 'detfrmly':
        $frm = daddslashes($_POST['frm']);
        $id = intval($_POST['id']);
        $sql = "delete from $frm where id =".$id;
        if($DB->query($sql)){
             exit('{"code":1,"msg":"删除成功！"}');
        }else{
            exit('{"code":-1,"msg":"删除失败！"}');
        }
        break;
    case 'setmb':
        $filename = daddslashes($_POST['filename']);
        $path = ROOT."templets/".$filename;
        if(is_dir($path)){
            $sql = "update tm_config_webinfo set v = '$filename' where k ='webtp'";
            if($DB->query($sql)){
                exit('{"code":1,"msg":"设置模板成功！"}');
            }else{
                exit('{"code":-1,"msg":"模板设置失败！"}');
            }
        }else{
            exit('{"code":1,"msg":"不存在"}');
        }
        break;
   
    default :exit('{"code":-9,"msg":"Not Act!"}');
}

?>
