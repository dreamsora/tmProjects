<?php
include 'admintm.php';
if($adminrow['admin_qx_web'] != 1){
    exit("您没有该页面的权限！");
}

if(!empty($_GET['act']) && $_GET['act'] == "edit_logo"){
    foreach ($_POST as $k => $value) {
        if($k == "logo"){
            $value=daddslashes($value);
        $DB->query("insert into tm_config_webinfo set `k`='logo',`v`='{$value}' on duplicate key update `v`='{$value}'");
        }
        
    }

    exit('<script>alert("修改成功！");window.location.href="imagesmanage.php?act=logo";</script>');
}
?>

<!DOCTYPE html>
<html>

	<head>
		<meta charset="utf-8">
		<title>表单</title>
		<meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="format-detection" content="telephone=no">

		<link rel="stylesheet" href="plugins/layui/css/layui.css" media="all" />
		<link rel="stylesheet" type="text/css" href="http://www.jq22.com/jquery/font-awesome.4.6.0.css">
	</head>

	<body>
		<div style="margin: 15px;">
			

                        <?php
                        if(!empty($_GET['act']) && $_GET['act'] == "slides"){
                       
                            ?>
                     
                          	<fieldset class="layui-elem-field">
                                    <legend>幻灯片管理　
                                        <a class="layui-btn layui-btn-small" style="background-color: red;" id="add">添加一个幻灯片</a>
                                        <a href="javascript: location.reload();"  class="layui-btn layui-btn-primary layui-btn-mini" ><i class="layui-icon">&#x1002;</i>  刷新</a>
                                    </legend>
				<div class="layui-field-box">
					<table class="layui-table">
						<thead>
							<tr>
								<th>幻灯片ID</th>
								<th>幻灯片名称</th>
								<th>幻灯片地址</th>
								<th>幻灯片链接</th>
                                                                <th>打开方式</th>
                                                                <th>排序值</th>
                                                                <th>操作</th>
							</tr>
						</thead>
						<tbody>
                                                    <?php
                                                    $sql = "select * from tm_slides ";
                                                    $rs = $DB->query($sql);
                                                    while ($row = $rs->fetch()){
                                                        ?>
                                                      <tr>
								<td style="text-align: center;"><?=$row['id']?></td>
								<td style="text-align: center;"><?=$row['slides_name']?></td>
								<td style="text-align: center;"><?=$row['slides_images']?></td>
								<td><?=$row['slides_url']?></td>
                                                                <td><?=$row['slides_target']?></td>
                                                                <td><?=$row['slides_sort']?></td>
                                                               <td>
                                                                   <a onclick="show('<?=ARTICLE_IMG_PATH.$row['slides_images']?>')"  class="layui-btn layui-btn-normal layui-btn-mini">预览</a>
									<a onclick="editsildes(<?=$row['id']?>)" class="layui-btn layui-btn-mini">编辑</a>
                                                                        <a onclick="deletesildesbyid(<?=$row['id']?>)"  data-id="1" data-opt="del" class="layui-btn layui-btn-danger layui-btn-mini">删除</a>
								</td>
							</tr>     
                                                        <?php
                                                    }
                                                    ?>
							
						
						</tbody>
					</table>
				</div>
			</fieldset>

                             <?php
                        }elseif(!empty($_GET['act']) && $_GET['act'] == "logo"){
                            ?>
                    
                     <fieldset class="layui-elem-field">
                                    <legend>LOGO上传(推荐尺寸：230*100)  
                                        <a href="javascript: location.reload();"  class="layui-btn layui-btn-primary layui-btn-mini" ><i class="layui-icon">&#x1002;</i>  刷新</a></legend>
                                    <div class="layui-field-box">
                                        <form method="POST" action="?act=edit_logo" class="layui-form" style="margin-top: 10px;display: block;">
                                           <div class="layui-form-item">
		<label class="layui-form-label">文章缩略图</label>
		<div class="layui-input-block" style="width: 80%;">
	 <div class="layui-upload">
           <button type="button" class="layui-btn" id="test1">上传图片</button>
           <div class="layui-upload-list">
               <img class="layui-upload-img" id="demo1" src="<?=LOGO_IMG_PATH.$webinfo_conf['logo']?>" alt="暂无图片" style="width: 80px; height: 80px;">
             <p id="demoText"></p>
             <input type="text" name='logo' value="<?=$row['logo']?>" id='logo'> * 如果图片过大,请将图片上传到upload/logo/文件夹下面 然后把图片名称填在此处
           </div>
         </div> 
		</div>
	</div>
                                            
                                            <div class="layui-form-item">
		<div class="layui-input-block">
                    <button type="submit" class="layui-btn" lay-submit >保存修改</button>
			<button type="reset" class="layui-btn layui-btn-primary">重置</button>
		</div>
	</div>
     
                         </form>           </div>
                     </fieldset>
                    
                         <fieldset class="layui-elem-field">
                                    <legend>LOGO预览</legend>
				<div class="layui-field-box">
                                  
                                    <fieldset class="layui-elem-field" style="width: 230px;display: inline-block;border: 1px solid red">
                                        <legend style="color:red;">当前使用</legend>
                                            <div class="layui-field">
                                                <img src="<?=LOGO_IMG_PATH?><?=$webinfo_conf['logo']?>" width="230" height="100">

                                            </div>
                                    </fieldset>
                                    
                                    <?php
                                    
                                    $handle = opendir(LOGO_DIR_PATH);
                                    if($handle){
                                        $i = 1;
                                       while(($fl = readdir($handle)) !== false && $i <= 4){
                                            $temp = $dir.DIRECTORY_SEPARATOR.$fl;
                                            if(is_dir($temp) && $fl!='.' && $fl != '..'){
                                                break;
                                            }else{
                                                if($fl!='.' && $fl != '..'){
                                                   // echo "\\".$temp.'---'."\\".$webinfo_conf['logo'];
                                                    if($temp == "\\".$webinfo_conf['logo']){
                                                        continue;
                                                    }       
                                                    $i++;
                                                   ?>
                                    <fieldset class="layui-elem-field" onclick="selectlogo('<?=$temp?>')" style="width: 230px;display: inline-block;cursor: pointer;">
                                        <legend style="color:gray;">历史使用</legend>
                                            <div class="layui-field">
                                                <img src="<?=LOGO_IMG_PATH?><?=$temp?>" width="230" height="100">

                                            </div>
                                    </fieldset>
                                                       <?php
                                                }
                                            }
                                        }
                                    }
                                    
                                    ?>
                                    
                                    
				</div>
			</fieldset>
                            <?php
                        }
                        
                        ?>
				
			
		</div>
            
            <div id="slidess" class="hide" ><img id="slidessrc" src=""></div>     
            
                         
<script src="layui/layui.js"></script>
<script src="layui/jquery-1.8.2.min.js"></script>
                
		<script>
                    function show(src){
                        $("#slidessrc").attr("src",src);
                        layer.open({
                            type: 1,
                            title: false,
                            closeBtn: 0,
                            area: '516px',
                            skin: 'layui-layer-nobg', //没有背景色
                            shadeClose: true,
                            content: $('#slidess'),
                            end:function(){
                                $('#slidess').hide();
                            }
                      });
                   /// $('#slidess').hide();
                 }
			layui.use(['form', 'layedit', 'laydate'], function() {
				var form = layui.form(),
					layer = layui.layer,
					layedit = layui.layedit,
					laydate = layui.laydate;

			
				
			});
                        
                        $('#add').on('click', function() {
                                layer.open({
                                             type: 2,
                                             title: '增加幻灯片',
                                             shadeClose: true,
                                             shade: false,
                                             maxmin: true, //开启最大化最小化按钮
                                             area: ['893px', '600px'],
                                             content: 'temp/slidesmanage.php',
                                             end: function () {
                                                 location.reload();
                                           }
                               }); 
			});
                      function deletesildesbyid(id){
                            if(!confirm('你确定要删除该幻灯片吗？')){
                                return false;
                            }
                            var ii = layer.load(2, {shade:[0.1,'#fff']});
                            $.ajax({
                                    type : "POST",
                                    url : "ajax.php?act=deletesildesbyid",
                                    data : {"id":id},
                                    dataType : 'json',
                                    success : function(data) {
                                         layer.close(ii);
                                         layer.msg(data.msg);
                                         if(data.code == 1){
                                                location.reload();
                                         }
                                            
                                    },
                                    error:function(data){
                                             layer.close(ii);
                                            layer.msg('服务器错误');
                                            return;
                                            }
                            });
                      }
                      var logopath = '<?=LOGO_IMG_PATH?>';
                      function selectlogo(src){
                          $("#logo").val(src);
                          $("#demo1").attr("src",logopath+src);
                         // alert(src);
                      }
                      function editsildes(id){
                             layer.open({
                                        type: 2,
                                        title: '修改幻灯片',
                                        shadeClose: true,
                                        shade: false,
                                        maxmin: true, //开启最大化最小化按钮
                                        area: ['893px', '600px'],
                                        content: 'temp/slidesmanage.php?id='+id,
                                        end: function () {
                                            location.reload();
                                      }
                               }); 
                      }
                      
                      
layui.use('upload', function(){

  var $ = layui.jquery
  ,upload = layui.upload;
  
  //普通图片上传
  var uploadInst = upload.render({
    elem: '#test1'
    ,url: '/upload/logo.php'
    ,size:2048
    ,before: function(obj){
      //预读本地文件示例，不支持ie8
      obj.preview(function(index, file, result){
        $('#demo1').attr('src', result); //图片链接（base64）
      });
    }
    ,done: function(res){
      //如果上传失败
      if(res.code > 0){
        return layer.msg('上传失败');
      }
      //上传成功
      $("#logo").val(res.data.src);
      //alert($("#article_images").val());
    }
    ,error: function(){
      //演示失败状态，并实现重传
      var demoText = $('#demoText');
      demoText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-mini demo-reload">重试</a>');
      demoText.find('.demo-reload').on('click', function(){
        uploadInst.upload();
      });
    }
  });
 });
		</script>
	</body>

</html>