<?php
error_reporting(0);
define('SYSTEM_ROOT', dirname(__FILE__).'/');//当前文件路径
define('ROOT', dirname(SYSTEM_ROOT).'/');//上级根目录
date_default_timezone_set('Asia/Shanghai');
session_start();

//数据库配置文件是否存在
if(!file_exists(ROOT.'tmphp/database.php')){
    //数据库配置文件不存在
    exit("未安装");
}
$loginerr = 1;
$data = require ROOT.'/tmphp/database.php'; //加载数据库配置文件

//数据库是否已配置
if($data['db_name'] == '' || $data['db_user'] == '' || $data['db_host'] == ''){
    exit("请先配置数据库文件");
}
$dsn="mysql:host=".$data['db_host'].";dbname=".$data['db_name'];
try {
    $DB = new PDO($dsn, $data['db_user'], $data['db_pwd']); //初始化一个PDO对象
} catch (PDOException $e) {
    die ("Error!: " . $e->getMessage() . "<br/>");
}
$DB->exec("set names utf8");
include ROOT.'tmphp/function/function.php';

require ROOT.'tmphp/class/system.class.php';
$webinfo_conf= system::webinfoquery(); //获取网站配置信息

$ret = system::query('tm_config_webinfo',"k = 'webtp'");


//主机协议 https || http
define('SERVER_PORT', isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://');
//当前访问的主机名 www.xxx.com
define('HTTP_HOST', (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : ''));
//程序URL地址 http://www.05.com/     
define('SITE_URL', SERVER_PORT.HTTP_HOST);

define("ARTICLE_IMG_PATH", SITE_URL."/upload/img/");
define("LOGO_IMG_PATH", SITE_URL."/upload/logo/");
define("LOGO_DIR_PATH", ROOT."/upload/logo/");
define("TEMPETS_PATH", ROOT."templets/".$ret['webtp']."/");//当前模板路径
define("TEMPETS_URL", SITE_URL."/templets/".$ret['webtp']."/");//当前模板路径
$password_hash = md5(SITE_URL);
include ROOT.'tmw/tmyz/checklogin.php';


//exit(var_dump($adminrow));



/*
 * 页面类型
 */
function pagetype($pageid){
    if($pageid == 0){
        return "自定义页面";
    }else{
        global $DB;
        $sql = "select pt_name from tm_pagetype where pt_id =".$pageid;
        $row = $DB->query($sql)->fetch();
        if($row){
            return $row['pt_name'];
        }else{
            return "未知页面";
        }
    }    
}
/*
 * 栏目状态
 */
function lmstatus($lmid,$sta){
    if($sta == 1){
        return '<button onclick="lmstatusqh('.$lmid.',0)" class="layui-btn layui-btn-normal layui-btn-mini" title="点击隐藏">正常</button>';
    }else{
        return '<button onclick="lmstatusqh('.$lmid.',1)" class="layui-btn layui-btn-danger layui-btn-mini" title="点击显示">隐藏</button>';
    }
}
/*
 * 文章状态
 */
function articestatus($articleid,$sta){
    if($sta == 1){
        return '<button onclick="articlestatusqh('.$articleid.',0)" class="layui-btn layui-btn-normal layui-btn-mini" title="点击隐藏">正常</button>';
    }else{
        return '<button onclick="articlestatusqh('.$articleid.',1)" class="layui-btn layui-btn-danger layui-btn-mini" title="点击显示">隐藏</button>';
    }
}

function getlmnamebyid($lmid){
    global $DB;
    $sql = "select lm_name,lm_pyname from tm_lanmulist where lm_id = ".$lmid;
    $row = $DB->query($sql)->fetch();
    return $row;
}

function insert($table,$data){
    global $DB;
    foreach($data as $k => $v){
            $fields[] = $v;
            $keys[] = $k;
    }
    $values = "('".implode("','", $fields)."')";
    $column = "(`".implode("`,`", $keys)."`)";
    $sql = "insert into {$table} {$column} values {$values}";
    //exit($sql);
    $cid = $DB->exec($sql);
    return $cid;
}

/*
 * 截取指定长度的字符
 * @param $str string 待处理的字符串
 * @param $len int 截取的字符数量
 * @param $tail string 超过部分代替字符
 * return String 处理后的字符串
 */
function substr_utf8($str,$len,$tail="..."){
    if(mb_strlen($str,"utf-8") > $len){
        $rstr = mb_substr($str,0,$len,'utf-8');
        $rstr .= $tail;
    }else{
        $rstr = $str;
    }
    return $rstr;
}

/*
 * 遍历文件就下所有的文件
 * @param $dir string 文件夹名称
 * @param $fname bool 是否只返回文件名称 1：是 0：返回文件全路径
 * @param $siondir bool 是否遍历子文件夹
 * return array 文件名列表
 */
function read_all ($dir,$fname =1,$siondir = 0){
    $filelist = array();
    $filenamelist = array();
    if(!is_dir($dir)) return false;
    
    $handle = opendir($dir);

    if($handle){
        while(($fl = readdir($handle)) !== false){
            $temp = iconv('GBK','utf-8',$dir.DIRECTORY_SEPARATOR.$fl);//转换成utf-8格式
            
            if(is_dir($temp) && $fl!='.' && $fl != '..' && $siondir ==1){
              //  array_push($filelist, $temp);
                read_all($temp,1,1);
            }else{
                if($fl!='.' && $fl != '..'){
                    array_push($filelist, $temp);
                    array_push($filenamelist, $fl);
                }
            }
        }
    }
    if($fname){
        return $filenamelist;
    }else{
        return $filelist;
    }
    
}


  //清空文件夹函数和清空文件夹后删除空文件夹函数的处理
function deldir($path){
    //如果是目录则继续
    if(is_dir($path)){
         //扫描一个文件夹内的所有文件夹和文件并返回数组
        $p = scandir($path);
        foreach($p as $val){
            //排除目录中的.和..
            if($val !="." && $val !=".."){
             //如果是目录则递归子目录，继续操作
             if(is_dir($path.$val)){
                //子目录中操作删除文件夹和文件
                deldir($path.$val.'/');
                //目录清空后删除空文件夹
                @rmdir($path.$val.'/');
             }else{
                //如果是文件直接删除
                unlink($path.$val);
             }
            }
        }
   }
}