<?php
include 'admintm.php';
if($adminrow['admin_qx_system'] != 1){
    exit("您没有该页面的权限！");
}

?>

 <!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title>Table</title>
		<link rel="stylesheet" href="plugins/layui/css/layui.css" media="all" />
		<link rel="stylesheet" href="css/global.css" media="all">
		<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/table.css" />
	</head>

	<body>
		<div class="admin-main">

			<fieldset class="layui-elem-field">
				<legend>数据库备份    <a href="javascript: location.reload();"  class="layui-btn layui-btn-primary layui-btn-mini" ><i class="layui-icon">&#x1002;</i>  刷新</a></legend>
				<div class="layui-field-box">
					<table class="site-table table-hover">
						<thead>
							<tr>
						
								<th>数据库表名</th>
								<th>数据数量</th>
								
								
							</tr>
						</thead>
						<tbody>
                                                    
                                                    <?php
                                                    $rs = $DB->query("show tables from ".$data['db_name']);
                                                  //  exit("show tables from ".$data['db_name']);
                                                  //  exit(var_dump($rs->fetchAll()));
                                                    $row = $rs->fetchAll();
                                                   
                                                    foreach ($row as $tablename){
                                                        //exit("select count(*) from ".$tablename[0]);
                                                        $num = $DB->query("select count(*) from ".$tablename[0])->fetch();
                                                       // var_dump($num);
                                                        ?>
                                                            <tr>
                                               
                                                    <td ><?= $tablename[0]?></td>
                                                    <td><?=$num[0]?>条</td>
                                                   
                                                            
						
                                                </tr>
                                                            <?php
                                                     
                                                    }
                                                    ?>
                                              
						</tbody>
					</table>
                                    <blockquote class="layui-elem-quote">
                           
				
                                        <a href="temp/exebackup.php" target="_block"  class="layui-btn layui-btn-normal" >
					<i class="layui-icon">&#xe600;</i> 一键备份
				</a>
				
			</blockquote>

				</div>
			</fieldset>
                    
                    <fieldset class="layui-elem-field">
				<legend>备份文件下载    <a href="javascript: location.reload();"  class="layui-btn layui-btn-primary layui-btn-mini" ><i class="layui-icon">&#x1002;</i>  刷新</a></legend>
				<div class="layui-field-box">
					<table class="site-table table-hover">
						<thead>
							<tr>
						
								<th>文件名称</th>
								<th>写入时间</th>
								
								<th>操作</th>
								
							</tr>
						</thead>
						<tbody>
                                                    
                                                    <?php
                                                    $filelist = read_all(ROOT."beifen");
                                                    //exit(var_dump($filelist));
                                                   
                                                    foreach ($filelist as $filename){
                                                       ?>
                                                            <tr>
                                               
                                                    <td ><?= $filename?></td>
                                                    <td><?= date('Y-m-d H:i:s', filectime(ROOT."beifen/".$filename))?></td>
                                                   
                                                               
								<td>
                                                                    <a href="temp/downbackup.php?filename=<?=urldecode($filename)?>" target="_block"  class="layui-btn layui-btn-normal layui-btn-mini">下载</a>
                                                            
                                                                    <a onclick="deletebpsql('<?=$filename?>')" class="layui-btn layui-btn-danger layui-btn-mini">删除</a>
                                                                </td>
						
                                                </tr>
                                                            <?php
                                                     
                                                    }
                                                    ?>
                                              
						</tbody>
					</table>

				</div>
			</fieldset>
			
		</div>
            <script src="layui/jquery-1.8.2.min.js"></script>
		<script type="text/javascript" src="plugins/layui/layui.js"></script>
		<script>
			
			layui.config({
				base: 'plugins/layui/modules/'
			});
                        layui.use(['icheck', 'laypage','layer'], function() {
				var $ = layui.jquery,
					laypage = layui.laypage,
					layer = parent.layer === undefined ? layui.layer : parent.layer;
				$('input').iCheck({
					checkboxClass: 'icheckbox_flat-green'
				});
                                
                                
                            })
                 function deletebpsql(filepath){
                            //layer.alert("!");
                         
                             var ii = layer.load(2, {shade:[0.1,'#fff']});
                           
                             $.ajax({
                                    type : "POST",
                                    url : "ajax.php?act=deletebpsql",
                                    data : {"filepath":filepath},
                                    dataType : 'json',
                                    success : function(data) {
                                         layer.close(ii);
                                         layer.msg(data.msg);
                                         if(data.code == 1){
                                                location.reload();
                                         }
                                            
                                    },
                                    error:function(data){
                                             layer.close(ii);
                                            layer.msg('服务器错误');
                                            return;
                                            }
                            });
                        }
		</script>
	</body>

</html>