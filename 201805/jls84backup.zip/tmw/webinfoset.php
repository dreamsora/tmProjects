<?php
include 'admintm.php';
if($adminrow['admin_qx_web'] != 1){
    exit("您没有该页面的权限！");
}

if(!empty($_GET['act']) && $_GET['act'] == "submit"){
     foreach ($_POST as $k => $value) {
        if($k=='pwd')continue;
        $value=daddslashes($value);
        $DB->query("insert into tm_config_webinfo set `k`='{$k}',`v`='{$value}' on duplicate key update `v`='{$value}'");
    }

    exit('<script>alert("修改成功！"); history.go(-1);</script>');
}

?>

<!DOCTYPE html>
<html>

	<head>
		<meta charset="utf-8">
		<title>表单</title>
		<meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="format-detection" content="telephone=no">

		<link rel="stylesheet" href="plugins/layui/css/layui.css" media="all" />
		<link rel="stylesheet" type="text/css" href="http://www.jq22.com/jquery/font-awesome.4.6.0.css">
	</head>

	<body>
		<div style="margin: 15px;">
			

                    <form class="layui-form" action="?act=submit" method="POST">
                        
                        <?php
                        if(!empty($_GET['act']) && $_GET['act'] == "web"){
                       
                            ?>
                        <fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
				<legend>网站基本信息设置
                                    <a href="javascript: location.reload();"  class="layui-btn layui-btn-primary layui-btn-mini" ><i class="layui-icon">&#x1002;</i>  刷新</a>
                                </legend>
			</fieldset>
                             <div class="layui-form-item">
					<label class="layui-form-label">网站标题</label>
					<div class="layui-input-block">
                                            <input type="text" name="webname" value="<?=$webinfo_conf['webname']?>" placeholder="请输入网站标题" class="layui-input">
                                            
					</div>
				</div>
				<div class="layui-form-item">
					<label class="layui-form-label">网站关键字</label>
					<div class="layui-input-block">
                                            <input type="text" name="webkey" value="<?=$webinfo_conf['webkey']?>" placeholder="请输入网站关键字" class="layui-input">
                                            
					</div>
				</div>
                            <div class="layui-form-item">
					<label class="layui-form-label">网站描述</label>
					<div class="layui-input-block">
                                            <textarea placeholder="请输入内容"  name="webdes" class="layui-textarea"><?=$webinfo_conf['webdes']?></textarea>
                                          
					</div>
                            </div>
                          <div class="layui-form-item">
					<label class="layui-form-label">统计代码</label>
					<div class="layui-input-block">
                                            <textarea placeholder="请输入内容"  name="statisticalcode" class="layui-textarea"><?=$webinfo_conf['statisticalcode']?></textarea>
                                            
					</div>
                            </div>
                             <?php
                        }elseif(!empty($_GET['act']) && $_GET['act'] == "footer"){
                            ?>
                              <fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
				<legend>网站版权信息设置
                                    <a href="javascript: location.reload();"  class="layui-btn layui-btn-primary layui-btn-mini" ><i class="layui-icon">&#x1002;</i>  刷新</a>
                                </legend>
			</fieldset>
                             <div class="layui-form-item">
					<label class="layui-form-label">网站备案号</label>
					<div class="layui-input-block">
                                            <input type="text" name="beian" value="<?=$webinfo_conf['beian']?>" placeholder="网站备案号" class="layui-input">
                                           
					</div>
				</div>
			
                           
                          <div class="layui-form-item">
					<label class="layui-form-label">底部版权信息</label>
					<div class="layui-input-block">
                                            <textarea placeholder="请输入内容"  name="footer" class="layui-textarea"><?=$webinfo_conf['footer']?></textarea>
                                             
					</div>
                            </div>    
                            <?php
                        }elseif(!empty($_GET['act']) && $_GET['act'] == "contact"){
                            ?>
                              <fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
				<legend>网站联系方式信息设置
                                <a href="javascript: location.reload();"  class="layui-btn layui-btn-primary layui-btn-mini" ><i class="layui-icon">&#x1002;</i>  刷新</a>
                                </legend>
			</fieldset>
                             <div class="layui-form-item">
					<label class="layui-form-label">客服QQ</label>
					<div class="layui-input-block">
                                            <input type="text" name="kqqq" value="<?=$webinfo_conf['kqqq']?>" placeholder="客服QQ" class="layui-input">
                                          
					</div>
				</div>
			
                           <div class="layui-form-item">
					<label class="layui-form-label">公司电话</label>
					<div class="layui-input-block">
                                            <input type="text" name="telephone" value="<?=$webinfo_conf['telephone']?>" placeholder="公司电话" class="layui-input">
                                            
					</div>
				</div>
                        <div class="layui-form-item">
					<label class="layui-form-label">公司地址</label>
					<div class="layui-input-block">
                                               <textarea placeholder="公司地址"  name="address" class="layui-textarea"><?=$webinfo_conf['address']?></textarea>
                                              
                                        
					</div>
				</div>
                            <?php
                        }elseif(!empty($_GET['act']) && $_GET['act'] == "links"){
                            ?>
                        <fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
				<legend>友情链接设置
                                    <a href="javascript: location.reload();"  class="layui-btn layui-btn-primary layui-btn-mini" ><i class="layui-icon">&#x1002;</i>  刷新</a>
                                </legend>
			</fieldset>
                           
                        <div class="layui-form-item">
					<label class="layui-form-label">友情链接代码</label>
					<div class="layui-input-block">
                                               <textarea placeholder="友情链接"  name="flinks" class="layui-textarea"><?=$webinfo_conf['flinks']?></textarea>
					</div>
			</div>
                       
                     
                          <fieldset class="layui-elem-field">
				<legend>友情链接代码生成工具</legend>
				<div class="layui-field-box">
				  <a class="layui-btn layui-btn-primary" onclick="sclink()">生成友情链接</a>
				</div>
			</fieldset>

                     
                            <?php
                        }elseif(!empty($_GET['act']) && $_GET['act'] == "template"){
                            ?>
                              <fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
				<legend>网站模板设置
                                    <a href="javascript: location.reload();"  class="layui-btn layui-btn-primary layui-btn-mini" ><i class="layui-icon">&#x1002;</i>  刷新</a>
                                </legend>
			</fieldset>
                        <fieldset class="layui-elem-field">
                                    <legend>已安装的模板</legend>
				<div class="layui-field-box">
                                  
                                    <fieldset class="layui-elem-field" style="width: 400px;display: inline-block;border: 1px solid red;text-align: center;cursor: pointer">
                                          <?php
                                                   $json = file_get_contents(TEMPETS_URL.'templets_conf_author.json');
                                                   $json = (array)json_decode($json);
                                                   
                                                    ?>
                                        <legend style="color:red;">(当前)<?=$json['templets']?></legend>
                                            <div class="layui-field">
                                                <img src="<?=TEMPETS_URL?>templets_conf_img.png" width="80%" height="150px">
                                                <div style="text-align: left;padding-left: 20px;font-size: 18px;line-height: 1.5">
                                                  
                                                    <p>模板作者：<?=$json['author']?></p>
                                                    <p>构造时间：<?=$json['buildtime']?></p>
                                                    <p>构造版本：<?=$json['build_version']?></p>
                                                    <p>兼容CMS版本：<?=$json['compatible_version']?></p>
                                                </div>
                                            </div>
                                    </fieldset>
                                    
                                    <?php
                                    
                                    $handle = opendir(ROOT."templets/");
                                    if($handle){
                                        $i = 1;
                                       while(($fl = readdir($handle)) !== false && $i <= 4){
                                            $temp = $dir.DIRECTORY_SEPARATOR.$fl;
                                            if(is_dir($temp) && $fl!='.' && $fl != '..'){
                                                break;
                                            }else{
                                                if($fl!='.' && $fl != '..'){
                                                    if($temp == "\\".$ret['webtp']){
                                                        continue;
                                                    }       
                                                    $i++;
                                                    $json = file_get_contents(SITE_URL.'/templets/'.$temp.'/templets_conf_author.json');
                                                   $json = (array)json_decode($json);
                                                   ?>
                                    <fieldset class="layui-elem-field" onclick="settemplets('<?=$json['templets_dir']?>')" style="width: 400px;display: inline-block;border: 1px solid black;text-align: center;cursor: pointer">
                                        <legend style="color:gray;"><?=$json['templets']?></legend>
                                            <div class="layui-field">
                                                <img src="<?=SITE_URL?>/templets/<?=$temp?>/templets_conf_img.png" width="80%" height="150px">
                                                <div style="text-align: left;padding-left: 20px;font-size: 18px;line-height: 1.5">
                                                    <?php
                                                  
                                                   
                                                    ?>
                                                    <p>模板作者：<?=$json['author']?></p>
                                                    <p>构造时间：<?=$json['buildtime']?></p>
                                                    <p>构造版本：<?=$json['build_version']?></p>
                                                    <p>兼容CMS版本：<?=$json['compatible_version']?></p>
                                                </div>
                                            </div>
                                    </fieldset>
                                                       <?php
                                                }
                                            }
                                        }
                                    }
                                    
                                    ?>
                                    
                                    
				</div>
			</fieldset>
                     
                       

                     
                            <?php
                        }
                        
                        ?>
				
			

				
                        <div class="layui-form-item" style="<?=@$_GET['act']=="template"?"display:none;":""?>">
					<div class="layui-input-block">
						<button class="layui-btn" lay-submit="" lay-filter="demo1">立即提交</button>
						<button type="reset" class="layui-btn layui-btn-primary">重置</button>
                                              
					</div>
				</div>
			</form>
		</div>
		<script type="text/javascript" src="plugins/layui/layui.js"></script>
                 <script src="layui/jquery-1.8.2.min.js"></script>
		<script>
                  
			layui.use(['form', 'layedit', 'laydate'], function() {
                                        var form  = layui.form(),
					layer = layui.layer,
					layedit = layui.layedit,
                                	laydate = layui.laydate;
                                      
                         
				
			});
                        
                       
                        function sclink(){
                              window.open('../other/tool.php?action=links');
                        }
                        function settemplets(filename){
                            //alert(filename);
                             if(!confirm('你确定修改网站首页模板吗？')){
                                return false;
                            }
                             var ii = layer.load(2, {shade:[0.1,'#fff']});
                            $.ajax({
                                    type : "POST",
                                    url : "ajax.php?act=setmb",
                                    data : {"filename":filename},
                                    dataType : 'json',
                                    success : function(data) {
                                         layer.close(ii);
                                         layer.msg(data.msg);
                                         if(data.code == 1){
                                                location.reload();
                                         }
                                            
                                    },
                                    error:function(data){
                                             layer.close(ii);
                                            layer.msg('服务器错误');
                                            return;
                                            }
                            });
                            
                        }
		</script>
	</body>

</html>