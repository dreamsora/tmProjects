<?php
include 'admintm.php';
    @header('Content-Type: text/html; charset=UTF-8');
if(!empty($_GET['act']) && $_GET['act'] == "submit"){
     $admin_user = daddslashes($_POST['userName']);
     $admin_pass = daddslashes($_POST['password']);
     $vc = daddslashes($_POST['vc']);
    
     if($admin_user == "" || $admin_pass == ""){
          exit('<script>alert("登陆失败,请输入管理员账号密码！");window.history.go(-1);</script>');
     }
     if(empty($_SESSION['code']) || strtolower($_SESSION['code']) != strtolower($vc) ){
         exit('<script>alert("验证码错误！");window.history.go(-1);</script>');
     }
     $row = $DB->query("select * from tm_admin where admin_user = '{$admin_user}' limit 1")->fetch();
     if($row && $row['admin_pass'] == $admin_pass){
         unset($_SESSION['code']);
         
         /*
          * 保存登陆信息
          */
         $session=md5($admin_user.$admin_pass.$password_hash);
         $token=authcode("{$admin_user}\t{$session}", 'ENCODE', "tmwl88888888");
         setcookie("admin_token", $token, time() + 604800);
     
    
        exit("<script language='javascript'>alert('登陆管理中心成功！');window.location.href='./';</script>");
     }else{
            exit('<script>alert("账户名或密码错误！");window.location.href="login.php";</script>');
     }
     
     
      
}elseif(isset($_GET['logout'])){
	setcookie("admin_token", "", time() - 604800);
	@header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert('您已成功注销本次登陆！');window.location.href='./login.php';</script>");
}

unset($_SESSION['code']);

?>

<!DOCTYPE html>

<html>

	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<title>管理员登录</title>
		<link rel="stylesheet" href="plugins/layui/css/layui.css" media="all" />
		<link rel="stylesheet" href="css/login.css" />
	</head>

	<body class="beg-login-bg">
            <div class="beg-login-box" style="height: 400px;">
			<header>
				<h1>后台登录</h1>
			</header>
                    <div class="beg-login-main" style="height: 400px">
				<form action="?act=submit" class="layui-form" method="post">
                                    
                                    
      <input name="__RequestVerificationToken" type="hidden" value="fkfh8D89BFqTdrE2iiSdG_L781RSRtdWOH411poVUWhxzA5MzI8es07g6KPYQh9Log-xf84pIR2RIAEkOokZL3Ee3UKmX0Jc8bW8jOdhqo81" />
					<div class="layui-form-item">
						<label class="beg-login-icon">
                        <i class="layui-icon">&#xe612;</i>
                    </label>
						<input type="text" name="userName" lay-verify="userName" autocomplete="off" placeholder="这里输入登录名" class="layui-input">
					</div>
					<div class="layui-form-item">
						<label class="beg-login-icon">
                                                  <i class="layui-icon">&#xe642;</i>  
                    </label>
						<input type="password" name="password" lay-verify="password" autocomplete="off" placeholder="这里输入密码" class="layui-input">
					</div>
                       
      
      <div class="layui-form-item" >
	<label class="beg-login-icon">
           <i class="layui-icon">&#xe642;</i>  
                    </label>
		<input type="text" name="vc" lay-verify="vc" autocomplete="off" placeholder="这里输入验证码" class="layui-input">
					
                        </div>
      
      <div class="layui-form-item" style="clear: both;display: block;height:50px;margin-top: -10px;">
	<label class="beg-login-icon">
            <img src='tmyz/code.php?t=<?=time()?>' onclick="this.src='tmyz/code.php?t=<?=time()?>'" height="50px" >
                </label>
					
                        </div>
      
    
					<div class="layui-form-item">
						<div class="beg-pull-left beg-login-remember">
							<label>记住帐号？</label>
							<input type="checkbox" name="rememberMe" value="true" lay-skin="switch" checked title="记住帐号">
						</div>
						<div class="beg-pull-right">
							<button class="layui-btn layui-btn-primary" lay-submit lay-filter="login">
                            <i class="layui-icon">&#xe650;</i> 登录
                        </button>
						</div>
						<div class="beg-clear"></div>
					</div>
				</form>
			</div>
			<footer>
				<p>Beginner © </p>
			</footer>
		</div>
		<script type="text/javascript" src="plugins/layui/layui.js"></script>
               
		<script>
                     
			layui.use(['layer', 'form'], function() {
				var layer = layui.layer,
					$ = layui.jquery,
					form = layui.form();
			});
                        
                        
		</script>
	</body>

</html>
