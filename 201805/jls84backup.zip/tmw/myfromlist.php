<?php
include 'admintm.php';
if($adminrow['admin_qx_article'] != 1){
    exit("您没有该页面的权限！");

}

?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title>Table</title>
		<link rel="stylesheet" href="plugins/layui/css/layui.css" media="all" />
		<link rel="stylesheet" href="css/global.css" media="all">
		<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/table.css" />
	</head>

	<body>
		<div class="admin-main">

			<blockquote class="layui-elem-quote">
                            <a href="javascript: location.reload();"  class="layui-btn layui-btn-normal" >
					<i class="layui-icon">&#x1002;</i>  刷新页面
				</a>
                            
                               <?php
                                $tablename = !empty($_SESSION['cfrm'])?$_SESSION['cfrm']:"";
                                  if(!empty($_GET['act']) &&  $_GET['act'] == "search"){
                                      echo '<a href="?t='.time().'" 	class="layui-btn layui-btn-normal">
					<i class="layui-icon">&#xe603;</i> 显示全部列表
				</a>';
                                  }
                                  
                                  $sql = "select * from tm_form";
                                  $rs = $DB->query($sql);
                                  $option = "";
                                  $temptab = "";
                                  while ($row = $rs->fetch()){
                                      $temptab = $row['frm_frmname'];
                                      $option .= "<option value='".$row['frm_frmname']."' ".($tablename==$row['frm_frmname']?"selected":"").">".$row['frm_name']."</option>";
                                  }
                                 if($tablename == "") $tablename =$temptab;
                               ?>
                            选中要查看的表单：<select  onchange="selectjump(this.value)"><?=$option?></select>
				
                        
			</blockquote>
			<fieldset class="layui-elem-field">
				<legend>文章列表</legend>
				<div class="layui-field-box">
					<table class="site-table table-hover">
						<thead>
							<tr>
                                                              <?php
                                                               $sql = "select COLUMN_NAME,column_comment,COLUMN_TYPE from INFORMATION_SCHEMA.Columns where table_name='".$tablename."' and table_schema='".$data['db_name']."'";
                                                                $trs = $DB->query($sql);
                                                                while ($trow = $trs->fetch()){
                                                                     $t = explode("|", $trow['column_comment']);
                                                                    $showname = $t[0];//显示名称
                                                                    $htmltype = $t[1];//HTML标签类型
                                                                    echo '<td>'.$showname.'</td>';
                                                                }
                                                              ?>
                                                            <td>操作</td>
							</tr>
						</thead>
						<tbody>
                                                    
                                                    <?php
                                                    
                                                    
                                                    
                                                    $numrows = $DB->query("select count(*) from ".$tablename)->fetch();
                                                    $numrows = $numrows[0];
                                                    $pagesize=30;
                                                    $pages=intval($numrows/$pagesize);
                                                    if ($numrows%$pagesize)
                                                    {
                                                     $pages++;
                                                     }
                                                    if (isset($_GET['page'])){
                                                    $page=intval($_GET['page']);
                                                    }
                                                    else{
                                                    $page=1;
                                                    }
                                                    $offset=$pagesize*($page - 1);
                                                    if(!empty($_GET['act']) &&  $_GET['act'] == "search"){
                                                        $keys = daddslashes($_POST['keys']);
                                                        $sql = "select * from ".$tablename."   order by article_id desc";
                                                     //   exit($sql);
                                                        
                                                    }else{
                                                          $sql = "select * from ".$tablename."   order by id desc limit $offset,$pagesize";
                                                    }
                                                  
                                                    $rs = $DB->query($sql);
                                                    while ($row = $rs->fetch()){
                                                        echo '<tr>';
                                                        $ci = -1;
                                                        foreach ($row as $value) {
                                                            $ci++;
                                                            if($ci%2!=0) continue;
                                                            echo "<td>".$value."</td>";
                                                        }
                                                      
                                                    ?>
                                                      <td><a onclick="detly('<?=$tablename?>','<?=$row['id']?>')" class="layui-btn layui-btn-normal">删除</a></td>  
                                                        <?php
                                                        echo '</tr>';
                                                    }
                                                    ?>
						</tbody>
					</table>
                                   <!--   <link href="//cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>-->
                                   <style>
                                       .pagination {
  display: inline-block;
  padding-left: 0;
  margin: 20px 0;
  border-radius: 4px;
}
.pagination > li {
  display: inline;
}
.pagination > li > a,
.pagination > li > span {
  position: relative;
  float: left;
  padding: 6px 12px;
  margin-left: -1px;
  line-height: 1.42857143;
  color: #337ab7;
  text-decoration: none;
  background-color: #fff;
  border: 1px solid #ddd;
}
.pagination > li:first-child > a,
.pagination > li:first-child > span {
  margin-left: 0;
  border-top-left-radius: 4px;
  border-bottom-left-radius: 4px;
}
.pagination > li:last-child > a,
.pagination > li:last-child > span {
  border-top-right-radius: 4px;
  border-bottom-right-radius: 4px;
}
                                   </style>
                                    <?php
  if(empty($_GET['act'])){
 echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
$link = "";
//首页按钮控制
if ($page>1)
{
echo '<li><a href="?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
//从第一页页到当前页-1
for ($i=1;$i<$page;$i++){
    if($page-3<$i){
        echo '<li><a href="?page='.$i.$link.'">'.$i .'</a></li>';
    }
        
}
//当前页不可点击
echo '<li class="disabled"><a>'.$page.'</a></li>';

//从当前页+1到最后一页
for ($i=$page+1;$i<=$pages;$i++){
    if($page +3 >= $i){
        echo '<li><a href="?page='.$i.$link.'">'.$i .'</a></li>';
    }
    
}
echo '';
//尾页按钮控制
if ($page<$pages)
{
echo '<li><a href="?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
  }                                    
 
                                    ?>

				</div>
			</fieldset>
                    <form method="POST" action="?act=search" id="searchfrm">
                        <input type="hidden" name="keys" id="keys">
                        <input type="submit"id="subbtn" style="display: none;">
                    </form>
		</div>
            <script src="layui/jquery-1.8.2.min.js"></script>
		<script type="text/javascript" src="plugins/layui/layui.js"></script>
               
		<script>
                    function detly(t,i){
                    
                         var ii = layer.load(2, {shade:[0.1,'#fff']});
                            $.ajax({
                                    type : "POST",
                                    url : "ajax.php?act=detfrmly",
                                    data : {"frm":t,"id":i},
                                    dataType : 'json',
                                    success : function(data) {
                                         layer.close(ii);
                                         layer.msg(data.msg);
                                         if(data.code == 1){
                                             location.reload();
                                         }
                                            
                                    },
                                    error:function(data){
                                             layer.close(ii);
                                            layer.msg('服务器错误');
                                            return;
                                            }
                            });
                    }
                    function selectjump(val){
                          var ii = layer.load(2, {shade:[0.1,'#fff']});
                            $.ajax({
                                    type : "POST",
                                    url : "ajax.php?act=setfrm",
                                    data : {"frm":val},
                                    dataType : 'json',
                                    success : function(data) {
                                         layer.close(ii);
                                         if(data.code == 1){
                                             location.reload();
                                         }
                                            
                                    },
                                    error:function(data){
                                             layer.close(ii);
                                            layer.msg('服务器错误');
                                            return;
                                            }
                            });
                    }
                  
			layui.config({
				base: 'plugins/layui/modules/'
			});

			layui.use(['icheck', 'laypage','layer'], function() {
				var $ = layui.jquery,
					laypage = layui.laypage,
					layer = parent.layer === undefined ? layui.layer : parent.layer;
				$('input').iCheck({
					checkboxClass: 'icheckbox_flat-green'
				});

				
                                $("#addzdyzd").on('click',function(){
                                 
                                      layer.open({
                                                                    type: 2,
                                                                    title: '添加文章自定义字段',
                                                                    shadeClose: true,
                                                                    shade: false,
                                                                    maxmin: true, //开启最大化最小化按钮
                                                                    area: ['70%', '80%'],
                                                                    content: 'temp/articlezdyzd.php',
                                                                    end: function () {
                                                                        location.reload();
                                                                  }
                                                      });
                                })
				

				$('#add').on('click', function() {
                                                      var index = layer.open({
                                                                    type: 2,
                                                                    title: '添加文章',
                                                                    shadeClose: true,
                                                                    shade: false,
                                                                    
                                                                    maxmin: true, //开启最大化最小化按钮
                                                                    area: ['50%', '50%'],
                                                                    content: 'temp/articlemanage.php',
                                                                    end: function () {
                                                                        location.reload();
                                                                  }
                                                      });
                                                   layer.full(index);
                                   
				});


				$('.site-table tbody tr').on('click', function(event) {
					var $this = $(this);
					var $input = $this.children('td').eq(0).find('input');
					$input.on('ifChecked', function(e) {
						$this.css('background-color', '#EEEEEE');
					});
					$input.on('ifUnchecked', function(e) {
						$this.removeAttr('style');
					});
					$input.iCheck('toggle');
				}).find('input').each(function() {
					var $this = $(this);
					$this.on('ifChecked', function(e) {
						$this.parents('tr').css('background-color', '#EEEEEE');
					});
					$this.on('ifUnchecked', function(e) {
						$this.parents('tr').removeAttr('style');
					});
				});
				$('#selected-all').on('ifChanged', function(event) {
					var $input = $('.site-table tbody tr td').find('input');
					$input.iCheck(event.currentTarget.checked ? 'check' : 'uncheck');
				});
			});
                        
                        function createcache_article(){
                            var ii = layer.load(2, {shade:[0.1,'#fff']});
                            $.ajax({
                                    type : "POST",
                                    url : "ajax.php?act=createcache",
                                    data : {},
                                    dataType : 'json',
                                    success : function(data) {
                                         layer.close(ii);
                                         layer.msg(data.msg);
                                      
                                            
                                    },
                                    error:function(data){
                                             layer.close(ii);
                                            layer.msg('服务器错误');
                                            return;
                                            }
                            });

                        }
                        function editarticle(id){
                               layer.open({
                                            type: 2,
                                            title: '编辑文章',
                                           shadeClose: true,
                                             shade: false,
                                                maxmin: true, //开启最大化最小化按钮
                                            area: ['90%', '90%'],
                                            content: 'temp/articlemanage.php?id='+id,
                                            end: function () {
                                                location.reload();
                                          }
                              });
                        }
                        function deleteartcbyid(id){
                            if(!confirm('你确定要删除该文章吗？')){
                                return false;
                            }
                            var ii = layer.load(2, {shade:[0.1,'#fff']});
                            $.ajax({
                                    type : "POST",
                                    url : "ajax.php?act=deleteartcbyid",
                                    data : {"id":id},
                                    dataType : 'json',
                                    success : function(data) {
                                         layer.close(ii);
                                         layer.msg(data.msg);
                                         if(data.code == 1){
                                                location.reload();
                                         }
                                            
                                    },
                                    error:function(data){
                                             layer.close(ii);
                                            layer.msg('服务器错误');
                                            return;
                                            }
                            });


                        }
                        
                        function articlestatusqh(id,sta){
                             var ii = layer.load(2, {shade:[0.1,'#fff']});
                             $.ajax({
                                    type : "POST",
                                    url : "ajax.php?act=articlestatusqh",
                                    data : {"id":id,"sta":sta},
                                    dataType : 'json',
                                    success : function(data) {
                                         layer.close(ii);
                                         layer.msg(data.msg);
                                         if(data.code == 1){
                                                location.reload();
                                         }
                                            
                                    },
                                    error:function(data){
                                             layer.close(ii);
                                            layer.msg('服务器错误');
                                            return;
                                            }
                            });
                        }
                        
                        function searchatticle(){
                            layer.prompt({title: '文章搜索[标题/作者/关键字/描述]', formType: 2}, function(text, index){
                                layer.close(index);
                                $("#keys").val(text);
                                $("#subbtn").click();
                                  
                          });
                        }
		</script>
	</body>

</html>