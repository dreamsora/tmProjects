<?php
include 'admintm.php';
if($adminrow['admin_qx_system'] != 1){
    exit("您没有该页面的权限！");
}


if(!empty($_GET['act']) && $_GET['act'] == "submit"){
    $fn = daddslashes($_POST['filename']);
    $html = $_POST['editbox'];
    if(file_exists($fn)){
        //unlink($fn); 
       // exit($fn);
        chmod($fn, 0777);
        if(!is_writable($fn)){
           
            exit('<script>alert("修改失败，没有权限操作该文件！");window.location.href="editfile.php";</script>');
           
        }
     
        file_put_contents($fn, $html);
         exit('<script>alert("修改文件内容成功！");window.location.href="editfile.php";</script>');
    }else{
         exit('<script>alert("修改失败，请刷新重试！");window.location.href="editfile.php";</script>');
    }
}
/*
 * substr 返回字符串的子串
 * base_convert  在任意进制之间转换数字
 * fileperms  取得文件的权限
 */
// 获取权限
function getChmod($filepath){
    return substr(base_convert(@fileperms($filepath),10,8),-4);
}
?>

 <!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title>文件编辑</title>
		<link rel="stylesheet" href="plugins/layui/css/layui.css" media="all" />
		<link rel="stylesheet" href="css/global.css" media="all">
		<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/table.css" />
	</head>

	<body>
		<div class="admin-main">

			<fieldset class="layui-elem-field">
				<legend>模版文件列表    <a href="javascript: location.reload();"  class="layui-btn layui-btn-primary layui-btn-mini" ><i class="layui-icon">&#x1002;</i>  刷新</a></legend>
				<div class="layui-field-box">
                                    <a href="?" class='layui-btn layui-btn-primary layui-btn-radius'>原始界面</a>
                                    <?php
                                    $filelist = read_all(ROOT."templets/".$webinfo_conf['webtp'],1,1);
                                  
                                    foreach ($filelist as $filename) {
                                        echo "<a href='?filename=".$filename."' class='layui-btn layui-btn-primary layui-btn-radius'>".$filename."</a>";
                                    }
                                    ?>

				</div>
			</fieldset>
                    
                    <fieldset class="layui-elem-field">
                                        <?php
                                        if(!empty($_GET['filename']) && $_GET['filename'] != ""){
                                            $fn = $_GET['filename'];
                                            $fnpath = ROOT."templets/".$webinfo_conf['webtp']."/".$fn;
                                           
                                            $txt = file_get_contents($fnpath);
                                        }else{
                                            $txt = "";
                                            $fnpath = "";
                                            $fn="";
                                        }
                                        
                                        ?>
				<legend>文件编辑  <?=$fn?></legend>
                                <div class="layui-field-box" style="text-align: center">
                                    <form action="?act=submit" method="post">
                                        
                                      
                                        <input type="hidden" name='filename' value="<?=$fnpath?>">
                                        <textarea rows="20" style="width: 100%;" name='editbox' id="editbox"><?=$txt ?></textarea>
                                        <br>
                                        <?php
                                        if(file_exists($fnpath)){
                                            echo '  <button type="submit" class="layui-btn layui-btn-normal" >
                                             <i class="layui-icon">&#xe642;</i> 保存修改后的文件</button>';
                                        }
                                        ?>
                                       
                                             
                                    </form>

				</div>
			</fieldset>
			
		</div>
            <script src="layui/jquery-1.8.2.min.js"></script>
		<script type="text/javascript" src="plugins/layui/layui.js"></script>
		<script>
			
			layui.config({
				base: 'plugins/layui/modules/'
			});
                        layui.use(['icheck', 'laypage','layer'], function() {
				var $ = layui.jquery,
					laypage = layui.laypage,
					layer = parent.layer === undefined ? layui.layer : parent.layer;
				$('input').iCheck({
					checkboxClass: 'icheckbox_flat-green'
				});
                                
                                
                            })
                 
		</script>
	</body>

</html>