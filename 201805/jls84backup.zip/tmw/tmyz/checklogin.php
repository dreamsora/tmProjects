<?php

$php_self=substr($_SERVER['REQUEST_URI'],strrpos($_SERVER['REQUEST_URI'],'/')+1,strrpos($_SERVER['REQUEST_URI'],'.')-strrpos($_SERVER['REQUEST_URI'],'/')-1);

/*
 * 获取登陆信息
 */
if(!empty($_COOKIE['admin_token'])){
    $token=authcode(daddslashes($_COOKIE['admin_token']), 'DECODE', "tmwl88888888");
	list($user, $sid) = explode("\t", $token);
        $adminrow = $DB->query("select * from tm_admin where admin_user = '$user' limit 1")->fetch();
	$session=md5($adminrow['admin_user'].$adminrow['admin_pass'].$password_hash);
	
	if($session==$sid) {
		$islogin=1;
               $loginerr = 0;
        }else{
           $loginerr = 1;
           if($php_self != "login"){
               exit("<script language='javascript'>window.location.href='./login.php';</script>");
           }
        }
}else{
    $loginerr = 1;
    if($php_self != "login"){
           exit("<script language='javascript'>window.location.href='./login.php';</script>");
     }
}
