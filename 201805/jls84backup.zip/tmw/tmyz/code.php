<?php
session_start();
define('ROOT_PATH', dirname(__FILE__));
require 'ValidateCode.class.php';
$_vc = new ValidateCode(4,1,50,100);
$_SESSION['code']= $_vc->getCode();
//echo $_SESSION['code'];
$_vc->outImage();
?>