var navs = [ 
    {
	"title": "栏目管理",
	"icon": "fa-fire",
	"href": "lmlist.php",
	"spread": false
},{
	"title": "文章管理",
	"icon": "&#xe609;",
	"href": "articlelist.php",
	"spread": false
},{
	"title": "留言管理",
	"icon": "&#xe646;",
	"href": "myfromlist.php",
	"spread": false
},{
	"title": "网站配置",
	"icon": "&#xe614;",
	"spread": false,
	"children": [{
		"title": "网站基本信息",
		"icon": "&#xe638;",
		"href": "webinfoset.php?act=web"
	},{
		"title": "网站版权信息",
		"icon": "fa-copyright",
		"href": "webinfoset.php?act=footer"
	},{
		"title": "联系方式配置",
		"icon": "fa-qq",
		"href": "webinfoset.php?act=contact"
	},{
		"title": "友情链接",
		"icon": "fa-chain-broken",
		"href": "temp/links.php"
	},{
		"title": "幻灯片管理",
		"icon": "fa-play-circle-o",
                "href": "imagesmanage.php?act=slides"
	},{
		"title": "LOGO更换",
		"icon": "fa-cloud-upload",
		 "href": "imagesmanage.php?act=logo"
	},{
		"title": "主题模板",
		"icon": "&#xe632;",
		 "href": "webinfoset.php?act=template"
	},{
		"title": "系统变量",
		"icon": "&#xe608;",
		"href": "customizevar.php"
	}]
}, {
	"title": "系统高级",
	"icon": "&#xe631;",
	"href": "",
	"spread": false,
	"children": [
            {
		"title": "网站管理员",
		"icon": "&#xe612;",
		"href": "adminmanage.php"
	},{
		"title": "数据库备份",
		"icon": "fa-database",
		"href": "databackup.php"
	}]
}, {
	"title": "开发者中心",
	"icon": "&#xe620;",
	"href": "",
	"spread": false,
	"children": [
             {
		"title": "自定义表单",
		"icon": "&#xe629;",
		"href": "myform.php"
	},{
		"title": "文章自定义参数",
		"icon": "&#xe647;",
		"href": "temp/articlezdyzd.php?act=show"
	},{
		"title": "编辑文件",
		"icon": "&#xe64e;",
		"href": "editfile.php"
	},{
		"title": "执行SQL",
		"icon": "&#xe628;",
		"href": "exesql.php"
	}]
}];