<?php
include 'admintm.php';
if($adminrow['admin_qx_article'] != 1){
    exit("您没有该页面的权限！");

}

?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title>Table</title>
		<link rel="stylesheet" href="plugins/layui/css/layui.css" media="all" />
		<link rel="stylesheet" href="css/global.css" media="all">
		<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/table.css" />
	</head>

	<body>
		<div class="admin-main">

			<blockquote class="layui-elem-quote">
                               <?php
                                  if(!empty($_GET['act']) &&  $_GET['act'] == "search"){
                                      echo '<a href="?t='.time().'" 	class="layui-btn layui-btn-normal">
					<i class="layui-icon">&#xe603;</i> 显示全部列表
				</a>';
                                  }
                               ?>
                            
				<a href="javascript:;" 	class="layui-btn layui-btn-lg" id="add">
					<i class="layui-icon">&#xe608;</i> 添加文章
				</a>
				<a href="javascript: location.reload();"  class="layui-btn layui-btn-normal" >
					<i class="layui-icon">&#x1002;</i>  刷新页面
				</a>
                            <a onclick="createcache_article()" class="layui-btn layui-btn-sm layui-btn-danger">
					<i class="layui-icon">&#xe62c;</i> 生成缓存文件
				</a>
                          
                            <a onclick="searchatticle()" class="layui-btn layui-btn-sm layui-btn-warm">
					<i class="layui-icon">&#xe615;</i> 搜索文章
				</a>
                        
			</blockquote>
			<fieldset class="layui-elem-field">
				<legend>文章列表</legend>
				<div class="layui-field-box">
					<table class="site-table table-hover">
						<thead>
							<tr>
                                                                <th>文章ID</th>
								<th>文章标题</th>
								<th>所属栏目</th>
								<th>添加时间</th>
								<th>文章作者</th>
                                                       
								<th>排序值</th>
                                                                <th>状态</th>
								
								<th>操作</th>
							</tr>
						</thead>
						<tbody>
                                                    
                                                    <?php
                                                    $numrows = $DB->query("select count(*) from tm_article_list")->fetch();
                                                    $numrows = $numrows[0];
                                                    $pagesize=30;
                                                    $pages=intval($numrows/$pagesize);
                                                    if ($numrows%$pagesize)
                                                    {
                                                     $pages++;
                                                     }
                                                    if (isset($_GET['page'])){
                                                    $page=intval($_GET['page']);
                                                    }
                                                    else{
                                                    $page=1;
                                                    }
                                                    $offset=$pagesize*($page - 1);
                                                    if(!empty($_GET['act']) &&  $_GET['act'] == "search"){
                                                        $keys = daddslashes($_POST['keys']);
                                                        $sql = "select * from tm_article_list where  article_title like '%$keys%' or article_description like '%$keys%' or article_keywords like '%$keys%' or article_author ='$keys'  order by article_id desc";
                                                     //   exit($sql);
                                                        
                                                    }else{
                                                          $sql = "select * from tm_article_list   order by article_id desc limit $offset,$pagesize";
                                                    }
                                                  
                                                    $rs = $DB->query($sql);
                                                    while ($row = $rs->fetch()){
                                                        ?>
                                                            <tr>
								
								<td><?=$row['article_id']?></td>
								<td><?=substr_utf8($row['article_title'],20)?></td>
								<td>
                                                                    <?php
                                                                    $lmrow = getlmnamebyid($row['article_lm_id']);
                                                                    echo $lmrow['lm_name'];
                                                                    ?>
                                                                </td>
								<td><?=$row['article_addtime']?></td>
								<td><?=$row['article_author']?></td>
								<td><?=$row['artice_sort']?></td>
								<td><?=articestatus($row['article_id'],$row['artice_status'])?></td>
                                                            
								
								<td>
                                                                    <a href="<?=SITE_URL?>/<?=$lmrow['lm_pyname']?>/article_<?=$row['article_id']?>.html" target="_blank" class="layui-btn layui-btn-normal layui-btn-mini">预览</a>
									<a onclick="editarticle(<?=$row['article_id']?>)" class="layui-btn layui-btn-mini">编辑</a>
                                                                        <a onclick="deleteartcbyid(<?=$row['article_id']?>)" data-id="1" data-opt="del" class="layui-btn layui-btn-danger layui-btn-mini">删除</a>
								</td>
							</tr>
                                                         
                                             
                                                  <?php
                                                       
                                                    }
                                                    ?>
						</tbody>
					</table>
                                   <!--   <link href="//cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>-->
                                   <style>
                                       .pagination {
  display: inline-block;
  padding-left: 0;
  margin: 20px 0;
  border-radius: 4px;
}
.pagination > li {
  display: inline;
}
.pagination > li > a,
.pagination > li > span {
  position: relative;
  float: left;
  padding: 6px 12px;
  margin-left: -1px;
  line-height: 1.42857143;
  color: #337ab7;
  text-decoration: none;
  background-color: #fff;
  border: 1px solid #ddd;
}
.pagination > li:first-child > a,
.pagination > li:first-child > span {
  margin-left: 0;
  border-top-left-radius: 4px;
  border-bottom-left-radius: 4px;
}
.pagination > li:last-child > a,
.pagination > li:last-child > span {
  border-top-right-radius: 4px;
  border-bottom-right-radius: 4px;
}
                                   </style>
                                    <?php
  if(empty($_GET['act'])){
 echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
$link = "";
//首页按钮控制
if ($page>1)
{
echo '<li><a href="?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
//从第一页页到当前页-1
for ($i=1;$i<$page;$i++){
    if($page-3<$i){
        echo '<li><a href="?page='.$i.$link.'">'.$i .'</a></li>';
    }
        
}
//当前页不可点击
echo '<li class="disabled"><a>'.$page.'</a></li>';

//从当前页+1到最后一页
for ($i=$page+1;$i<=$pages;$i++){
    if($page +3 >= $i){
        echo '<li><a href="?page='.$i.$link.'">'.$i .'</a></li>';
    }
    
}
echo '';
//尾页按钮控制
if ($page<$pages)
{
echo '<li><a href="?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
  }                                    
 
                                    ?>

				</div>
			</fieldset>
                    <form method="POST" action="?act=search" id="searchfrm">
                        <input type="hidden" name="keys" id="keys">
                        <input type="submit"id="subbtn" style="display: none;">
                    </form>
		</div>
            <script src="layui/jquery-1.8.2.min.js"></script>
		<script type="text/javascript" src="plugins/layui/layui.js"></script>
               
		<script>
                  
			layui.config({
				base: 'plugins/layui/modules/'
			});

			layui.use(['icheck', 'laypage','layer'], function() {
				var $ = layui.jquery,
					laypage = layui.laypage,
					layer = parent.layer === undefined ? layui.layer : parent.layer;
				$('input').iCheck({
					checkboxClass: 'icheckbox_flat-green'
				});

				
                                $("#addzdyzd").on('click',function(){
                                 
                                      layer.open({
                                                                    type: 2,
                                                                    title: '添加文章自定义字段',
                                                                    shadeClose: true,
                                                                    shade: false,
                                                                    maxmin: true, //开启最大化最小化按钮
                                                                    area: ['70%', '80%'],
                                                                    content: 'temp/articlezdyzd.php',
                                                                    end: function () {
                                                                        location.reload();
                                                                  }
                                                      });
                                })
				

				$('#add').on('click', function() {
                                                      var index = layer.open({
                                                                    type: 2,
                                                                    title: '添加文章',
                                                                    shadeClose: true,
                                                                    shade: false,
                                                                    
                                                                    maxmin: true, //开启最大化最小化按钮
                                                                    area: ['50%', '50%'],
                                                                    content: 'temp/articlemanage.php',
                                                                    end: function () {
                                                                        location.reload();
                                                                  }
                                                      });
                                                   layer.full(index);
                                   
				});


				$('.site-table tbody tr').on('click', function(event) {
					var $this = $(this);
					var $input = $this.children('td').eq(0).find('input');
					$input.on('ifChecked', function(e) {
						$this.css('background-color', '#EEEEEE');
					});
					$input.on('ifUnchecked', function(e) {
						$this.removeAttr('style');
					});
					$input.iCheck('toggle');
				}).find('input').each(function() {
					var $this = $(this);
					$this.on('ifChecked', function(e) {
						$this.parents('tr').css('background-color', '#EEEEEE');
					});
					$this.on('ifUnchecked', function(e) {
						$this.parents('tr').removeAttr('style');
					});
				});
				$('#selected-all').on('ifChanged', function(event) {
					var $input = $('.site-table tbody tr td').find('input');
					$input.iCheck(event.currentTarget.checked ? 'check' : 'uncheck');
				});
			});
                        
                        function createcache_article(){
                            var ii = layer.load(2, {shade:[0.1,'#fff']});
                            $.ajax({
                                    type : "POST",
                                    url : "ajax.php?act=createcache",
                                    data : {},
                                    dataType : 'json',
                                    success : function(data) {
                                         layer.close(ii);
                                         layer.msg(data.msg);
                                      
                                            
                                    },
                                    error:function(data){
                                             layer.close(ii);
                                            layer.msg('服务器错误');
                                            return;
                                            }
                            });

                        }
                        function editarticle(id){
                               layer.open({
                                            type: 2,
                                            title: '编辑文章',
                                           shadeClose: true,
                                             shade: false,
                                                maxmin: true, //开启最大化最小化按钮
                                            area: ['90%', '90%'],
                                            content: 'temp/articlemanage.php?id='+id,
                                            end: function () {
                                                location.reload();
                                          }
                              });
                        }
                        function deleteartcbyid(id){
                            if(!confirm('你确定要删除该文章吗？')){
                                return false;
                            }
                            var ii = layer.load(2, {shade:[0.1,'#fff']});
                            $.ajax({
                                    type : "POST",
                                    url : "ajax.php?act=deleteartcbyid",
                                    data : {"id":id},
                                    dataType : 'json',
                                    success : function(data) {
                                         layer.close(ii);
                                         layer.msg(data.msg);
                                         if(data.code == 1){
                                                location.reload();
                                         }
                                            
                                    },
                                    error:function(data){
                                             layer.close(ii);
                                            layer.msg('服务器错误');
                                            return;
                                            }
                            });


                        }
                        
                        function articlestatusqh(id,sta){
                             var ii = layer.load(2, {shade:[0.1,'#fff']});
                             $.ajax({
                                    type : "POST",
                                    url : "ajax.php?act=articlestatusqh",
                                    data : {"id":id,"sta":sta},
                                    dataType : 'json',
                                    success : function(data) {
                                         layer.close(ii);
                                         layer.msg(data.msg);
                                         if(data.code == 1){
                                                location.reload();
                                         }
                                            
                                    },
                                    error:function(data){
                                             layer.close(ii);
                                            layer.msg('服务器错误');
                                            return;
                                            }
                            });
                        }
                        
                        function searchatticle(){
                            layer.prompt({title: '文章搜索[标题/作者/关键字/描述]', formType: 2}, function(text, index){
                                layer.close(index);
                                $("#keys").val(text);
                                $("#subbtn").click();
                                  
                          });
                        }
		</script>
	</body>

</html>