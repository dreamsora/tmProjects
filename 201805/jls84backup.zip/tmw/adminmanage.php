<?php
include 'admintm.php';

if($adminrow['admin_qx_system'] != 1){
    exit("您没有该页面的权限！");
}


if(!empty($_GET['act']) && $_GET['act'] == 'edit'){
    $id = intval($_GET['id']);
     $set = "";
    foreach ($_POST as $k => $v){
        if($set != ""){
            $set = $set.",";
        }
        $set .= $k."='".$v."'";
    }
    $sql = "update tm_admin set $set where admin_id =".$id;
     if($DB->exec($sql)){
        exit('<script>alert("修改管理员成功！");window.location.href="adminmanage.php";</script>');
    }else{
        exit('<script>alert("修改管理员失败！");window.history.go(-1);</script>');
    }
    
}elseif(!empty($_GET['act']) && $_GET['act'] == "add"){
    
    $admin_user = $_POST['admin_user'];
    $r = $DB->query("select admin_user from tm_admin where admin_user = '$admin_user' limit 1")->fetch();
    if($r){
        exit('<script>alert("管理员登陆名已经存在！");window.location.href="adminmanage.php";</script>');
    }
    if(insert("tm_admin", $_POST)){
          exit('<script>alert("添加管理员成功！");window.location.href="adminmanage.php";</script>');
    }else{
        exit('<script>alert("添加管理员失败！");window.location.href="adminmanage.php";</script>');
    }
    
    
}

?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title>Table</title>
		<link rel="stylesheet" href="plugins/layui/css/layui.css" media="all" />
		<link rel="stylesheet" href="css/global.css" media="all">
		<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/table.css" />
	</head>

	<body>
		<div class="admin-main">

			<fieldset class="layui-elem-field">
				<legend>网站管理员设置    <a href="javascript: location.reload();"  class="layui-btn layui-btn-primary layui-btn-mini" ><i class="layui-icon">&#x1002;</i>  刷新</a></legend>
				<div class="layui-field-box">
					<table class="site-table table-hover">
						<thead>
							<tr>
						
								<th>管理员ID</th>
								<th>管理员用户名</th>
								<th>管理员密码</th>
                                                                <th>文章管理权限</th>
                                                                <th>栏目管理权限</th>
                                                                <th>网站管理权限</th>
                                                                <th>系统高级权限</th>
                                                                
                                                                
								<th>管理员状态</th>
                                                                
								
								<th>操作</th>
							</tr>
						</thead>
						<tbody>
                                                    
                                                    <?php
                                                    $sql = "select * from tm_admin";
                                                    $rs = $DB->query($sql);
                                                    while ($row = $rs->fetch()){
                                                        ?>
                                                            <tr>
                                                <form action="?act=edit&id=<?=$row['admin_id']?>" method="POST">
								
                                                    <td><input type="text" name="admin_id" value="<?=$row['admin_id']?>" disabled /></td>
                                                          <td ><input  type="text" name="admin_user" value="<?=$row['admin_user']?>" /></td>
                                                                <td><input type="text" name="admin_pass" value="<?=$row['admin_pass']?>" /></td>
                                                   
                                                                 <td>
                                                                    <select name="admin_qx_article">
                                                                        <option value="1" <?=$row['admin_qx_article']==1?"selected":""?> >有</option>
                                                                        <option value="0"  <?=$row['admin_qx_article']==0?"selected":""?>>无</option>
                                                                    </select>
                                                                </td>
                                                                 <td>
                                                                    <select name="admin_qx_lm">
                                                                        <option value="1" <?=$row['admin_qx_lm']==1?"selected":""?> >有</option>
                                                                        <option value="0"  <?=$row['admin_qx_lm']==0?"selected":""?>>无</option>
                                                                    </select>
                                                                </td>
                                                                 <td>
                                                                    <select name="admin_qx_web">
                                                                        <option value="1" <?=$row['admin_qx_web']==1?"selected":""?> >有</option>
                                                                        <option value="0"  <?=$row['admin_qx_web']==0?"selected":""?>>无</option>
                                                                    </select>
                                                                </td>
                                                                 <td>
                                                                    <select name="admin_qx_system">
                                                                        <option value="1" <?=$row['admin_qx_system']==1?"selected":""?> >有</option>
                                                                        <option value="0"  <?=$row['admin_qx_system']==0?"selected":""?>>无</option>
                                                                    </select>
                                                                </td>
                                                                
                                                                
                                                                <td>
                                                                    <select name="admin_status">
                                                                        <option value="1" <?=$row['admin_status']==1?"selected":""?> >正常</option>
                                                                        <option value="0"  <?=$row['admin_status']==0?"selected":""?>>冻结</option>
                                                                    </select>
                                                                </td>
                                                            
								
								<td>
                                                                    
                                                                    <input type="submit" value="修改保存"  class="layui-btn layui-btn-normal layui-btn-mini">
                                                                   <a onclick="deleteadminbyid(<?=$row['admin_id']?>)" data-id="1" data-opt="del" class="layui-btn layui-btn-danger layui-btn-mini">删除</a>
								</td>
						</form>	
                                                </tr>
                                                            <?php
                                                     
                                                    }
                                                    ?>
                                                <tr style="border: 1px salmon solid;">
                                                <form action="?act=add" method="POST">
								
                                                    <td>新增管理员信息：</td>
                                                          <td ><input  type="text" name="admin_user" value="" /></td>
                                                                <td><input type="text" name="admin_pass" value="" /></td>
                                                   
                                                            
                                                                <td>
                                                                    <select name="admin_qx_article">
                                                                        <option value="1" >有</option>
                                                                        <option value="0" >无</option>
                                                                    </select>
                                                                </td>
                                                                 <td>
                                                                    <select name="admin_qx_lm">
                                                                        <option value="1"  >有</option>
                                                                        <option value="0">无</option>
                                                                    </select>
                                                                </td>
                                                                <td>
                                                                    <select name="admin_qx_web">
                                                                        <option value="1"  >有</option>
                                                                        <option value="0" >无</option>
                                                                    </select>
                                                                </td>
                                                                 <td>
                                                                    <select name="admin_qx_system">
                                                                        <option value="1"  >有</option>
                                                                        <option value="0">无</option>
                                                                    </select>
                                                                </td>
                                                                 <td>
                                                                    <select name="admin_status">
                                                                        <option value="1" >正常</option>
                                                                        <option value="0">冻结</option>
                                                                    </select>
                                                                </td>
                                                                
								
								<td>
                                                                    
                                                                    <input type="submit" value="添加管理员"  class="layui-btn layui-btn-normal layui-btn-mini">
                                                              </td>
						</form>	
                                                </tr>
						</tbody>
					</table>

				</div>
			</fieldset>
			<div class="admin-table-page">
				<div id="page" class="page">
				</div>
			</div>
		</div>
            <script src="layui/jquery-1.8.2.min.js"></script>
		<script type="text/javascript" src="plugins/layui/layui.js"></script>
		<script>
			layui.config({
				base: 'plugins/layui/modules/'
			});
                          layui.use(['icheck', 'laypage','layer'], function() {
				var $ = layui.jquery,
					laypage = layui.laypage,
					layer = parent.layer === undefined ? layui.layer : parent.layer;
				$('input').iCheck({
					checkboxClass: 'icheckbox_flat-green'
				});
                                
                                
                            })
                        function deleteadminbyid(id){
                             var ii = layer.load(2, {shade:[0.1,'#fff']});
                           
                             $.ajax({
                                    type : "POST",
                                    url : "ajax.php?act=deleteadminbyid",
                                    data : {"id":id},
                                    dataType : 'json',
                                    success : function(data) {
                                         layer.close(ii);
                                         layer.msg(data.msg);
                                         if(data.code == 1){
                                                location.reload();
                                         }
                                            
                                    },
                                    error:function(data){
                                             layer.close(ii);
                                            layer.msg('服务器错误');
                                            return;
                                            }
                            });
                        }
			
                 
		</script>
	</body>

</html>