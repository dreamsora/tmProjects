<?php

class backUp{
        private    $mysql_link;//链接标识
        private    $dbName;    //数据库名
        private    $dataDir;     //数据所要存放的目录
        private    $tableNames;//表名

        public function __construct($mysql_link){
            $this->mysql_link = $mysql_link;
        }
        
     
        
        public function backupTables($dbName,$dataDir,$tableNames){
            global $pdo;

            global $database;

            $this->dbName  = $dbName;

            $this->dataDir  = $dataDir;
            
            $this->tableNames = $tableNames;

            $tables=$this->delarray($this->tableNames);

            $sqls='';

            foreach($tables as $tablename){

                    $tablename =$tablename['Tables_in_'.$database];

                    if($tablename == ''){//表不存在时

                    continue;

                    }

                    //************************以下是形成SQL的前半部分**************

                    //如果存在表，就先删除

                    $sqls .= "\nDROP TABLE IF EXISTS $tablename;\n\n";

                    //读取表结构

                    try{

                    $rs = $pdo->query('SHOW CREATE TABLE '.$tablename); //创表语句

                    }catch(PDOException $e){

                    var_dump($e);

                    }

                    $row=$rs->fetch();

                    //获得表结构组成SQL

                    $sqls.=$row['Create Table'].";\n\n";

                    unset($rs);

                    unset($row);

            //************************以下是形成SQL的后半部分**************

                    //查寻出表中的所有数据

                    $rs=$pdo->query("select * from ".$tablename);

                    $result=$rs->setFetchMode (PDO::FETCH_ASSOC);

                    $rows=$rs->fetchAll();

                    $count = $rs->rowCount();

                    echo $tablename.":".$count.'<br>';

                    $i = 0;

                    //$sqls.="INSERT INTO $tablename VALUES ";

                    foreach ($rows as $row) {

                    //var_dump($row);

                    $douhao="";

                    $sqls.="INSERT INTO $tablename VALUES(";

                    foreach ($row as $ro) {

                    $ro=addslashes($ro);

                    $sqls.=$douhao.'('.'\''.$ro.'\''.")";

                    $douhao=",";

                    }

                    $sqls.=");\n";

                    }

            //$sqls.=";\n";

            }
            
            //exit($dataDir);
        $backfilepath=$dataDir.$database.date("Y-m-d",time()).'.sql';
        //exit($backfilepath);
        //写入文件

        $filehandle = fopen($backfilepath, "w");

        fwrite($filehandle, $sqls);

        fclose($filehandle);

        return true;

            
        }

       public function delarray($array){
           
            global $pdo;

            global $database;

            $array_del = array('first'=>$array);
           foreach($array_del as $tables){
                    if($tables == "*"){
                         $newtables = $pdo->query('show tables from '.$database);

                        $tableList = array();

                        $tableList =$newtables->fetchAll();
                    }else{
                        
                        $tableList=$array_del;

                        break;
                    }

            }

            return $tableList;

       }

       
//end

}
include '../admintm.php';
global $pdo;
global $database;
date_default_timezone_set('Asia/Shanghai');
$database = $data['db_name'];
$dir=ROOT.'beifen/';
$pdo = $DB ;
if (!$pdo) {

echo'connect_wrong';

}

$data = new backUp($pdo);

$success =$data->backupTables($database,$dir,'*');

if ($success) {

echo'success';

}
?>


