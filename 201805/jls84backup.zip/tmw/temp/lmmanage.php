<?php
include '../admintm.php';

if(!empty($_GET['act']) && $_GET['act'] == "add"){
    $adddata['lm_name']= daddslashes($_POST['lm_name']);
    $adddata['lm_fname']= daddslashes($_POST['lm_fname']);
    $adddata['lm_pyname'] = $_POST['lm_pyname']!=""?daddslashes($_POST['lm_pyname']):pinyin($_POST['lm_name']);
    $adddata['lm_images'] = !empty($_POST['lm_images'])?daddslashes($_POST['lm_images']):"default.png";
    $adddata['lm_desc']= daddslashes($_POST['lm_desc']);
    $adddata['lm_key']= daddslashes($_POST['lm_key']);
    $adddata['lm_articlemodel']= daddslashes($_POST['lm_articlemodel']);
    $adddata['lm_pagetype']=intval($_POST['lm_pagetype']);
    if(daddslashes($_POST['lm_pagemodel']) == ""){
        $sql = "select * from tm_pagetype where pt_id = ".$adddata['lm_pagetype']." limit 1";
        $prow = $DB->query($sql)->fetch();
        $adddata['lm_pagemodel'] = $prow['pt_model'];
    }else{
        $adddata['lm_pagemodel'] = daddslashes($_POST['lm_pagemodel']);
    }

    $adddata['lm_addtime'] =date("Y-m-d H:i:s");
    $adddata['lm_text'] = empty($_POST['editor'])?"":daddslashes($_POST['editor']);
    $adddata['lm_sort'] = empty($_POST['lm_sort'])?5:intval($_POST['lm_sort']);
    if(intval($_POST['lm_parent'])!=0){
        $adddata['lm_parent'] = intval($_POST['lm_parent']);
    }
    $adddata['lm_status'] = 1;
    if(insert('tm_lanmulist',$adddata)){
        exit('<script>alert("添加成功！");
            var index=parent.layer.getFrameIndex(window.name);
            
                parent.layer.close(index);</script>');
    }else{
        exit('<script>alert("修改失败！");
            var index=parent.layer.getFrameIndex(window.name);
            
                parent.layer.close(index);</script>');
    }
}elseif(!empty($_GET['act']) && $_GET['act'] == "edit_add"){
    //edit_add
    $id = intval($_POST['lm_id']);
    
    $edata['lm_name']= daddslashes($_POST['lm_name']);
    $edata['lm_fname']= daddslashes($_POST['lm_fname']);
    $edata['lm_desc']= daddslashes($_POST['lm_desc']);
    $edata['lm_key']= daddslashes($_POST['lm_key']);
    $edata['lm_articlemodel']= daddslashes($_POST['lm_articlemodel']);
    $edata['lm_images'] = !empty($_POST['lm_images'])?daddslashes($_POST['lm_images']):"default.png";
    $edata['lm_pyname'] = $_POST['lm_pyname']!=""?daddslashes($_POST['lm_pyname']):pinyin($_POST['lm_name']);
    
    $edata['lm_pagetype']=intval($_POST['lm_pagetype']);
    if(daddslashes($_POST['lm_pagemodel']) == ""){
        $sql = "select * from tm_pagetype where pt_id = ".$edata['lm_pagetype']." limit 1";
        $prow = $DB->query($sql)->fetch();
        $edata['lm_pagemodel'] = $prow['pt_model'];
    }else{
        $edata['lm_pagemodel'] = daddslashes($_POST['lm_pagemodel']);
    }

  //  $adddata['lm_addtime'] =date("Y-m-d H:i:s");
    $edata['lm_text'] = empty($_POST['editor'])?"":daddslashes($_POST['editor']);
    $edata['lm_sort'] = empty($_POST['lm_sort'])?5:intval($_POST['lm_sort']);
    if(intval($_POST['lm_parent'])!=0){
        $edata['lm_parent'] = intval($_POST['lm_parent']);
    }else{
          $edata['lm_parent'] = 0;
    }
    $set = "";
    foreach ($edata as $k => $v){
        if($set != ""){
            $set = $set.",";
        }
        $set .= $k."='".$v."'";
    }
    $sql = "update tm_lanmulist set $set where lm_id =".$id;
  //  exit($sql);
    if($DB->exec($sql)){
        exit('<script>alert("修改成功！");
            var index=parent.layer.getFrameIndex(window.name);
            
                parent.layer.close(index);</script>');
    }else{
     //   exit($sql);
        exit('<script>alert("修改失败！");
            var index=parent.layer.getFrameIndex(window.name);
            
                parent.layer.close(index);</script>');
    }
    
}




?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title>Table</title>
                      <link rel="stylesheet" href="../layui/css/layui.css">
                
<script src="../layui/layui.js"></script>
<script src="../layui/jquery-1.8.2.min.js"></script>
	</head>

        <body>

<?php
if(!empty($_GET['id']) && $_GET['id'] != "" && intval($_GET['id']) >0){
    $id = intval($_GET['id']);
    $row = $DB->query("select * from tm_lanmulist where lm_id=".$id)->fetch();
    
    ?>
        <!-- 编辑栏目开始 -->
<form method="POST" action="?act=edit_add" class="layui-form" style="margin-top: 10px;display: block;">

    <input type="hidden" value="<?=$id?>" name="lm_id">
	<div class="layui-form-item">
		<label class="layui-form-label">栏目名称</label>
                <div class="layui-input-block" style="width: 80%;">
                    <input type="text" name="lm_name" placeholder="请输入栏目名称" id="lm_name" value="<?=$row['lm_name']?>" class="layui-input">
		</div>
                
	</div>
    <div class="layui-form-item">
		<label class="layui-form-label">栏目副标题</label>
		<div class="layui-input-block" style="width: 80%;">
			<input type="text" name="lm_fname" placeholder="栏目副标题" value="<?=$row['lm_fname']?>"  id="lm_fname" class="layui-input">
		</div>
	</div>
    <div class="layui-form-item">
		<label class="layui-form-label">栏目描述</label>
                <div class="layui-input-block" style="width: 80%;">
                    <input type="text" name="lm_desc" placeholder="用于SEO的描述" id="lm_desc" value="<?=$row['lm_desc']?>" class="layui-input">
		</div>
                
	</div>
      <div class="layui-form-item">
		<label class="layui-form-label">栏目关键字</label>
                <div class="layui-input-block" style="width: 80%;">
                    <input type="text" name="lm_key" placeholder="用于SEO的关键字" id="lm_key" value="<?=$row['lm_key']?>" class="layui-input">
		</div>
                
	</div>
     
        <div class="layui-form-item">
		<label class="layui-form-label">栏目图</label>
		<div class="layui-input-block" style="width: 80%;">
	 <div class="layui-upload">
           <button type="button" class="layui-btn" id="test1">上传图片</button>
           <div class="layui-upload-list">
               <img class="layui-upload-img" id="demo1" src="<?=ARTICLE_IMG_PATH.$row['lm_images']?>" style="width: 80px; height: 80px;">
             <p id="demoText"></p>
           </div>
         </div> 
		</div>
                <input type="hidden" name='lm_images' value="<?=$row['lm_images']?>" id='lm_images'>
	</div>
    
        <div class="layui-form-item">
		<label class="layui-form-label">栏目别名</label>
		<div class="layui-input-block" style="width: 80%;">
			<input type="text" name="lm_pyname" placeholder="请输入栏目别名 *为空默认为拼音" value="<?=$row['lm_pyname']?>"  id="lm_pyname" class="layui-input">
		</div>
	</div>
         <div class="layui-form-item">
		<label class="layui-form-label">文章模板</label>
		<div class="layui-input-block" style="width: 80%;">
			<input type="text" name="lm_articlemodel" placeholder="本栏目下文章展示模板" value="<?=$row['lm_articlemodel']==""?"article_article.html":$row['lm_articlemodel']?>"  id="lm_articlemodel" class="layui-input">
		</div>
	</div>
        <div class="layui-form-item">
                <label class="layui-form-label">上级栏目</label>
                <div class="layui-input-block" style="width: 80%;">
                    <select name="lm_parent">
                          <option value="0">无</option>
                      <?php
                      $sql = "select * from tm_lanmulist where lm_parent is null or lm_parent =0";
                      $rss =$DB->query($sql);
                      while ($roww = $rss->fetch()){
                          if($roww['lm_id'] == $row['lm_id'])    continue;
                           if($row['lm_parent'] == $roww['lm_id']){
                                $selected = "selected";
                            }else{
                                $selected = "";
                            }
                          echo ' <option value="'.$roww['lm_id'].'"  '.$selected.'>'.$roww['lm_name'].'</option>';
                      }
                      ?>
                    
                  </select>
                </div>
          </div>
      <div class="layui-form-item">
            <label class="layui-form-label">栏目类型</label>
            <div class="layui-input-block" style="width: 80%;">
                <select name="lm_pagetype"   lay-filter="test">
                  <?php
                  $sql = "select * from tm_pagetype ";
                  $rss =$DB->query($sql);
                  while ($roww = $rss->fetch()){
                      if($row['lm_pagetype'] == $roww['pt_id']){
                          $selected = "selected";
                      }else{
                          $selected = "";
                      }
                      echo ' <option value="'.$roww['pt_id'].'"  '.$selected.'>'.$roww['pt_name'].'</option>';
                  }
                  ?>
                  <option value="0" <?=$row['lm_pagetype']==0?"selected":""?>>自定义模板</option>
              </select>
            </div>
      </div>
    
       <div class="layui-form-item" id="zdy_pagemodel" style="<?=$row['lm_pagetype']==0?"":"display: none;"?>">
		<label class="layui-form-label">模板文件名称</label>
		<div class="layui-input-block" style="width: 80%;">
                    <input type="text" name="lm_pagemodel" placeholder="输入您放置在模板文件夹下面的模板文件名称 " value="<?=$row['lm_pagemodel']?>" id="lm_pagemodel" class="layui-input">
		</div>
	</div>
    
    
      
    
     <div class="layui-form-item">
		<label class="layui-form-label">排序值</label>
		<div class="layui-input-block" style="width: 80%;">
			<input type="number" name="lm_sort" placeholder="数值越高 越前面" id="lm_sort"  value="<?=$row['lm_sort']?>" class="layui-input">
		</div>
	</div>
    
      <div class="layui-form-item">
            <label class="layui-form-label">封面页</label>
            <div class="layui-input-block">
                <input type="checkbox"  title="是否编辑" checked  lay-filter="pagee">
            </div>
  </div>
    
    <br><br>
    <div class="layui-form-item" id="edit_page" >
		<label class="layui-form-label">编辑封面</label>
		<div class="layui-input-block" style="width: 80%;">
			
                        <script type="text/javascript" charset="utf-8" src="../../ueditor/ueditor.config.js"></script>
                        <script type="text/javascript" charset="utf-8" src="../../ueditor/ueditor.all.min.js"> </script>
                        <script type="text/javascript" charset="utf-8" src="../../ueditor/lang/zh-cn/zh-cn.js"></script>
                            <script id="editor" name="editor" type="text/plain" width="100%" height="300px;" ><?=$row['lm_text']?></script>
                            <script>  var ue = UE.getEditor('editor');</script>
		</div>
	</div> 
    
    
     
	<div class="layui-form-item">
		<div class="layui-input-block">
                    <button type="submit" class="layui-btn" lay-submit >保存编辑</button>
			<button type="reset" class="layui-btn layui-btn-primary">重置</button>
		</div>
	</div>
</form>
<!-- 编辑栏目结束 -->
        
        <?php
}else{
    ?>
        
        <!-- 添加栏目开始 -->
<form method="POST" action="?act=add" class="layui-form" style="margin-top: 10px;display: block;">

    
	<div class="layui-form-item">
		<label class="layui-form-label">栏目名称</label>
                <div class="layui-input-block" style="width: 80%;">
			<input type="text" name="lm_name" placeholder="请输入栏目名称" id="lm_name" class="layui-input">
		</div>
                
	</div>
        <div class="layui-form-item">
		<label class="layui-form-label">栏目副标题</label>
		<div class="layui-input-block" style="width: 80%;">
			<input type="text" name="lm_fname" placeholder="栏目副标题" value="<?=$row['lm_fname']?>"  id="lm_fname" class="layui-input">
		</div>
	</div>
         <div class="layui-form-item">
		<label class="layui-form-label">栏目描述</label>
                <div class="layui-input-block" style="width: 80%;">
                    <input type="text" name="lm_desc" placeholder="用于SEO的描述" id="lm_desc" value="" class="layui-input">
		</div>
                
	</div>
      <div class="layui-form-item">
		<label class="layui-form-label">栏目关键字</label>
                <div class="layui-input-block" style="width: 80%;">
                    <input type="text" name="lm_key" placeholder="用于SEO的关键字" id="lm_key" value="" class="layui-input">
		</div>
                
	</div>
    
        <div class="layui-form-item">
		<label class="layui-form-label">栏目图</label>
		<div class="layui-input-block" style="width: 80%;">
	 <div class="layui-upload">
           <button type="button" class="layui-btn" id="test1">上传图片</button>
           <div class="layui-upload-list">
               <img class="layui-upload-img" id="demo1" src="" style="width: 80px; height: 80px;">
             <p id="demoText"></p>
           </div>
         </div> 
		</div>
                <input type="hidden" name='lm_images' value="" id='lm_images'>
	</div>
    
        <div class="layui-form-item">
		<label class="layui-form-label">栏目别名</label>
		<div class="layui-input-block" style="width: 80%;">
			<input type="text" name="lm_pyname" placeholder="请输入栏目别名 *为空默认为拼音" id="lm_pyname" class="layui-input">
		</div>
	</div>
              <div class="layui-form-item">
		<label class="layui-form-label">文章模板</label>
		<div class="layui-input-block" style="width: 80%;">
			<input type="text" name="lm_articlemodel" placeholder="本栏目下文章展示模板" value="article_article.html"  id="lm_articlemodel" class="layui-input">
		</div>
	</div>
      <div class="layui-form-item">
            <label class="layui-form-label">栏目类型</label>
            <div class="layui-input-block" style="width: 80%;">
                <select name="lm_pagetype"   lay-filter="test">
                  <?php
                  $sql = "select * from tm_pagetype";
                  $rs =$DB->query($sql);
                  while ($row = $rs->fetch()){
                      echo ' <option value="'.$row['pt_id'].'">'.$row['pt_name'].'</option>';
                  }
                  ?>
                  <option value="0">自定义模板</option>
              </select>
            </div>
      </div>
    
    
       <div class="layui-form-item" id="zdy_pagemodel" style="display: none;">
		<label class="layui-form-label">模板文件名称</label>
		<div class="layui-input-block" style="width: 80%;">
			<input type="text" name="lm_pagemodel" placeholder="输入您放置在模板文件夹下面的模板文件名称 " id="lm_pagemodel" class="layui-input">
		</div>
	</div>
    
    
      
    
        <div class="layui-form-item">
                <label class="layui-form-label">上级栏目</label>
                <div class="layui-input-block" style="width: 80%;">
                    <select name="lm_parent">
                          <option value="0">无</option>
                      <?php
                      $sql = "select * from tm_lanmulist where lm_parent is null or lm_parent =0";
                      $rs =$DB->query($sql);
                      while ($row = $rs->fetch()){
                          echo ' <option value="'.$row['lm_id'].'">'.$row['lm_name'].'</option>';
                      }
                      ?>
                    
                  </select>
                </div>
          </div>
     <div class="layui-form-item">
		<label class="layui-form-label">排序值</label>
		<div class="layui-input-block" style="width: 80%;">
			<input type="number" name="lm_sort" placeholder="数值越高 越前面" id="lm_sort" class="layui-input">
		</div>
	</div>
    
      <div class="layui-form-item">
    <label class="layui-form-label">封面页</label>
    <div class="layui-input-block">
      <input type="checkbox"  title="是否编辑"   lay-filter="pagee">
    </div>
  </div>
    
    <div class="layui-form-item" id="edit_page" style="display: none;">
		<label class="layui-form-label">编辑封面</label>
		<div class="layui-input-block" style="width: 80%;">
			
                        <script type="text/javascript" charset="utf-8" src="../../ueditor/ueditor.config.js"></script>
                        <script type="text/javascript" charset="utf-8" src="../../ueditor/ueditor.all.min.js"> </script>
                        <script type="text/javascript" charset="utf-8" src="../../ueditor/lang/zh-cn/zh-cn.js"></script>
                            <script id="editor" name="editor" type="text/plain" width="100%" height="300px;" ></script>
                            <script>  var ue = UE.getEditor('editor');</script>
		</div>
	</div> 
    
    
     
	<div class="layui-form-item">
		<div class="layui-input-block">
                    <button type="submit" class="layui-btn" lay-submit >保存栏目</button>
			<button type="reset" class="layui-btn layui-btn-primary">重置</button>
		</div>
	</div>
</form>
<!-- 添加栏目结束 -->
        <?php
}
?>




        </body></html><!-- 
<script type="text/javascript" src="../plugins/layui/layui.js"></script>-->

<script>
//Demo
layui.use('form', function(){
  var form = layui.form;

  form.on('select(test)', function(data){
      var v = data.value;
      if(v == 0){
          $("#zdy_pagemodel").show();
      }else{
          $("#lm_pagemodel").val("");
            $("#zdy_pagemodel").hide();
      }
  });
  //pagee
   form.on('checkbox(pagee)', function(data){
      
     if(data.elem.checked){
       
         $("#edit_page").show();
     }else{
         $("#edit_page").hide();
     }
  });
});
layui.use('upload', function(){
    var upload = layui.upload;
     //普通图片上传
        var uploadInst = upload.render({
          elem: '#test1'
          ,url: '/upload/'
          ,before: function(obj){
            //预读本地文件示例，不支持ie8
            obj.preview(function(index, file, result){
              $('#demo1').attr('src', result); //图片链接（base64）
            });
          }
          ,done: function(res){
            //如果上传失败
            if(res.code > 0){
              return layer.msg('上传失败');
            }
            //上传成功
            $("#lm_images").val(res.data.src);
            //alert($("#article_images").val());
          }
          ,error: function(){
            //演示失败状态，并实现重传
            var demoText = $('#demoText');
            demoText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-mini demo-reload">重试</a>');
            demoText.find('.demo-reload').on('click', function(){
              uploadInst.upload();
            });
          }
        });
    
})
/*
layui.use('upload', function(){
    alert("444");
        var $ = layui.jquery
        ,upload = layui.upload;

        //普通图片上传
        var uploadInst = upload.render({
          elem: '#test1'
          ,url: '/upload/'
          ,before: function(obj){
            //预读本地文件示例，不支持ie8
            obj.preview(function(index, file, result){
              $('#demo1').attr('src', result); //图片链接（base64）
            });
          }
          ,done: function(res){
            //如果上传失败
            if(res.code > 0){
              return layer.msg('上传失败');
            }
            //上传成功
            $("#article_images").val(res.data.src);
            //alert($("#article_images").val());
          }
          ,error: function(){
            //演示失败状态，并实现重传
            var demoText = $('#demoText');
            demoText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-mini demo-reload">重试</a>');
            demoText.find('.demo-reload').on('click', function(){
              uploadInst.upload();
            });
          }
        });
 )}*/
</script>