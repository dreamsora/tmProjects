<?php
include '../admintm.php';

if(!empty($_GET['act']) && $_GET['act'] == "add"){
    $admin_phone = daddslashes($_POST['admin_phone']);
    $admin_qq = daddslashes($_POST['admin_qq']);
    $admin_eamil = daddslashes($_POST['admin_eamil']);
    
    if(!empty($_POST['admin_pass']) && $_POST['admin_pass'] != ""){
        $pass = daddslashes($_POST['admin_pass']);
        $sql = "update tm_admin set admin_phone ='$admin_phone',admin_qq='$admin_qq',admin_eamil='$admin_eamil',admin_pass='$pass' where admin_id =".$adminrow['admin_id'];
    }else{
         $sql = "update tm_admin set admin_phone ='$admin_phone',admin_qq='$admin_qq',admin_eamil='$admin_eamil' where admin_id =".$adminrow['admin_id'];
    }
    if($DB->exec($sql)){
         exit('<script>alert("修改成功！");
            var index=parent.layer.getFrameIndex(window.name);
            
                parent.layer.close(index);</script>');
    }else{
         exit('<script>alert("修改失败！");
            var index=parent.layer.getFrameIndex(window.name);
            
                parent.layer.close(index);</script>');
    }
    
}

?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title>Table</title>
                <link rel="stylesheet" href="../layui/css/layui.css">
                
<script src="../layui/layui.js"></script>
<script src="../layui/jquery-1.8.2.min.js"></script>
	</head>

        <body>

<form method="POST" action="?act=add" class="layui-form" style="margin-top: 10px;display: block;">

    
	<div class="layui-form-item">
		<label class="layui-form-label">管理员用户名</label>
                <div class="layui-input-block" style="width: 80%;">
                    <input type="text" name="admin_user" placeholder="" disabled value="<?=$adminrow['admin_user']?>" class="layui-input">
		</div>
	</div>
    
    
     
        <div class="layui-form-item">
		<label class="layui-form-label">管理员密码</label>
		<div class="layui-input-block" style="width: 80%;">
			<input type="text" name="admin_pass" placeholder="不修改请留空"  class="layui-input">
		</div>
	</div>
      
    <div class="layui-form-item">
		<label class="layui-form-label">管理员手机</label>
		<div class="layui-input-block" style="width: 80%;">
			<input type="text" name="admin_phone" placeholder="<?=$adminrow['admin_phone']?>"  class="layui-input">
		</div>
	</div>
    
    <div class="layui-form-item">
		<label class="layui-form-label">管理员QQ</label>
		<div class="layui-input-block" style="width: 80%;">
			<input type="text" name="admin_qq" placeholder="<?=$adminrow['admin_qq']?>"  class="layui-input">
		</div>
	</div>
   
        <div class="layui-form-item">
		<label class="layui-form-label">管理员邮箱</label>
		<div class="layui-input-block" style="width: 80%;">
			<input type="text" name="admin_eamil" placeholder="<?=$adminrow['admin_eamil']?>"  class="layui-input">
		</div>
	</div>
      
    
    
     
	<div class="layui-form-item">
		<div class="layui-input-block">
                    <button type="submit" class="layui-btn" lay-submit >保存修改</button>
			<button type="reset" class="layui-btn layui-btn-primary">重置</button>
		</div>
	</div>
</form>





        </body></html>
<script>

</script>
<script>
//Demo
layui.use('form', function(){
  var form = layui.form();
});
layui.use('upload', function(){

  var $ = layui.jquery
  ,upload = layui.upload;
  
  //普通图片上传
  var uploadInst = upload.render({
    elem: '#test1'
    ,url: '/upload/'
    ,size:2048
    ,before: function(obj){
      //预读本地文件示例，不支持ie8
      obj.preview(function(index, file, result){
        $('#demo1').attr('src', result); //图片链接（base64）
      });
    }
    ,done: function(res){
      //如果上传失败
      if(res.code > 0){
        return layer.msg('上传失败');
      }
      //上传成功
      $("#slides_images").val(res.data.src);
      //alert($("#article_images").val());
    }
    ,error: function(){
      //演示失败状态，并实现重传
      var demoText = $('#demoText');
      demoText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-mini demo-reload">重试</a>');
      demoText.find('.demo-reload').on('click', function(){
        uploadInst.upload();
      });
    }
  });
 });

</script>