<?php
include '../admintm.php';

if(!empty($_GET['act']) && $_GET['act'] == "add"){
  //  exit(var_dump($_POST));
    unset($_POST['file']);
    $_POST['slides_images'] = empty($_POST['slides_images'])?"default.png":daddslashes($_POST['slides_images']);
    if(insert('tm_slides',$_POST)){
        exit('<script>alert("添加成功！");
            var index=parent.layer.getFrameIndex(window.name);
            
                parent.layer.close(index);</script>');
    }else{
        exit('<script>alert("添加失败！");
            var index=parent.layer.getFrameIndex(window.name);
            
                parent.layer.close(index);</script>');
    }
}elseif(!empty($_GET['act']) && $_GET['act'] == "edit_add"){
    $edata = $_POST;
    $id=intval($_GET['id']);
    $set = "";
    foreach ($edata as $k => $v){
        if($k == 'file')            continue;
        if($set != ""){
            $set = $set.",";
        }
        $set .= $k."='".$v."'";
    }
    $sql = "update tm_slides set $set where id =".$id;
   // exit($sql);
    if($DB->exec($sql)){
        exit('<script>alert("修改成功！");
            var index=parent.layer.getFrameIndex(window.name);
            
                parent.layer.close(index);</script>');
    }else{
        exit('<script>alert("修改失败！");
            var index=parent.layer.getFrameIndex(window.name);
            
                parent.layer.close(index);</script>');
    }
    
}




?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title>Table</title>
                <link rel="stylesheet" href="../layui/css/layui.css">
                
<script src="../layui/layui.js"></script>
<script src="../layui/jquery-1.8.2.min.js"></script>
	</head>

        <body>

<?php
if(!empty($_GET['id']) && $_GET['id'] != "" && intval($_GET['id']) >0){
    $id = intval($_GET['id']);
    $row = $DB->query("select * from tm_slides where id=".$id)->fetch();
 
    ?>
        <!-- 编辑栏目开始 -->
<form method="POST" action="?act=edit_add&id=<?=$id?>" class="layui-form" style="margin-top: 10px;display: block;">
<div class="layui-form-item">
		<label class="layui-form-label">幻灯片名称</label>
                <div class="layui-input-block" style="width: 80%;">
                    <input type="text" name="slides_name" placeholder="请输入幻灯片名称" value="<?=$row['slides_name']?>" id="slides_name" class="layui-input">
		</div>
                
	</div>
    
     <div class="layui-form-item">
		<label class="layui-form-label">幻灯片图片</label>
		<div class="layui-input-block" style="width: 80%;">
	 <div class="layui-upload">
           <button type="button" class="layui-btn" id="test1">上传图片</button>
           <div class="layui-upload-list">
               <img class="layui-upload-img" id="demo1" src="<?=ARTICLE_IMG_PATH.$row['slides_images']?>" style="width: 80px; height: 80px;">
             <p id="demoText"></p>
             <input type="text" name='slides_images' value="<?=$row['slides_images']?>" id='slides_images'> * 如果图片过大,请将图片上传到upload/img/文件夹下面 然后把图片名称填在此处
           </div>
         </div> 
		</div>
                <!--<input type="hidden" name='slides_images'  value="<?=$row['slides_images']?>"  id='slides_images'>-->
	</div>
     
        <div class="layui-form-item">
		<label class="layui-form-label">幻灯片链接</label>
		<div class="layui-input-block" style="width: 80%;">
			<input type="text" name="slides_url"  value="<?=$row['slides_url']?>" placeholder="点击幻灯片跳转的地址" id="slides_url" class="layui-input">
		</div>
	</div>
    
    
      <div class="layui-form-item">
            <label class="layui-form-label">跳转类型</label>
            <div class="layui-input-block" style="width: 80%;">
                <select name="slides_target"   lay-filter="test">
                  <option value="_blank" <?=$row['slides_target']=="_blank"?"selected":""?> >_blank 在新窗口中打开被链接文档。</option>
                  <option value="_self" <?=$row['slides_target']=="_self"?"selected":""?> >_self 在相同的框架中打开被链接文档。</option>
                  <option value="_parent" <?=$row['slides_target']=="_parent"?"selected":""?> >_parent 在父框架集中打开被链接文档。</option>
                  <option value="_top" <?=$row['slides_target']=="_top"?"selected":""?> >_top 在整个窗口中打开被链接文档。</option>
                   <option value="framename" <?=$row['slides_target']=="framename"?"selected":""?> >framename 在指定的框架中打开被链接文档（链接地址填iframe的name值）。</option>
              </select>
            </div>
      </div>
    
       <div class="layui-form-item" id="zdy_pagemodel" style="display: none;">
		<label class="layui-form-label">排序值</label>
		<div class="layui-input-block" style="width: 80%;">
                    <input type="number" name="slides_sort" placeholder="5"  value="<?=$row['slides_sort']?>" value="5" id="slides_sort" class="layui-input">
		</div>
	</div>
    
      <div class="layui-form-item">
            <label class="layui-form-label">幻灯片状态</label>
            <div class="layui-input-block" style="width: 80%;">
                <select name="slides_status"   lay-filter="test">
                  <option value="0"  <?=$row['slides_status']=="0"?"selected":""?> >关闭</option>
                  <option value="1"  <?=$row['slides_status']=="1"?"selected":""?> >开启</option>
   
              </select>
            </div>
      </div>
      
    
    
     
	<div class="layui-form-item">
		<div class="layui-input-block">
                    <button type="submit" class="layui-btn" lay-submit >保存修改</button>
			<button type="reset" class="layui-btn layui-btn-primary">重置</button>
		</div>
	</div>
</form>
<!-- 编辑栏目结束 -->
        
        <?php
}else{
    ?>
        
        <!-- 添加栏目开始 -->
<form method="POST" action="?act=add" class="layui-form" style="margin-top: 10px;display: block;">

    
	<div class="layui-form-item">
		<label class="layui-form-label">幻灯片名称</label>
                <div class="layui-input-block" style="width: 80%;">
			<input type="text" name="slides_name" placeholder="请输入幻灯片名称" id="slides_name" class="layui-input">
		</div>
                
	</div>
    
     <div class="layui-form-item">
		<label class="layui-form-label">幻灯片图片</label>
		<div class="layui-input-block" style="width: 80%;">
	 <div class="layui-upload">
           <button type="button" class="layui-btn" id="test1">上传图片</button>
           <div class="layui-upload-list">
               <img class="layui-upload-img" id="demo1" src="" style="width: 80px; height: 80px;">
             <p id="demoText"></p>
             <input type="text" name='slides_images' value="" id='slides_images'> * 如果图片过大,请将图片上次到upload/img/文件夹下面 然后把图片名称填在此处
           </div>
         </div> 
		</div>
                <input type="hidden" name='slides_images' value="" id='slides_images'>
	</div>
     
        <div class="layui-form-item">
		<label class="layui-form-label">幻灯片链接</label>
		<div class="layui-input-block" style="width: 80%;">
			<input type="text" name="slides_url" placeholder="点击幻灯片跳转的地址" id="slides_url" class="layui-input">
		</div>
	</div>
    
    
      <div class="layui-form-item">
            <label class="layui-form-label">跳转类型</label>
            <div class="layui-input-block" style="width: 80%;">
                <select name="slides_target"   lay-filter="test">
                  <option value="_blank">_blank 在新窗口中打开被链接文档。</option>
                  <option value="_self">_self 在相同的框架中打开被链接文档。</option>
                  <option value="_parent">_parent 在父框架集中打开被链接文档。</option>
                  <option value="_top">_top 在整个窗口中打开被链接文档。</option>
                   <option value="framename">framename 在指定的框架中打开被链接文档（链接地址填iframe的name值）。</option>
              </select>
            </div>
      </div>
    
       <div class="layui-form-item" id="zdy_pagemodel" style="display: none;">
		<label class="layui-form-label">排序值</label>
		<div class="layui-input-block" style="width: 80%;">
                    <input type="number" name="slides_sort" placeholder="5" value="5" id="slides_sort" class="layui-input">
		</div>
	</div>
    
      <div class="layui-form-item">
            <label class="layui-form-label">幻灯片状态</label>
            <div class="layui-input-block" style="width: 80%;">
                <select name="slides_status"   lay-filter="test">
                  <option value="0">关闭</option>
                  <option value="1" selected>开启</option>
   
              </select>
            </div>
      </div>
      
    
    
     
	<div class="layui-form-item">
		<div class="layui-input-block">
                    <button type="submit" class="layui-btn" lay-submit >添加幻灯片</button>
			<button type="reset" class="layui-btn layui-btn-primary">重置</button>
		</div>
	</div>
</form>
<!-- 添加栏目结束 -->
        <?php
}
?>




        </body></html>
<script>

</script>
<script>
//Demo
layui.use('form', function(){
  var form = layui.form();
});
layui.use('upload', function(){

  var $ = layui.jquery
  ,upload = layui.upload;
  
  //普通图片上传
  var uploadInst = upload.render({
    elem: '#test1'
    ,url: '/upload/'
    ,size:2048
    ,before: function(obj){
      //预读本地文件示例，不支持ie8
      obj.preview(function(index, file, result){
        $('#demo1').attr('src', result); //图片链接（base64）
      });
    }
    ,done: function(res){
      //如果上传失败
      if(res.code > 0){
        return layer.msg('上传失败');
      }
      //上传成功
      $("#slides_images").val(res.data.src);
      //alert($("#article_images").val());
    }
    ,error: function(){
      //演示失败状态，并实现重传
      var demoText = $('#demoText');
      demoText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-mini demo-reload">重试</a>');
      demoText.find('.demo-reload').on('click', function(){
        uploadInst.upload();
      });
    }
  });
 });

</script>