<?php
include '../admintm.php';
if($adminrow['admin_qx_system'] != 1){
    exit("您没有该页面的权限！");
}

if(!empty($_GET['act']) && $_GET['act'] == 'edit'){
    $id = intval($_GET['id']);
    $link_name = daddslashes($_POST['link_name']);
    $link_url = daddslashes($_POST['link_url']);
    $link_sort = daddslashes($_POST['link_sort']);
    $sql = "update tm_links set link_name ='$link_name',link_url='$link_url',link_sort='$link_sort' where link_id =".$id;
     if($DB->exec($sql)){
        exit('<script>alert("修改友情链接成功！");window.location.href="links.php";</script>');
    }else{
        exit('<script>alert("修改友情链接失败！");window.history.go(-1);</script>');
    }
    
}elseif(!empty($_GET['act']) && $_GET['act'] == "add"){
    $link_name = daddslashes($_POST['link_name']);
    $link_url = daddslashes($_POST['link_url']);
    $link_sort = daddslashes($_POST['link_sort']);
    $sql = "insert into tm_links(link_name,link_url,link_sort,link_status) values('$link_name','$link_url','$link_sort',1)";
    if($DB->exec($sql)){
          exit('<script>alert("添加友情链接成功！");window.location.href="links.php";</script>');
    }else{
        exit('<script>alert("添加友情链接失败！");window.history.go(-1);</script>');
    }
    
    
}elseif(!empty($_GET['act']) && $_GET['act'] =="delete"){
     $id = intval($_GET['id']);
     $sql = 'delete from tm_links where link_id='.$id;
      if($DB->exec($sql)){
          exit('<script>alert("删除友情链接成功！");window.location.href="links.php";</script>');
    }else{
        exit('<script>alert("删除友情链接失败！");window.history.go(-1);</script>');
    }
}

?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title>Table</title>
		<link rel="stylesheet" href="../plugins/layui/css/layui.css" media="all" />
		<link rel="stylesheet" href="../css/global.css" media="all">
		<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="../css/table.css" />
	</head>

	<body>
		<div class="admin-main">

			<fieldset class="layui-elem-field">
				<legend>友情链接列表    <a href="javascript: location.reload();"  class="layui-btn layui-btn-primary layui-btn-mini" ><i class="layui-icon">&#x1002;</i>  刷新</a></legend>
				<div class="layui-field-box">
					<table class="site-table table-hover">
						<thead>
							<tr>
						
								<th>ID</th>
								<th>友情链接名称</th>
								<th>友情链接地址</th>
								<th>排序值</th>
                                                                
								
								<th>操作</th>
							</tr>
						</thead>
						<tbody>
                                                    
                                                    <?php
                                                    $sql = "select * from tm_links";
                                                    $rs = $DB->query($sql);
                                                    while ($row = $rs->fetch()){
                                                        ?>
                                                            <tr>
                                                <form action="?act=edit&id=<?=$row['link_id']?>" method="POST">
								
                                                    <td><input type="text" name="link_id" value="<?=$row['link_id']?>" disabled /></td>
                                                          <td ><input  type="text" name="link_name" value="<?=$row['link_name']?>" /></td>
                                                                <td><input type="text" name="link_url" value="<?=$row['link_url']?>" /></td>
                                                        <td><input type="number" name="link_sort" value="<?=$row['link_sort']?>" /></td>
                                                            
								
								<td>
                                                                    
                                                                    <input type="submit" value="修改保存"  class="layui-btn layui-btn-normal layui-btn-mini">
                                                                   <a href="?act=delete&id=<?=$row['link_id']?>" data-id="1" data-opt="del" class="layui-btn layui-btn-danger layui-btn-mini">删除</a>
								</td>
						</form>	
                                                </tr>
                                                            <?php
                                                     
                                                    }
                                                    ?>
                                                <tr style="border: 1px salmon solid;">
                                                <form action="?act=add" method="POST">
								
                                                    <td>输入变量信息：</td>
                                                          <td ><input  type="text" name="link_name" value="" /></td>
                                                                <td><input type="text" name="link_url" value="" /></td>
                                                   
                                                                   <td><input type="number" name="link_sort" value="" /></td>
                                                            
								
								<td>
                                                                    
                                                                    <input type="submit" value="添加友情链接"  class="layui-btn layui-btn-normal layui-btn-mini">
                                                              </td>
						</form>	
                                                </tr>
						</tbody>
					</table>

				</div>
			</fieldset>
			<div class="admin-table-page">
				<div id="page" class="page">
				</div>
			</div>
		</div>
            <script src="../layui/jquery-1.8.2.min.js"></script>
		<script type="text/javascript" src="../plugins/layui/layui.js"></script>
		<script>
			layui.config({
				base: 'plugins/layui/modules/'
			});
                        layui.use(['icheck', 'laypage','layer'], function() {
				var $ = layui.jquery,
					laypage = layui.laypage,
					layer = parent.layer === undefined ? layui.layer : parent.layer;
				$('input').iCheck({
					checkboxClass: 'icheckbox_flat-green'
				});
                                
                                
                            })
			
                 
		</script>
	</body>

</html>