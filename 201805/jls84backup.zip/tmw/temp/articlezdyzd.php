<?php
include '../admintm.php';
if($adminrow['admin_qx_system'] != 1){
    exit("您没有该页面的权限！");
}
function getzdytype($type){
    if($type == "text"){
        return "多行文本";
    }
    if($type == "file"){
        return "附件";
    }
    if($type == "images"){
        return "图片";
    }
    if($type == "txt"){
        return "单行文本";
    }
}
if(!empty($_GET['act']) && $_GET['act'] == "add"){
  $articlezdyzd_name = daddslashes($_POST['articlezdyzd_name']);
  $articlezdyzd_kv = daddslashes($_POST['articlezdyzd_kv']);

   $sql = "insert into tm_articlezdyzd values(null,'$articlezdyzd_name','$articlezdyzd_kv')";
  if($DB->exec($sql)){
      /*  exit('<script>alert("保存成功！");
            var index=parent.layer.getFrameIndex(window.name);
            
                parent.layer.close(index);</script>');*/
     exit('<script>alert("保存成功！");window.location.href="./articlezdyzd.php?act=show";</script>');
    }else{
        exit('<script>alert("保存失败！");window.history.go(-1);</script>');
       /* exit($sql);
        exit('<script>alert("保存失败！");
            var index=parent.layer.getFrameIndex(window.name);
            
                parent.layer.close(index);</script>');*/
    }
  
}elseif(!empty($_GET['act']) && $_GET['act'] == "edit_add"){
    $articlezdyzd_id = intval($_POST['articlezdyzd_id']);
   $articlezdyzd_name = daddslashes($_POST['articlezdyzd_name']);
  $articlezdyzd_kv = daddslashes($_POST['articlezdyzd_kv']);
    $sql = "update tm_articlezdyzd set articlezdyzd_name ='$articlezdyzd_name',articlezdyzd_kv='$articlezdyzd_kv' where articlezdyzd_id = ".$articlezdyzd_id;
     if($DB->exec($sql)){
     exit('<script>alert("保存成功！");window.location.href="./articlezdyzd.php?act=show";</script>');
    }else{
      //  exit($sql);
        exit('<script>alert("保存失败！");window.history.go(-1);</script>');
    }
}elseif(!empty($_GET['act']) && $_GET['act'] == "delete"){
    $articlezdyzd_id = intval($_GET['id']);
  
    $sql = "delete from tm_articlezdyzd where articlezdyzd_id = ".$articlezdyzd_id;
     if($DB->exec($sql)){
     exit('<script>alert("删除成功！");window.location.href="./articlezdyzd.php?act=show";</script>');
    }else{
      //  exit($sql);
        exit('<script>alert("删除失败！");window.history.go(-1);</script>');
    }
}



 $i = 0;
?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title>Table</title>
                <link rel="stylesheet" href="../layui/css/layui.css">
                
<script src="../layui/layui.js"></script>
<script src="../layui/jquery-1.8.2.min.js"></script>
<style>
    table{
        text-align: center
    }
    table tr{
        border: 1px solid black;
    }
    table td{
        border: 1px solid black;
    }
    thead tr{
        font-size: 18px;
        background-color: grey;
       
    }
</style>
	</head>

        <body>

<?php
if(!empty($_GET['id']) && $_GET['id'] != "" && intval($_GET['id']) >0){
    $id = intval($_GET['id']);
    $row = $DB->query("select * from tm_articlezdyzd where articlezdyzd_id =".$id)->fetch();
    
    ?>
              <blockquote class="layui-elem-quote">
                            
                            
				<a href="?act=show" 	class="layui-btn layui-btn-small">
					<i class="layui-icon">&#xe647;</i> 展示所有字段
				</a>
				<a href="javascript: location.reload();"  class="layui-btn layui-btn-normal" >
					<i class="layui-icon">&#x1002;</i>  刷新页面
				</a>
                         
			</blockquote>
        <!-- 编辑栏目开始 -->
<form method="POST" action="?act=edit_add" class="layui-form" style="margin-top: 10px;display: block;"  onsubmit="return checksub()">

    <input type="hidden" value="<?=$id?>" name="articlezdyzd_id">
	<div class="layui-form-item">
		<label class="layui-form-label">字段模板名称</label>
                <div class="layui-input-block" style="width: 80%;">
                    <input type="text" name="articlezdyzd_name" placeholder="将此字段保存为一个模板" id="articlezdyzd_name" value="<?=$row['articlezdyzd_name']?>" class="layui-input">
                        <input type="hidden" name="articlezdyzd_kv" id="articlezdyzd_kv" class="layui-input">
		</div>
	</div>
       
     
    <?php
                    $str = $row['articlezdyzd_kv'];
                    $arr = explode("|", $str);
                   
                    foreach ($arr as $value) {
                        $kv = explode(":", $value);
                        ?>
                            <div class="layui-form-item zdykeys">
                <div class="layui-input-block" style="width:100%;">
                        <input type="text"  placeholder="字段名称(用于展示)" id="zd_name_<?=$i?>" class="layui-input zd_name" value="<?=$kv[0]?>" style="display: inline-block;width: 30%;">
                        <input type="text"  placeholder="key（用于数据库）" id="zd_key_<?=$i?>" class="layui-input zd_key"  value="<?=$kv[1]?>" style="display: inline-block;width: 30%;">
                        <input type="radio" name="zd_type_<?=$i?>" value="txt" title="文本" <?=$kv[2]=="txt"?"checked":""?> ><input type="radio" name="zd_type_<?=$i?>"  <?=$kv[2]=="text"?"checked":""?> value="text" title="多行文本">
                        <input type="radio" name="zd_type_<?=$i?>" value="images" title="图片"  <?=$kv[2]=="images"?"checked":""?>><input type="radio" name="zd_type_<?=$i?>"  <?=$kv[2]=="file"?"checked":""?> value="file" title="附件">
                        
		</div>
	</div>
                        <?php
                        $i++;
                    }      
                    $i--;
                    
                    ?>
    
     <div class="layui-form-item" style="text-align: center;" id="addzd_div">
        <a href="javascript:;" 	class="layui-btn layui-btn-danger layui-btn-sm" id="addzd">
					<i class="layui-icon">&#xe608;</i> 添加字段
				</a>
     </div>

	<div class="layui-form-item">
		<div class="layui-input-block">
                    <button type="submit" class="layui-btn" lay-submit >保存编辑</button>
			<button type="reset" class="layui-btn layui-btn-primary">重置</button>
		</div>
	</div>
</form>
<!-- 编辑栏目结束 -->
        
        <?php
}elseif(!empty ($_GET['act']) && $_GET['act'] == "show"){
    
    $sql = "select * from tm_articlezdyzd";
    $rs = $DB->query($sql);
 
    ?>

                        <blockquote class="layui-elem-quote">
				<a href="?" 	class="layui-btn layui-btn-small">
					<i class="layui-icon">&#xe608;</i> 添加字段模板
				</a>
				<a href="javascript: location.reload();"  class="layui-btn layui-btn-normal" >
					<i class="layui-icon">&#x1002;</i>  刷新页面
				</a>
                         
			</blockquote>    


<div style="padding: 20px; background-color: #F2F2F2;">
  <div class="layui-row layui-col-space15">
      <?php
    while ($row = $rs->fetch()){
    ?>
       <div class="layui-col-md3">
      <div class="layui-card">
          <div class="layui-card-header"><?=$row['articlezdyzd_name']?>
              &nbsp;&nbsp;|&nbsp;&nbsp;<a href="?act=edit&id=<?=$row['articlezdyzd_id']?>" style="color:blue;cursor: pointer">编辑</a>
              &nbsp;&nbsp;|&nbsp;&nbsp;<a href="?act=delete&id=<?=$row['articlezdyzd_id']?>" onclick="return  confirm('确定要删除吗？')" style="color:red;cursor: pointer">删除</a>
          </div>
        <div class="layui-card-body">
            <table class="site-table table-hover" style="width: 100%;">
                <thead>
                    <tr>
                        <td >字段名称</td>
                        <td>字段KEY</td>
                        <td>字段类型</td>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $str = $row['articlezdyzd_kv'];
                    $arr = explode("|", $str);
                    foreach ($arr as $value) {
                        $kv = explode(":", $value);
                        ?>
                             <tr>
                        <td><?=$kv[0]?></td>
                        <td><?=$kv[1]?></td>
                        <td><?=getzdytype($kv[2])?></td>
                    </tr>
                        <?php
                    }
                    
                    ?>
                    <tr>
                        <td colspan="3">文章页面调用使用：{tm:article.字段KEY/}</td>
                     
                    </tr>
                    <tr style="text-align: left;">
                        <td colspan="3">修改SQL：<font color=green>update tm_articlezdyzd set articlezdyzd_kv='<?=$row['articlezdyzd_kv']?>' where articlezdyzd_id = <?=$row['articlezdyzd_id']?></font></td>
                    </tr>
                   
                </tbody>
            </table>
        </div>
      </div>
    </div>
      
        <?php
    }
      
      ?>
    
    
    
  </div>
</div> 
        
    <?php
    
}else{
    ?>
           <blockquote class="layui-elem-quote">
                            
                            
				<a href="?act=show" 	class="layui-btn layui-btn-small">
					<i class="layui-icon">&#xe647;</i> 展示所有字段
				</a>
				<a href="javascript: location.reload();"  class="layui-btn layui-btn-normal" >
					<i class="layui-icon">&#x1002;</i>  刷新页面
				</a>
                         
			</blockquote>
        <!-- 添加开始 -->
        <form method="POST" action="?act=add" class="layui-form" style="margin-top: 10px;display: block;" onsubmit="return checksub()">

    
	<div class="layui-form-item">
		<label class="layui-form-label">字段模板名称</label>
                <div class="layui-input-block" style="width: 80%;">
			<input type="text" name="articlezdyzd_name" placeholder="将此字段保存为一个模板" id="articlezdyzd_name" class="layui-input">
                        <input type="hidden" name="articlezdyzd_kv" id="articlezdyzd_kv" class="layui-input">
		</div>
	</div>
       
        <div class="layui-form-item zdykeys">
                <div class="layui-input-block" style="width:100%;">
                        <input type="text"  placeholder="字段名称(用于展示)" id="zd_name_0" class="layui-input zd_name" style="display: inline-block;width: 30%;">
                        <input type="text"  placeholder="key（用于数据库）" id="zd_key_0" class="layui-input zd_key"  style="display: inline-block;width: 30%;">
                        <input type="radio" name="zd_type_0" value="txt" title="文本" checked><input type="radio" name="zd_type_0" value="text" title="多行文本">
                        <input type="radio" name="zd_type_0" value="images" title="图片"><input type="radio" name="zd_type_0" value="file" title="附件">
                        
		</div>
	</div>
     <div class="layui-form-item" style="text-align: center;" id="addzd_div">
        <a href="javascript:;" 	class="layui-btn layui-btn-danger layui-btn-sm" id="addzd">
					<i class="layui-icon">&#xe608;</i> 添加字段
				</a>
     </div>
             
	<div class="layui-form-item">
		<div class="layui-input-block">
                    <button type="submit" class="layui-btn" lay-submit >保存</button>
			<button type="reset" class="layui-btn layui-btn-primary">重置</button>
		</div>
	</div>
</form>
<!-- 添加栏目结束 -->
        <?php
}
?>




        </body></html><script type="text/javascript" src="../plugins/layui/layui.js"></script>
<script>

</script>
<script>
function checksub(){
    if($("#articlezdyzd_name").val() == ""){
        layer.alert("请输入文章自定义字段模板名称");
        return false;
    }
    var div = $(".zdykeys");
    var kv = "";
    div.each(function(e) { 
        var name = $("#zd_name_"+e).val();
        var key = $("#zd_key_"+e).val();
        var type = $("input[name='zd_type_"+e+"']:checked").val();
    
        if(name!="" && key != "" && name != null && key != null){ 
         if(kv!="") kv=kv+"|";
         kv = kv +name+":"+key+":"+type;
        }
       
       
    })
    if(kv == ""){
        layer.alert("未获取到有效的字段");
        return false;
    }
    $("#articlezdyzd_kv").val(kv);
    return true;
}
    
//Demo
layui.use('form', function(){
  var form = layui.form();

  form.on('select(test)', function(data){
      var v = data.value;
      if(v == 0){
          $("#zdy_pagemodel").show();
      }else{
          $("#lm_pagemodel").val("");
            $("#zdy_pagemodel").hide();
      }
  });
  //pagee
   form.on('checkbox(pagee)', function(data){
      
     if(data.elem.checked){
       
         $("#edit_page").show();
     }else{
         $("#edit_page").hide();
     }
     
  });
  var index = <?=$i?>;
 
  $("#addzd").click(function(){
      index++;
     var html = '   <div class="layui-form-item zdykeys">'
              + ' <div class="layui-input-block" style="width:100%;">'
               +    ' <input type="text" id="zd_name_'+index+'" placeholder="字段名称(用于展示)" id="" class="layui-input" style="display: inline-block;width: 30%;">'
                +      '  <input type="text" id="zd_key_'+index+'" placeholder="key（用于数据库）" id="" class="layui-input"  style="display: inline-block;width: 30%;">'
		+'<input type="radio" name="zd_type_'+index+'" value="txt" title="文本" checked><input type="radio" name="zd_type_'+index+'" value="text" title="多行文本">'
                     + '  <input type="radio" name="zd_type_'+index+'" value="images" title="图片"><input type="radio" name="zd_type_'+index+'" value="file" title="附件"></div>'
	+'</div>';
/*+' <input type="radio" name="zd_type_'+index+'" value="txt" title="文本" checked><input type="radio" name="zd_type_'+index+'" value="text" title="多行文本">'
                     + '  <input type="radio" name="zd_type_'+index+'" value="images" title="图片"><input type="radio" name="zd_type_'+index+'" value="file" title="附件">*/
   // alert(html);
        $("#addzd_div").before(html);
       form.render();
  })
  //监听提交
 /* form.on('submit(formDemo)', function(data){
    layer.msg(JSON.stringify(data.field));
    return false;
  });*/
});


</script>