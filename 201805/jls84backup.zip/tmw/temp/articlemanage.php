<?php

include '../admintm.php';

if(!empty($_GET['act']) && $_GET['act'] == "add"){
    //var_dump($_POST);
  //  exit();
    
    $adddata['article_title'] = daddslashes($_POST['article_title']);
    $adddata['article_description'] = daddslashes($_POST['article_description']);
    $adddata['article_keywords'] = daddslashes($_POST['article_keywords']);
    $adddata['article_lm_id'] = daddslashes(intval($_POST['article_lm_id']));
    $adddata['article_images'] = !empty($_POST['article_images'])?daddslashes($_POST['article_images']):"default.png";
    $adddata['article_imageslist'] = !empty($_POST['article_imageslist'])?daddslashes($_POST['article_imageslist']):"default.png";
    $adddata['article_text'] = daddslashes($_POST['editor']);
    $adddata['article_author'] = !empty($_POST['article_author'])?daddslashes($_POST['article_author']):"系统";
    $adddata['artice_sort'] = daddslashes($_POST['artice_sort']);
    $adddata['article_addtime'] =date("Y-m-d H:i:s");
    $adddata['article_isj_url'] = daddslashes($_POST['article_isj_url']);
    $adddata['article_zdy'] = daddslashes($_POST['article_zdy']);
    foreach ($_POST['attr'] as $k => $v){
        $adddata[$k] = 1;
    }
    
     if(insert('tm_article_list',$adddata)){
        exit('<script>alert("添加成功！");
            var index=parent.layer.getFrameIndex(window.name);
            
                parent.layer.close(index);</script>');
    }else{
        exit('<script>alert("修改失败！");
            var index=parent.layer.getFrameIndex(window.name);
            
                parent.layer.close(index);</script>');
    }
    
}elseif(!empty($_GET['act']) && $_GET['act'] == "edit_add"){
    //edit_add
   $id= intval($_GET['id']);
    $edata['article_title'] = daddslashes($_POST['article_title']);
    $edata['article_description'] = daddslashes($_POST['article_description']);
    $edata['article_keywords'] = daddslashes($_POST['article_keywords']);
    $edata['article_lm_id'] = daddslashes(intval($_POST['article_lm_id']));
    $edata['article_images'] = !empty($_POST['article_images'])? $_POST['article_images']:"default.png";
    $edata['article_imageslist'] = !empty($_POST['article_imageslist'])? str_replace("default.png,", "", $_POST['article_imageslist']):"default.png";
    $edata['article_text'] = daddslashes($_POST['editor']);
    $edata['article_author'] = !empty($_POST['article_author'])?daddslashes($_POST['article_author']):"系统";
    $edata['artice_sort'] = daddslashes($_POST['artice_sort']);
    if(!empty($_POST['article_zdy'])){
         $edata['article_zdy'] = daddslashes($_POST['article_zdy']);
    }
    //$adddata['article_addtime'] =date("Y-m-d H:i:s");
    $edata['article_isj_url'] = daddslashes($_POST['article_isj_url']);
    foreach ($_POST['attr'] as $k => $v){
        $edata[$k] = 1;
    }
     $set = "";
    foreach ($edata as $k => $v){
        if($set != ""){
            $set = $set.",";
        }
        $set .= $k."='".$v."'";
    }
    $sql = "update tm_article_list set $set where article_id =".$id;
    //exit($sql);
    if($DB->query($sql)){
        exit('<script>alert("修改成功！");
            var index=parent.layer.getFrameIndex(window.name);
            
                parent.layer.close(index);</script>');
    }else{
      //  exit($sql);
        exit('<script>alert("修改失败！");
            var index=parent.layer.getFrameIndex(window.name);
            
                parent.layer.close(index);</script>');
    }
    
}



?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title>Table</title>
                <link rel="stylesheet" href="../layui/css/layui.css">
                
<script src="../layui/layui.js"></script>
<script src="../layui/jquery-1.8.2.min.js"></script>
	</head>

<body>
    
  <?php

if(!empty($_GET['id']) && $_GET['id'] != "" && intval($_GET['id']) >0){
    $id = intval($_GET['id']);
    $arow = $DB->query("select * from tm_article_list where article_id = ".$id)->fetch();
    
    $arow['article_images'] = empty($arow['article_images'])?"default.png":$arow['article_images'];
    ?>
        
       <!-- 修改文章开始 -->
<form method="POST" action="?act=edit_add&id=<?=$id?>" class="layui-form" style="margin-top: 10px;display: block;" onsubmit="return checkaddartcile()">

    
	<div class="layui-form-item">
		<label class="layui-form-label">文章标题</label>
                <div class="layui-input-block" style="width: 80%;">
                    <input type="text" name="article_title" placeholder="请输入文章标题" id="article_title" value="<?=$arow['article_title']?>" class="layui-input" required>
		</div>
                
	</div>
     
        <div class="layui-form-item">
		<label class="layui-form-label">文章描述</label>
		<div class="layui-input-block" style="width: 80%;">
			<input type="text" name="article_description" placeholder="请输入文章描述" id="article_description" value="<?=$arow['article_description']?>"  class="layui-input">
		</div>
	</div>
    
        <div class="layui-form-item">
		<label class="layui-form-label">文章关键字</label>
		<div class="layui-input-block" style="width: 80%;">
			<input type="text" name="article_keywords" placeholder="请输入文章关键字" id="article_keywords" value="<?=$arow['article_keywords']?>"  class="layui-input">
		</div>
	</div>
    
   
        <div class="layui-form-item">
                <label class="layui-form-label">所属栏目</label>
                <div class="layui-input-block" style="width: 80%;">
                    <select name="article_lm_id">
            
                      <?php
                      $sql = "select * from tm_lanmulist ";
                      $rs =$DB->query($sql);
                      while ($row = $rs->fetch()){
                          if($row['lm_id'] == $arow['article_lm_id']){
                              $selected = "selected";
                          }else{
                              $selected = "";
                          }
                          echo ' <option value="'.$row['lm_id'].'" '.$selected.'>'.$row['lm_name'].'</option>';
                      }
                      ?>
                    
                  </select>
                </div>
          </div>

      <div class="layui-form-item">
		<label class="layui-form-label">文章缩略图</label>
		<div class="layui-input-block" style="width: 80%;">
	 <div class="layui-upload">
           <button type="button" class="layui-btn" id="test1">上传图片</button>
           <div class="layui-upload-list">
               <img class="layui-upload-img" id="demo1" src="<?=ARTICLE_IMG_PATH.$arow['article_images']?>" style="width: 80px; height: 80px;">
             <p id="demoText"></p>
           </div>
         </div> 
		</div>
                <input type="hidden" name='article_images' value="<?=$arow['article_images']?>" id='article_images'>
	</div>
    
       <div class="layui-form-item">
		<label class="layui-form-label">上传图集</label>
		<div class="layui-input-block" style="width: 80%;">
			<div class="layui-upload">
           <button type="button" class="layui-btn" id="test2">上传图片[支持多张上传]</button>
            <blockquote class="layui-elem-quote layui-quote-nm" style="margin-top: 10px;">
            预览图：
            <div class="layui-upload-list" id="demo2">
                <?php
                $list = explode(",", $arow['article_imageslist']);
                foreach ($list as $src){
                    echo '<img src="'.ARTICLE_IMG_PATH.$src.'" alt="'.$src.'" width=80px; class="layui-upload-img">';
                }
                ?>
            </div>
         </blockquote>
         </div> 
		</div>
                <input type="hidden" name='article_imageslist' id='article_imageslist' value="<?=$arow['article_imageslist']?>">
	</div>
    
    
      <div class="layui-form-item">
    <label class="layui-form-label">文章属性</label>
    <div class="layui-input-block">
      <input type="checkbox"  title="热门" name="attr[article_ish]" <?=$arow['article_ish']==1?"checked":""?>  lay-filter="pagee">
        <input type="checkbox"  title="推荐" name="attr[article_isc]"  <?=$arow['article_isc']==1?"checked":""?>  lay-filter="pagee">
          <input type="checkbox"  title="换灯"  name="attr[article_isf]"  <?=$arow['article_isf']==1?"checked":""?>  lay-filter="pagee">
            <input type="checkbox"  title="外链" name="attr[article_isj]"  <?=$arow['article_isj']==1?"checked":""?>  lay-filter="pagee">
    </div>
  </div>
         <div class="layui-form-item">
		<label class="layui-form-label">外链地址</label>
		<div class="layui-input-block" style="width: 80%;">
                    <input type="text" name="article_isj_url" placeholder="外链地址" value="<?=!empty($arow['article_isj_url'])?$arow['article_isj_url']:""?>" id="artice_sort" class="layui-input">
		</div>
	</div>
     
      <div class="layui-form-item" >
                <label class="layui-form-label">更多参数</label>
                <div class="layui-input-block" style="width: 80%;">
                    <select name="" style="z-index: 99999;" lay-filter="test"  id="zdytest">
                        <option value="-1">无</option>
                      <?php
                      $sql = "select * from tm_articlezdyzd ";
                      $rs =$DB->query($sql);
                      while ($row = $rs->fetch()){
                          echo ' <option value="'.$row['articlezdyzd_id'].'">'.$row['articlezdyzd_name'].'</option>';
                      }
                      ?>
                    
                  </select>
                </div>
          </div>
    <div id="zdyzd_pdiv" style="display: none">
          <div class="layui-form-item" >
          <label class="layui-form-label"></label>
            <div class="layui-input-block" style="width:80%;">
                <div class="layui-card" >
            <div class="layui-card-header">请填写下方数据</div>
            <div class="layui-card-body"  id="zdy_inputlist">
               
            </div>
          </div>
		</div>
          
    </div>
    </div>
      <div class="layui-form-item">
		<label class="layui-form-label">自定义数据</label>
		<div class="layui-input-block" style="width: 80%;">
                     <input type="text" class="layui-input" name="article_zdy" id="article_zdy" value="<?=$arow['article_zdy']?>" >
		</div>
	</div>
     <div class="layui-form-item">
		<label class="layui-form-label">排序值</label>
		<div class="layui-input-block" style="width: 80%;">
                    <input type="number" name="artice_sort" placeholder="排序值" value="<?=$arow['artice_sort']?>" id="artice_sort" class="layui-input">
		</div>
	</div>
        <div class="layui-form-item">
		<label class="layui-form-label">文章作者</label>
		<div class="layui-input-block" style="width: 80%;">
                    <input type="text" name="article_author" placeholder="作者" value="<?=$arow['article_author']?>" id="article_author" class="layui-input">
		</div>
	</div>
      <div class="layui-form-item" >
		<label class="layui-form-label">文章内容</label>
		<div class="layui-input-block" style="width: 80%;">
			
                        <script type="text/javascript" charset="utf-8" src="../../ueditor/ueditor.config.js"></script>
                        <script type="text/javascript" charset="utf-8" src="../../ueditor/ueditor.all.min.js"> </script>
                        <script type="text/javascript" charset="utf-8" src="../../ueditor/lang/zh-cn/zh-cn.js"></script>
                            <script id="editor" name="editor" type="text/plain" width="100%" height="300px;" ><?=$arow['article_text']?></script>
                            <script>  var ue = UE.getEditor('editor');</script>
		</div>
	</div>
   
    
     
	<div class="layui-form-item">
		<div class="layui-input-block">
                    <button type="submit" class="layui-btn" lay-submit >保存修改</button>
			<button type="reset" class="layui-btn layui-btn-primary">重置</button>
		</div>
	</div>
</form>
<!-- 修改文章结束 -->
        
        <?php
    
}else{

?>  
    
       <!-- 添加开始 -->
       <form method="POST" action="?act=add" class="layui-form" style="margin-top: 10px;display: block;" onsubmit="return checkaddartcile()">

    
	<div class="layui-form-item">
		<label class="layui-form-label">文章标题</label>
                <div class="layui-input-block" style="width: 80%;">
                    <input type="text" name="article_title" placeholder="请输入文章标题" id="article_title" class="layui-input" required>
		</div>
                
	</div>
     
        <div class="layui-form-item">
		<label class="layui-form-label">文章描述</label>
		<div class="layui-input-block" style="width: 80%;">
			<input type="text" name="article_description" placeholder="请输入文章描述" id="article_description" class="layui-input">
		</div>
	</div>
        <div class="layui-form-item">
		<label class="layui-form-label">文章关键字</label>
		<div class="layui-input-block" style="width: 80%;">
			<input type="text" name="article_keywords" placeholder="请输入文章关键字" id="article_keywords" class="layui-input">
		</div>
	</div>
    
   
    <div class="layui-form-item" >
                <label class="layui-form-label">所属栏目</label>
                <div class="layui-input-block" style="width: 80%;">
                    <select name="article_lm_id" style="z-index: 99999;">
            
                      <?php
                      $sql = "select * from tm_lanmulist ";
                      $rs =$DB->query($sql);
                      while ($row = $rs->fetch()){
                          echo ' <option value="'.$row['lm_id'].'">'.$row['lm_name'].'</option>';
                      }
                      ?>
                    
                  </select>
                </div>
          </div>

      <div class="layui-form-item">
		<label class="layui-form-label">文章缩略图</label>
		<div class="layui-input-block" style="width: 80%;">
			<div class="layui-upload">
           <button type="button" class="layui-btn" id="test1">上传图片</button>
           <div class="layui-upload-list">
               <img class="layui-upload-img" id="demo1" style="width: 80px; height: 80px;">
             <p id="demoText"></p>
           </div>
         </div> 
		</div>
                <input type="hidden" name='article_images' id='article_images'>
	</div>
           
      
        <div class="layui-form-item">
		<label class="layui-form-label">上传图集</label>
		<div class="layui-input-block" style="width: 80%;">
			<div class="layui-upload">
           <button type="button" class="layui-btn" id="test2">上传图片[支持多张上传]</button>
            <blockquote class="layui-elem-quote layui-quote-nm" style="margin-top: 10px;">
            预览图：
            <div class="layui-upload-list" id="demo2"></div>
         </blockquote>
         </div> 
		</div>
                <input type="hidden" name='article_imageslist' id='article_imageslist'>
	</div>
      
  
 
           
    
      <div class="layui-form-item">
    <label class="layui-form-label">文章属性</label>
    <div class="layui-input-block">
      <input type="checkbox"  title="热门" name="attr[article_ish]"  lay-filter="pagee">
        <input type="checkbox"  title="推荐" name="attr[article_isc]"  lay-filter="pagee">
          <input type="checkbox"  title="换灯"  name="attr[article_isf]" lay-filter="pagee">
            <input type="checkbox"  title="外链" name="attr[article_isj]"  lay-filter="pagee">
    </div>
  </div>
    
     <div class="layui-form-item">
		<label class="layui-form-label">外链地址</label>
		<div class="layui-input-block" style="width: 80%;">
                    <input type="text" name="article_isj_url" placeholder="非外链可留空" value="<?=!empty($arow['article_isj_url'])?$arow['article_isj_url']:""?>" id="artice_sort" class="layui-input">
		</div>
	</div>
           
             <div class="layui-form-item" >
                <label class="layui-form-label">更多参数</label>
                <div class="layui-input-block" style="width: 80%;">
                    <select name="" style="z-index: 99999;" lay-filter="test"  id="zdytest">
                        <option value="-1">无</option>
                      <?php
                      $sql = "select * from tm_articlezdyzd ";
                      $rs =$DB->query($sql);
                      while ($row = $rs->fetch()){
                          echo ' <option value="'.$row['articlezdyzd_id'].'">'.$row['articlezdyzd_name'].'</option>';
                      }
                      ?>
                    
                  </select>
                </div>
          </div>
    <div id="zdyzd_pdiv" style="display: none;">
          <div class="layui-form-item" >
          <label class="layui-form-label"></label>
            <div class="layui-input-block" style="width:80%;">
                <div class="layui-card" style="background-color: gray">
            <div class="layui-card-header">请填写下方数据</div>
            <div class="layui-card-body"  id="zdy_inputlist">
               
            </div>
          </div>
		</div>
          
    </div>
        <input type="hidden" name="article_zdy" id="article_zdy" >
   
    </div>
           
               <div class="layui-form-item">
		<label class="layui-form-label">文章作者</label>
		<div class="layui-input-block" style="width: 80%;">
			<input type="text" name="article_author" placeholder="作者" id="article_author" class="layui-input">
		</div>
	</div>
    
       <div class="layui-form-item">
		<label class="layui-form-label">排序值</label>
		<div class="layui-input-block" style="width: 80%;">
			<input type="number" name="artice_sort" placeholder="排序值" id="artice_sort" class="layui-input">
		</div>
	</div>
     
    <div class="layui-form-item"  id="eaitdiv" style="" >
		<label class="layui-form-label">文章内容</label>
		<div class="layui-input-block" style="width: 80%;">
			
                        <script type="text/javascript" charset="utf-8" src="../../ueditor/ueditor.config.js"></script>
                        <script type="text/javascript" charset="utf-8" src="../../ueditor/ueditor.all.min.js"> </script>
                        <script type="text/javascript" charset="utf-8" src="../../ueditor/lang/zh-cn/zh-cn.js"></script>
                        <script id="editor" name="editor" type="text/plain" width="100%" height="300px;" wmode="transparent"></script>
                            <script>  var ue = UE.getEditor('editor');</script>
		</div>
	</div>
    
     
  
     
	<div class="layui-form-item">
		<div class="layui-input-block">
                    <button type="submit" class="layui-btn" lay-submit >添加文章</button>
			<button type="reset" class="layui-btn layui-btn-primary">重置</button>
		</div>
	</div>
</form>
<!-- 添加栏目结束 -->
    
    <?php
    
}?>

</body>

</html>

<script>
var url = '<?=SITE_URL?>';
function checkaddartcile(){
    var input = $(".zdyinput");
    var data = "";
    input.each(function(){
        if(data != "") data = data +"|";
        var name = $(this).attr("name");
        var value = $(this).val();
        data = data +name+"="+value
    })
    $("#article_zdy").val(data);
    return true;
}
layui.use('form', function(){
    var form = layui.form;
   form.on('select(test)', function(data){
      var id = data.value;
       var ii = layer.load(2, {shade:[0.1,'#fff']});
        $.ajax({
                type : "POST",
                url : "../ajax.php?act=getarticlezdyzd_kv",
                data : {"articlezdyzd_id":id},
                dataType : 'json',
                success : function(data) {
                     layer.close(ii);
                     $("#zdy_inputlist").text("");
                   
                     if(data.code == 1){
                         $("#zdyzd_pdiv").show();
                         
                         var data = data.data;
                         var list = data.split("|");
                         var ijs = "";
                         var fjs = "";
                         for(var i =0;i<list.length;i++){
                             var kv = list[i].split(":");
                             if(kv[2] == "images"){
                                 var html = ' <button style="margin-top: 5px;" type="button" id="'+kv[1]+'"  class="layui-btn test" lay-data="{url: \'/upload/\', accept: \'images\'}">【上传图片】'+kv[0]+'</button>'
        +'  <input type="hidden" style="width: 30%;display: inline-block;margin-top: 5px;" placeholder="请点击上传按钮,此输入框无需输入" name="'+kv[1]+'" id="hide_'+kv[1]+'" class="layui-input zdyinput"><br>';
                            ijs = ijs +" upload.render({"
                                        + "  elem: '#"+kv[1]+"'"
                                        +"   ,done: function(res, index, upload){"
                                        +   "  var item = this.item;var src = res.data.src;"
                                        +   "  $('#hide_"+kv[1]+"').val('/upload/img/'+src);$('#"+kv[1]+"').text('已上传图片：'+src)"
                                        + "  }"
                                        +" }); ";
                             }else if(kv[2] == "file"){
                                var html = ' <button style="margin-top: 5px;" type="button" id="'+kv[1]+'"  class="layui-btn test" lay-data="{url: \'/upload/file.php\', accept: \'file\'}">【上传附件】'+kv[0]+'</button>'
                                  +'  <input type="hidden" style="width: 30%;display: inline-block;margin-top: 5px;" placeholder="请点击上传按钮,此输入框无需输入" name="'+kv[1]+'" id="hide_'+kv[1]+'" class="layui-input zdyinput"><br>';
                                    fjs = fjs +" upload.render({"
                                        + "  elem: '#"+kv[1]+"'"
                                        +"   ,done: function(res, index, upload){"
                                        +   "  var item = this.item;var src = res.data.src;"
                                        +   "  $('#hide_"+kv[1]+"').val('/upload/file/'+src);$('#"+kv[1]+"').text('已上传附件：'+src)"
                                        + "  }"
                                        +" }); ";
                                 
                             }else if(kv[2] == "text"){
                                  var html = '<textarea name="'+kv[1]+'"  placeholder="'+kv[0]+'"  style="width: 30%;display: inline-block;margin-top: 5px;" class="layui-input zdyinput"></textarea><br>';
                             }else{
                                   var html = ' <input type="text" name="'+kv[1]+'" placeholder="'+kv[0]+'" style="width: 30%;display: inline-block;margin-top: 5px;"class="layui-input zdyinput" ><br>';
                             }
                           
                             $("#zdy_inputlist").append(html);
                             // form.render();
                            
                         }
                         var js = "<script>layui.use('upload', function(){"
                            +" var $ = layui.jquery"
                             +",upload = layui.upload;"+ijs +fjs
                             +"});"
                            +"<\/script>"; $("#zdy_inputlist").append(js);
    /*
                     *  "upload.render({"
       + "  elem: '.test'"
       +"   ,done: function(res, index, upload){"
       +   "  var item = this.item;var src = res.data.src;"
       +   "  alert($(this).text());"
       + "  }"
       +" }) " */
                     }else{
                           $("#zdyzd_pdiv").hide();
                     }
                },
                error:function(data){
                         layer.close(ii);
                        layer.msg('服务器错误');
                        return;
                        }
        });
   });
});
layui.use('upload', function(){
  var $ = layui.jquery
  ,upload = layui.upload;
  
  //普通图片上传
  var uploadInst = upload.render({
    elem: '#test1'
    ,url: '/upload/'
    ,before: function(obj){
      //预读本地文件示例，不支持ie8
      obj.preview(function(index, file, result){
        $('#demo1').attr('src', result); //图片链接（base64）
      });
    }
    ,done: function(res){
      //如果上传失败
      if(res.code > 0){
        return layer.msg('上传失败');
      }
      //上传成功
      $("#article_images").val(res.data.src);
      //alert($("#article_images").val());
    }
    ,error: function(){
      //演示失败状态，并实现重传
      var demoText = $('#demoText');
      demoText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-mini demo-reload">重试</a>');
      demoText.find('.demo-reload').on('click', function(){
        uploadInst.upload();
      });
    }
  });
  
    //多图片上传
  upload.render({
    elem: '#test2'
    ,url: '/upload/'
    ,multiple: true
    ,before: function(obj){
      //预读本地文件示例，不支持ie8
      obj.preview(function(index, file, result){
        $('#demo2').append('<img src="'+ result +'" alt="'+ file.name +'" width=80px; class="layui-upload-img">')
      });
    }
    ,done: function(res){
      //上传完毕
      var imgslist = $("#article_imageslist").val();
      if(imgslist!="")  imgslist = imgslist + ",";
      imgslist = imgslist + res.data.src;
       $("#article_imageslist").val(imgslist);
      
    }
  });
  
  
  
   //动态
  var uploadInst = upload.render({
    elem: '#upimages'
    ,url: '/upload/'
    ,before: function(obj){
      //预读本地文件示例，不支持ie8
      obj.preview(function(index, file, result){
        $('#demo1').attr('src', result); //图片链接（base64）
      });
    }
    ,done: function(res){
      //如果上传失败
      if(res.code > 0){
        return layer.msg('上传失败');
      }
      //上传成功
      $("#article_images").val(res.data.src);
      //alert($("#article_images").val());
    }
    ,error: function(){
      //演示失败状态，并实现重传
      var demoText = $('#demoText');
      demoText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-mini demo-reload">重试</a>');
      demoText.find('.demo-reload').on('click', function(){
        uploadInst.upload();
      });
    }
  });
  

  

 });
 
 
 



</script>