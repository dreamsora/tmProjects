<?php


include '../admintm.php';
$dir=ROOT.'beifen/';
$filename = $_GET['filename'];
if(empty($_GET['filename'])){
    die("文件不存在");
}

$file=$dir.$filename;


//1.重设响应类型
$info = getimagesize($file);
header("Content-Type:".$info['mime']);
//2.执行下载的文件名
header("Content-Disposition:attachment;filename=".$filename);
//3.指定文件大小
header("Content-Length:".filesize($file));
//4.响应内容
readfile($file);