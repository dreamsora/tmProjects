<?php
include 'admintm.php';
if($adminrow['admin_qx_system'] != 1){
    exit("您没有该页面的权限！");
}

?>

 <!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title>Table</title>
		<link rel="stylesheet" href="plugins/layui/css/layui.css" media="all" />
		<link rel="stylesheet" href="css/global.css" media="all">
		<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/table.css" />
	</head>

	<body>
		<div class="admin-main">

			<fieldset class="layui-elem-field">
				<legend>输入sql语句    <a href="javascript: location.reload();"  class="layui-btn layui-btn-primary layui-btn-mini" ><i class="layui-icon">&#x1002;</i>  刷新</a></legend>
                                <form action="?submit" method="POST">
                                <div class="layui-field-box">
					
                                    <textarea name='sql' rows="8" style="width: 100%" placeholder='在此输入可执行的sql命令'><?=@$_POST['sql']?></textarea>
                                    <br> <br>
                                    
                                 
                                        <input type="radio" name='sqltype' value="insert">&nbsp;增加数据
                                 
                                    <input type="radio" name='sqltype' value="update_delete">&nbsp;修改删除数据
                     
                                           <input type="radio" name='sqltype' value="query" >&nbsp;查询数据
                               
                                     <input type="radio" name='sqltype' value="exectue">&nbsp;执行语句
                                     
                                <br> <br>
                                
                         
                              
                                
                                    <blockquote class="layui-elem-quote">
                         
				
                                        <button type="submit" class="layui-btn layui-btn-normal" >
					<i class="layui-icon">&#xe638;</i> 执行
				</button>
				
			</blockquote>

				</div>
                                         
                                    </form>
			</fieldset>
                    
                    <fieldset class="layui-elem-field">
				<legend>结果集    <a href="javascript: location.reload();"  class="layui-btn layui-btn-primary layui-btn-mini" ><i class="layui-icon">&#x1002;</i>  刷新</a></legend>
				<div class="layui-field-box">
                                   
 <pre><?php
if(isset($_GET['submit'])){
    $type = $_POST['sqltype'];
    $sql = $_POST['sql'];
    switch ($type){
        case 'insert':
            $ret = $DB->exec($sql);
            $lastid = $DB->lastinsertid();
            if($ret){
                echo '执行成功！返回:'.$ret.",该条数据id：".$lastid;
            }else{
                echo '执行失败！'.print_r($DB->errorInfo());
            }
            break;

        case 'update_delete':
            $ret = $DB->exec($sql);
            if($ret){
                echo '执行成功！返回:'.$ret;
            }else{
                echo '执行失败！'.print_r($DB->errorInfo()) ;
            }

            break;

        case 'query':
             $ret = $DB->query($sql);
            if($ret){
                echo '<br><br>执行成功！<br><br>'.var_dump($ret->fetchALL());
            }else{
                echo '执行失败！'.print_r($DB->errorInfo()) ;
            }
            break;

        case 'exectue':
             $ret = $DB->exec($sql);
            if($ret){
                echo '执行成功！返回结果:<br>'.var_dump($ret);
            }else{
                echo '执行失败！'.print_r($DB->errorInfo()) ;
            }
            break;

        default :
            echo '没有选择sql命令类型';
            break;
    }
}

?>
                                        </pre>
				</div>
			</fieldset>
			
		</div>
            <script src="layui/jquery-1.8.2.min.js"></script>
		<script type="text/javascript" src="plugins/layui/layui.js"></script>
		<script>
                    
                    
			
            
		</script>
	</body>

</html>