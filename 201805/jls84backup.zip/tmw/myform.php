<?php
include 'admintm.php';
if($adminrow['admin_qx_article'] != 1){
    exit("您没有该页面的权限！");

}
function data_type($type){
    if($type == "number"){
     return "数字类型";   
    }elseif($type == "radio"){
     return "radio选项卡";   
    }elseif($type == "checkbox"){
     return "Checkbox多选框";   
    }elseif($type == "select"){
     return "option下拉框";   
    }elseif($type == "int"){
     return "数字类型";   
    }elseif($type == "textarea"){
     return "多行文本";   
    }elseif($type == "text"){
     return "单行文本";   
    }else{
     return $type;
    }
}
if(!empty($_GET['act']) && $_GET['act'] == "sum_add"){
    $frm_name = daddslashes($_POST['frm_name']);
    $frm_frmname = daddslashes($_POST['frm_frmname']);
    
     $frm_list_model = daddslashes($_POST['frm_list_model']);
     $frm_con_model = daddslashes($_POST['frm_con_model']);
     $frm_put_model = daddslashes($_POST['frm_put_model']);
       
     $frm_status = intval($_POST['frm_status']);
     
     $sql = "insert into tm_form(frm_name,frm_frmname,frm_addtime,frm_list_model,frm_con_model,frm_put_model,frm_status) "
             . "value('$frm_name','$frm_frmname',now(),'$frm_list_model','$frm_con_model','$frm_put_model',$frm_status)";
    $tablecheck = true;
    $rs = $DB->query("show tables from ".$data['db_name']);
    while ($row=$rs->fetch()){
       if($row[0] == $frm_frmname){
           $tablecheck = false;
           break;
       }
    }
   if(!$tablecheck){
          exit('<script>alert("当前数据表已经存在！");window.history.go(-1);</script>');
   }
   
    //创建数据表
   $cre_sql = "CREATE TABLE ".$frm_frmname." (id INT(12) UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '编号|number')";
   $DB->exec($cre_sql);
   
   $addcheck = false;
   $rs = $DB->query("show tables from ".$data['db_name']);
    while ($row=$rs->fetch()){
       if($row[0] == $frm_frmname){
           $addcheck = true;
           break;
       }
    }
   
   
   if($addcheck){
       $DB->exec($sql);
        exit("<script language='javascript'>alert('创建成功！');window.location.href='./myform.php';</script>");
   }else{
 
         exit('<script>alert("创建数据表失败！");window.history.go(-1);</script>');
   }
   
}

?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title>Table</title>
		<link rel="stylesheet" href="plugins/layui/css/layui.css" media="all" />
		<link rel="stylesheet" href="css/global.css" media="all">
		<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/table.css" />
	</head>

	<body>
		<div class="admin-main">
                    
                    <?php
                    if(!empty($_GET['act']) && $_GET['act'] =="add"){
                     
                        ?>
                    
                    	<blockquote class="layui-elem-quote">
                            <a href="?" 	class="layui-btn layui-btn-lg" >
					<i class="layui-icon">&#xe647;</i> 全部自定义表单
				</a>
                                <a href="javascript: location.reload();"  class="layui-btn layui-btn-normal" >
					<i class="layui-icon">&#x1002;</i>  刷新页面
				</a>
                        
			</blockquote>
                            <!-- 添加开始--->
                            <form method="POST" action="?act=sum_add" class="layui-form" style="margin-top: 10px;display: block;">

    
	<div class="layui-form-item">
		<label class="layui-form-label">表单名称</label>
                <div class="layui-input-block" style="width: 80%;">
			<input type="text" name="frm_name" placeholder="表单名称" id="frm_name" class="layui-input" required>
		</div>
	</div>
                                
          <div class="layui-form-item">
		<label class="layui-form-label">数据表名</label>
                <div class="layui-input-block" style="width: 80%;">
                    <input type="text" name="frm_frmname" placeholder="数据表名" id="frm_name" class="layui-input" required>
		</div>
	</div>
       
        <div class="layui-form-item zdykeys">
                <div class="layui-input-block" style="width:100%;">
                    <input type="text"  placeholder="列表模板" name="frm_list_model" value="list_diyform.html" class="layui-input" style="display: inline-block;width: 25%;" required>
                        <input type="text"  placeholder="内容模板" name="frm_con_model" value="view_diyform.html" class="layui-input"  style="display: inline-block;width: 25%;" required>
                   <input type="text"  placeholder="发布模板" name="frm_put_model" value="post_diyform.html" class="layui-input"  style="display: inline-block;width: 25%;" required>
                        
		</div>
	</div>
          <div class="layui-form-item">
		<label class="layui-form-label">前台列表和内容页公开</label>
                <div class="layui-input-block" style="width: 80%;">
                  
                    <select lay-ignore name="frm_status" >
                        <option value="1">完全公开</option>
                        <option value="0" selected>审核公开</option>
                            <option value="-1">不公开</option>
                    </select>
                    
		</div>
	</div>                
             
	<div class="layui-form-item">
		<div class="layui-input-block">
                    <button type="submit" class="layui-btn" lay-submit >保存</button>
			<button type="reset" class="layui-btn layui-btn-primary">重置</button>
		</div>
	</div>
</form>
                             <!-- 添加结束--->
                            <?php
                    }elseif(!empty($_GET['act']) && $_GET['act'] == "sub_editzd"){
                          $frmname = daddslashes($_POST['frmname']);
                        $tis_name = daddslashes($_POST['tis_name']);
                        $zd_name = daddslashes($_POST['zd_name']);
                         if($frmname == "" || $frmname == "" || $zd_name == ""){
                                  exit('<script>alert("error！Not set data！");window.history.go(-1);</script>');
                            }
                        $data_type = explode("|",daddslashes($_POST['data_type']));
                        $default = daddslashes($_POST['default']);
                        //ALTER TABLE table_name ADD field_name field_type;
                        $type = $data_type[0];
                        if($type == "enum" || $type == "set"){
                            if($default == ""){
                                  exit('<script>alert("error！Not set default！");window.history.go(-1);</script>');
                            }
                            $default = str_replace("，", ",", $default);
                            $default = explode(",", $default);
                            $valuedata = "";
                            foreach ($default as $value) {
                                if($valuedata !="") $valuedata .= ",";
                                $valuedata = $valuedata ."'$value'";
                            }
                            $type = $type."($valuedata)";
                        }
                        //$sql = "ALTER TABLE $frmname add $zd_name $type COMMENT '$tis_name|$data_type[1]'";
                        $sql = "alter table $frmname  modify column $zd_name $type COMMENT '$tis_name|$data_type[1]';";
                        if($DB->query($sql)){
                             exit('<script>alert("修改成功！");
                                var index=parent.layer.getFrameIndex(window.name); parent.layer.close(index);</script>');
                        }else{
                            exit('<script>alert("修改失败！");
                                var index=parent.layer.getFrameIndex(window.name); parent.layer.close(index);</script>');
                        }
                        
                    }elseif(!empty($_GET['act']) && $_GET['act'] == "editzd"){
                        $frmname= daddslashes($_GET['frmname']);
                        $zd = daddslashes($_GET['zd']);
                        $sql = "select COLUMN_NAME,column_comment,COLUMN_TYPE from INFORMATION_SCHEMA.Columns where table_name='".$frmname."' and table_schema='".$data['db_name']."' and COLUMN_NAME='$zd'";
                        $row = $DB->query($sql)->fetch();
                     
                        $t = explode("|", $row['column_comment']);
                     
                    //    echo var_dump($row['COLUMN_TYPE']);
                        $enum = $row['COLUMN_TYPE'];
                        $enum = str_replace("'", "", $enum);
                         $enum_arr=explode("(",$enum);
    $enum=$enum_arr[1];
    $enum_arr=explode(")",$enum);
    $enum=$enum_arr[0];
    $enum_arr=explode(",",$enum);

                        ?>
                          <div class="layui-form">
                <table class="layui-table">
                  <colgroup>
                    <col width="150">
                    <col width="150">
                    <col width="200">
                    <col>
                  </colgroup>
                  <thead>
                  <form action="?act=sub_editzd" method="POST">
                    <tr>
                        <th >【表<?=$frmname?>】字段编辑说明：</th>
                        <th colspan="3">*所有填写的内容不允许包含 | ，否则配置将无法写入。</th>
                    </tr> 
                  </thead>
                    <tbody>
                       <tr>
                        <th >表单提示文字</th>
                        <th colspan="3"><input type="hidden" name="frmname" value="<?=$frmname?>"><input   value="<?=$t[0]?>" type="text" name="tis_name"></th>
                    </tr> 
                    <tr>
                        <th >表单字段名</th>
                        <th colspan="3"><input type="text" name="zd_name" value="<?=$zd?>">*请勿修改字段名</th>
                    </tr> 
                      <tr>
                        <th >数据类型</th>
                        <th colspan="3">
                            <select name="data_type">
                                <option value="varchar(100)|text" <?=$t[1]=="text"?"selected":""?> > 单行文本</option>
                                 <option value="text|textarea"  <?=$t[1]=="textarea"?"selected":""?>>多行文本</option>
                                  <option value="enum|select" <?=$t[1]=="select"?"selected":""?>>option下拉框</option>
                                  <option value="enum|radio" <?=$t[1]=="radio"?"selected":""?>>radio选项卡</option>
                                   <option value="set|checkbox" <?=$t[1]=="checkbox"?"selected":""?>>Checkbox多选框</option>
                            </select>
                            
                        </th>
                    </tr>
                     <tr>
                        <th >默认值</th>
                        <th colspan="3"><textarea rows="4" style="width: 100%;" name="default"><?php    
                        for($i=0;$i<count($enum_arr);$i++){
        echo $enum_arr[$i];
        if($i<count($enum_arr)-1)            echo ',';
    } ?></textarea>
                        *option下拉框，radio选项卡，Checkbox多选框需要设置默认值，格式为：xx,xx,xx 比如：男,女,人妖,
                        </th>
                    </tr>
                     <tr>
                        <th ></th>
                        <th colspan="3">
                            <input type="submit" value="提交保存">
                        </th>
                    </tr>
                    </tbody>
                    </form>
                </table>
                </div>  
                            
                            
                        <?php
                    }elseif(!empty($_GET['act']) && $_GET['act'] =="sub_addzd"){
                         $frmname = daddslashes($_POST['frmname']);
                        $tis_name = daddslashes($_POST['tis_name']);
                        $zd_name = daddslashes($_POST['zd_name']);
                         if($frmname == "" || $frmname == "" || $zd_name == ""){
                                  exit('<script>alert("error！Not set data！");window.history.go(-1);</script>');
                            }
                        $data_type = explode("|",daddslashes($_POST['data_type']));
                        $default = daddslashes($_POST['default']);
                        //ALTER TABLE table_name ADD field_name field_type;
                        $type = $data_type[0];
                        if($type == "enum" || $type == "set"){
                            if($default == ""){
                                  exit('<script>alert("error！Not set default！");window.history.go(-1);</script>');
                            }
                            $default = str_replace("，", ",", $default);
                            $default = explode(",", $default);
                            $valuedata = "";
                            foreach ($default as $value) {
                                if($valuedata !="") $valuedata .= ",";
                                $valuedata = $valuedata ."'$value'";
                            }
                            $type = $type."($valuedata)";
                        }
                        $sql = "ALTER TABLE $frmname add $zd_name $type COMMENT '$tis_name|$data_type[1]'";
                       if($DB->query($sql)){
                              exit('<script>alert("添加成功！");
                                var index=parent.layer.getFrameIndex(window.name); parent.layer.close(index);</script>');
                        }else{
                            exit('<script>alert("修改失败！");
                                var index=parent.layer.getFrameIndex(window.name); parent.layer.close(index);</script>');
                        }
                        
                        
                    }elseif(!empty($_GET['act']) && $_GET['act'] =="addzd"){
                        $frmname = $_GET['frmname'];
                        ?>
                            
                            <div class="layui-form">
                <table class="layui-table">
                  <colgroup>
                    <col width="150">
                    <col width="150">
                    <col width="200">
                    <col>
                  </colgroup>
                  <thead>
                  <form action="?act=sub_addzd" method="POST">
                    <tr>
                        <th >【表<?=$frmname?>】字段增加说明：</th>
                        <th colspan="3">*所有填写的内容不允许包含 | ，否则配置将无法写入。</th>
                    </tr> 
                  </thead>
                    <tbody>
                       <tr>
                        <th >表单提示文字</th>
                        <th colspan="3"><input type="hidden" name="frmname" value="<?=$frmname?>"><input type="text" name="tis_name"></th>
                    </tr> 
                    <tr>
                        <th >表单字段名</th>
                        <th colspan="3"><input type="text" name="zd_name"></th>
                    </tr> 
                      <tr>
                        <th >数据类型</th>
                        <th colspan="3">
                            <select name="data_type">
                                <option value="varchar(100)|text">单行文本</option>
                                 <option value="text|textarea">多行文本</option>
                                  <option value="enum|select">option下拉框</option>
                                  <option value="enum|radio">radio选项卡</option>
                                   <option value="set|checkbox">Checkbox多选框</option>
                            </select>
                            
                        </th>
                    </tr>
                     <tr>
                        <th >默认值</th>
                        <th colspan="3"><textarea rows="4" style="width: 100%;" name="default"></textarea>
                        *option下拉框，radio选项卡，Checkbox多选框需要设置默认值，格式为：xx,xx,xx 比如：男,女,人妖,
                        </th>
                    </tr>
                     <tr>
                        <th ></th>
                        <th colspan="3">
                            <input type="submit" value="提交保存">
                        </th>
                    </tr>
                    </tbody>
                    </form>
                </table>
                </div>
                            
                            
                            
                        <?php
                    }elseif(!empty($_GET['act']) && $_GET['act'] == "sub_edit"){
                        $id = intval($_GET['id']);
                        $frm_name = daddslashes($_POST['frm_name']);
                        $frm_list_model = daddslashes($_POST['frm_list_model']);
                        $frm_con_model = daddslashes($_POST['frm_con_model']);
                        $frm_put_model = daddslashes($_POST['frm_put_model']);
                        $frm_status = intval($_POST['frm_status']);
                        $sql = "update tm_form "
                                . "set frm_name ='$frm_name',frm_list_model='$frm_list_model',frm_con_model='$frm_con_model',frm_put_model='$frm_put_model',frm_status='$frm_status' "
                                . "where frm_id = ".$id;
                        if($DB->query($sql)){
                              exit("<script language='javascript'>alert('修改成功！');window.location.href='./myform.php';</script>");
                          }else{
                                exit('<script>alert("修改失败！");window.history.go(-1);</script>');
                          }
                        
                    }elseif(!empty($_GET['act']) && $_GET['act'] =="edit"){
                        $id = intval($_GET['id']);
                        $sql = "select * from tm_form where frm_id=".$id." limit 1";
                        $row = $DB->query($sql)->fetch();
                     
                        
                        ?>
                              	<blockquote class="layui-elem-quote">
                            <a href="?" 	class="layui-btn layui-btn-lg" >
					<i class="layui-icon">&#xe647;</i> 全部自定义表单
				</a>
                                <a href="javascript: location.reload();"  class="layui-btn layui-btn-normal" >
					<i class="layui-icon">&#x1002;</i>  刷新页面
				</a>
                        
			</blockquote>
                            
                            
                            
<div class="layui-form">
  <table class="layui-table">
    <colgroup>
      <col width="150">
      <col width="150">
      <col width="200">
      <col>
    </colgroup>
    <thead>
      <tr>
          <th colspan="4">自定义表单 [<?=$row['frm_frmname']?>]</th>
       
      </tr> 
    </thead>
    <tbody>
    <form action="?act=sub_edit&id=<?=$row['frm_id']?>" method="POST">
      <tr>
        <td>表单ID</td>
        <td colspan="3"><?=$row['frm_id']?></td>
      </tr>
      
      <tr>
        <td>表单名称</td>
        <td colspan="3"><input type="text" value="<?=$row['frm_name']?>" name="frm_name"></td>
      </tr>
      
      <tr>
        <td>数据表名称</td>
        <td colspan="3"><input type="text" value="<?=$row['frm_frmname']?>" name="frm_frmname" disabled></td>
      </tr>
      
      <tr>
        <td>创建时间</td>
        <td colspan="3"><?=$row['frm_addtime']?></td>
      </tr>
       <tr>
        <td>字段展示</td>
        <td colspan="3">
            <a onclick="addzd('<?=$row['frm_frmname']?>')" class="layui-btn ">增加字段</a>
                <div class="layui-form">
                <table class="layui-table">
                  <colgroup>
                    <col width="150">
                    <col width="150">
                    <col width="200">
                    <col>
                  </colgroup>
                  <thead>
                    <tr>
                        <th style="width: 25%">表单提示文字</th>
                        <th style="width: 25%">数据字段名</th>
                        <th style="width: 25%">数据类型</th>
                        <th style="width: 25%">维护</th>
                    </tr> 
                  </thead>
                    <tbody>
                       
                           <?php
                           $sql = "select COLUMN_NAME,column_comment,COLUMN_TYPE from INFORMATION_SCHEMA.Columns where table_name='".$row['frm_frmname']."' and table_schema='".$data['db_name']."'";
                           
                           $rs = $DB->query($sql);
                           while ($crow = $rs->fetch()){
                               $column_comment = explode("|", $crow['column_comment']);
                               
                              ?>
                                  
                                <tr>
                        <td style="width: 25%"><?=$column_comment[0]?></td>
                         <td style="width: 25%"><?=$crow['COLUMN_NAME']?></td>
                          <td style="width: 25%"><?=data_type($column_comment[1])?></td>
                          <td style="width: 25%">
                               <a onclick="bjzd('<?=$crow['COLUMN_NAME']?>','<?=$row['frm_frmname']?>')" class="layui-btn layui-btn-small layui-btn-normal">编辑</a>
                              <a onclick="delzd('<?=$crow['COLUMN_NAME']?>','<?=$row['frm_frmname']?>')" class="layui-btn layui-btn-small layui-btn-danger">删除</a>
                          </td>
                    </tr>    
                                  
                                  
                               <?php
                           }
                           ?>
                    </tbody>
                </table>
                </div>
            
        </td>
      </tr>
      
          <tr>
        <td>列表模板</td>
        <td colspan="3"><input type="text" value="<?=$row['frm_list_model']?>" name="frm_list_model" ></td>
      </tr>
          <tr>
        <td>内容模板</td>
        <td colspan="3"><input type="text" value="<?=$row['frm_con_model']?>" name="frm_con_model" ></td>
      </tr>
          <tr>
        <td>发布模板</td>
        <td colspan="3"><input type="text" value="<?=$row['frm_put_model']?>" name="frm_put_model" ></td>
      </tr>
        <tr>
        <td>是否公开</td>
        <td colspan="3"> 
                    <select lay-ignore name="frm_status" >
                        <option value="1">完全公开</option>
                        <option value="0" selected>审核公开</option>
                            <option value="-1">不公开</option>
                    </select>
        </td>
      </tr>
       <tr>
        <td> 
         
        </td>
        <td colspan="3"> 
               <input type="submit" value="提交保存">
            <input type="reset" value="重置">
        </td>
        
      </tr>
   </form>
    </tbody>
  </table>
</div>
         
                        
                            
                            
                        <?php
                    }else{
                        
                  ?>
                    
                <!-- 展示开始 -->
			<blockquote class="layui-elem-quote">
                            <a href="?act=add" 	class="layui-btn layui-btn-lg" >
					<i class="layui-icon">&#xe608;</i> 添加自定义表单
				</a>
                                <a href="javascript: location.reload();"  class="layui-btn layui-btn-normal" >
					<i class="layui-icon">&#x1002;</i>  刷新页面
				</a>
                        
			</blockquote>
			<fieldset class="layui-elem-field">
				<legend>自定义表单列表</legend>
				<div class="layui-field-box">
					<table class="site-table table-hover">
						<thead>
							<tr>
                                                                <th>表单ID</th>
								<th>表单标题</th>
								<th>数据表</th>
								<th>添加时间</th>
								
								
								<th>操作</th>
							</tr>
						</thead>
						<tbody> <?php
                                                   $sql = "select * from tm_form   order by frm_id desc ";
                                                    $rs = $DB->query($sql);
                                                    while ($row = $rs->fetch()){
                                                        ?>
                                                            <tr>
								
								<td><?=$row['frm_id']?></td>
								<td><?=$row['frm_name']?></td>
							
								<td><?=$row['frm_frmname']?></td>
								<td><?=$row['frm_addtime']?></td>
							
								
								<td>
                                                                    <a href="<?=SITE_URL?>/other/diy.php?action=put&id=<?=$row['frm_id']?>" target="_block" class="layui-btn layui-btn-normal layui-btn-mini">预览表单</a>
                                                                  <a href="?act=edit&id=<?=$row['frm_id']?>" class="layui-btn layui-btn-mini">编辑字段</a>
                                                                        <a onclick="deletefrm(<?=$row['frm_id']?>)" data-id="1" data-opt="del" class="layui-btn layui-btn-danger layui-btn-mini">删除</a>
								</td>
							</tr>
                                                  <?php
                                                    }
                                                    ?>
						</tbody>
					</table>
                  
				</div>
			</fieldset>
                    
                    <!-- 展示结束 -->
                 <?php
                   }
                    ?>
                
		</div>
            <script src="layui/jquery-1.8.2.min.js"></script>
		<script type="text/javascript" src="plugins/layui/layui.js"></script>
               
		<script>
                   layui.use('form', function(){
                          var form = layui.form;
                        
                        })
			layui.config({
				base: 'plugins/layui/modules/'
			});
                       
			layui.use(['icheck', 'laypage','layer'], function() {
				var $ = layui.jquery,
					laypage = layui.laypage,
					layer = parent.layer === undefined ? layui.layer : parent.layer;
				$('input').iCheck({
					checkboxClass: 'icheckbox_flat-green'
				});

				
                             
				


				$('.site-table tbody tr').on('click', function(event) {
					var $this = $(this);
					var $input = $this.children('td').eq(0).find('input');
					$input.on('ifChecked', function(e) {
						$this.css('background-color', '#EEEEEE');
					});
					$input.on('ifUnchecked', function(e) {
						$this.removeAttr('style');
					});
					$input.iCheck('toggle');
				}).find('input').each(function() {
					var $this = $(this);
					$this.on('ifChecked', function(e) {
						$this.parents('tr').css('background-color', '#EEEEEE');
					});
					$this.on('ifUnchecked', function(e) {
						$this.parents('tr').removeAttr('style');
					});
				});
				$('#selected-all').on('ifChanged', function(event) {
					var $input = $('.site-table tbody tr td').find('input');
					$input.iCheck(event.currentTarget.checked ? 'check' : 'uncheck');
				});
			});
                        function addzd(frmname){
                             layer.open({
                                            type: 2,
                                            title: '增加字段',
                                           shadeClose: true,
                                             shade: false,
                                                maxmin: true, //开启最大化最小化按钮
                                            area: ['90%', '90%'],
                                            content: './myform.php?act=addzd&frmname='+frmname,
                                            end: function () {
                                                location.reload();
                                          }
                              });
                        }
                        function bjzd(zd,frm){
                              layer.open({
                                            type: 2,
                                            title: '编辑字段',
                                           shadeClose: true,
                                             shade: false,
                                                maxmin: true, //开启最大化最小化按钮
                                            area: ['90%', '90%'],
                                            content: './myform.php?act=editzd&frmname='+frm+"&zd="+zd,
                                            end: function () {
                                                location.reload();
                                          }
                              });
                        }
                        function deletefrm(id){
                            if(confirm("确定要删除这张表吗？")){
                                 var ii = layer.load(2, {shade:[0.1,'#fff']});
                           
                                $.ajax({
                                       type : "POST",
                                       url : "ajax.php?act=deletefrm",
                                       data : {"id":id},
                                       dataType : 'json',
                                       success : function(data) {
                                            layer.close(ii);
                                            layer.msg(data.msg);
                                            if(data.code == 1){
                                                   location.reload();
                                            }

                                       },
                                       error:function(data){
                                                layer.close(ii);
                                               layer.msg('服务器错误');
                                               return;
                                               }
                               });
                            }
                        }
                        function delzd(zd,frm){
                            if(confirm("确定要删除"+frm+"表中的字段"+zd+"吗？")){
                                 var ii = layer.load(2, {shade:[0.1,'#fff']});
                           
                                $.ajax({
                                       type : "POST",
                                       url : "ajax.php?act=deletezd",
                                       data : {"zd":zd,"frm":frm},
                                       dataType : 'json',
                                       success : function(data) {
                                            layer.close(ii);
                                            layer.msg(data.msg);
                                            if(data.code == 1){
                                                   location.reload();
                                            }

                                       },
                                       error:function(data){
                                                layer.close(ii);
                                               layer.msg('服务器错误');
                                               return;
                                               }
                               });
                            }
                        }
                
		</script>
	</body>

</html>