$(window).scroll(function() {
        var scrolls = $(this).scrollTop();
        if(scrolls > 100){
            $("#bar-up").show();
        }else{
            $("#bar-up").hide();
        }
});
$(function() {
    var ui = $.fn.ui || {};
    ui.fx = {
        goPageEnd: function() {
            $(document).scrollTop = $(document).height(),
            $("html,body").animate({
                scrollTop: $("body").outerHeight()
            },
            1e3)
        },
        goPageTop: function() {
            console.log(0),
            $("html,body").animate({
                scrollTop: 0
            },
            1e3)
        }
    },
    $(document).delegate("[data-on-click]", "click",
    function(e) {
        var cmd = $(this).data("on-click"),
        key = cmd.substring(0, 2);
        "ui" == key && eval(cmd.replace(":", ".") + "()")
    })
}),
$(function(){
	$('#bar-app').mouseenter(function(){
		$(this).addClass('blue');         
		$('div',this).removeClass('bg-app1');
		$('span',this).show();
		$('.float-bar-ewm').show();
	}); 
	$('#bar-app').mouseleave(function(){
		$(this).removeClass('blue');         
		$('div',this).addClass('bg-app1');
		$('span',this).hide();
		$('.float-bar-ewm').hide();
	});
	$('#bar-fav').mouseenter(function(){
		$(this).addClass('blue');         
		$('div',this).removeClass('bg-fav');
		$('span',this).show();
	}); 
	$('#bar-fav').mouseleave(function(){
		$(this).removeClass('blue');         
		$('div',this).addClass('bg-fav');
		$('span',this).hide();
	});
	$('#bar-up').mouseenter(function(){
		$(this).addClass('blue');         
		$('div',this).removeClass('bg-up');
		$('span',this).show();
	}); 
	$('#bar-up').mouseleave(function(){
		$(this).removeClass('blue');         
		$('div',this).addClass('bg-up');
		$('span',this).hide();
	});
});
jQuery.fn.addFavorite = function(l, h) {
	return this.click(function() {
		var obj = $(this);
		if($.browser.msie) {
			window.external.addFavorite(h, l);
		} else if (jQuery.browser.mozilla || jQuery.browser.opera) {
			obj.attr("rel", "sidebar");
			obj.attr("title", l);
			obj.attr("href", h);
		} else {
			alert("请使用Ctrl+D将本页加入收藏夹！");
		}
	});
};

$('#bar-fav').addFavorite(document.title,location.href);
$('#top-fav').addFavorite('借钱大全 - 快速借款','http://www.pcben.com/');
