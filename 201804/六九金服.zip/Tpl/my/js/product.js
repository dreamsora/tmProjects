$('#jie_money,#jie_day').keyup(function () {
	var jie_money = $('#jie_money').val();
	var jie_day = $('#jie_day').val();
	suan(jie_money, jie_day);
});

function suan(jie_money, jie_day) {
	if (!jie_money || !jie_day) {
		$('#yhk').text('0');
		$('#zfy').text('0');
		return false;
	}
	if (!isNaN(jie_money) && !isNaN(jie_day)) {
		var rate = $('#lixi').text();
		rate = rate.replace("%", "");
		var yhk = '', zfy = '';
		zfy = jie_money * (rate / 100) * jie_day;
		yhk = jie_money - (-zfy);
		$('#yhk').text(yhk.toFixed(2));
		$('#zfy').text(zfy.toFixed(2));
	}
}
$('#tab_title li').click(function() {
	var i = $(this).index();//下标第一种写法
	$(this).addClass('cur').siblings().removeClass('cur');
	$('#tab_detail li').eq(i).show().siblings().hide();
});
$(function()
{
 //异步提交表单

 })