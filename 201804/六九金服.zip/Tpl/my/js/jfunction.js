window.onscroll = function() {
	var top = document.documentElement.scrollTop || document.body.scrollTop;
	var toTop = document.getElementById("back-to-top");
	if(toTop){
		if (top > 100) {
			toTop.style.display = "block";
		} else {
			toTop.style.display = "none";
		}
	}
};
var toTop = new
function() {
	var Timer = null;
	function $id(id) {
		return typeof id == "string" ? document.getElementById(id) : id;
	};
	this.goto = function() {
		$id("back-to-top").onclick = function() {
			var top = document.documentElement.scrollTop || document.body.scrollTop;
			startNove();
			return false;
		};
		var startNove = function() {
			if (Timer) clearInterval(Timer);
			Timer = setInterval(doMove, 10);
		};
		var doMove = function() {
			var iSpeed = 0;
			var top = document.documentElement.scrollTop || document.body.scrollTop;
			iSpeed = (0 - top) / 5;
			iSpeed = iSpeed > 0 ? Math.ceil(iSpeed) : Math.floor(iSpeed);
			if (Math.abs(iSpeed) < 1 && Math.abs(0 - top) < 1) {
				clearInterval(Timer);
				Timer = null;
			}
			window.scrollTo(0, (top + iSpeed));
		};
	};
};
$(function() {
	var share = $(".share");
	if(share.length >= 1) {
		$("#header span").click(function() {
			$("body").css({"overflow" : "hidden"})
			$(".share_mark").show();
			$(".share_mark").stop().animate({
				"opacity" : "1"
			},300) 
			$(".share_box").stop().animate({
				"height" : "125px"
			},300)
		})
		$(".title span").click(function() {
			$("body").css({"overflow" : "hidden"})
			$(".share_mark").show();
			$(".share_mark").stop().animate({
				"opacity" : "1"
			},300) 
			$(".share_box").stop().animate({
				"height" : "125px"
			},300)
		})
		$(".share_mark").click(function() {
			shareHide()
		})
		$(".share_box span").click(function(){
			shareHide()
		})
		function shareHide() {
			$("body").css({"overflow" : "inherit"})
			$(".share_box").stop().animate({
				"height" : "0"
			},300)
			$(".share_mark").stop().animate({
				"opacity" : "0"
			},300)
			setTimeout(function(){
				$(".share_mark").hide();     
			}, 300) 
		}
	}
});
$(function(){
    
	var downbar = "true";
	var u = navigator.userAgent;
	var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
	if(!isiOS)$('.download').removeClass('dn');
	if(downbar!="false"){
		if(localStorage.getItem('downbar')==null || localStorage.getItem('downbar')==true){
			$('.download-bar').removeClass('dn');
		}
	}

	$('.download-bar-close').click(function(e){
		$(this).parents('.download-bar').hide();
		localStorage.setItem("downbar",false);
		return false;
	})
})
